# Mochi Module Recovery State

Preserved exact state after successful runtime decryption of 48/49 module display names.

## Contents

- `harness/`
  - `modules.txt` — the 49 obfuscated module subclass names (one per line, UTF-8)
  - `Harness.java` / `Harness.class` — the working isolated JVM harness
  - `mochi-classes.jar` — original Mochi classes + A.class + L.class + .bin resources + all required Minecraft/Fabric/Gson stubs
- `mapping/`
  - `display_name_to_class.tsv` — full mapping: display_name → obfuscated_class → category → description (49 rows; one entry has texture paths instead of a clean name)
  - `recovered_names_only.txt` — clean list of the 48 real display names
- `stubs/`
  - Java sources and compiled hierarchy stubs used for net.minecraft.*, FabricLoader, Gson
- `logs/`
  - `successful_extraction_utf8.log` — full harness output (TOTAL_OK=49)
- `disassembly/`
  - `u_clinit_and_methods.txt` — javap of cc.mochi.ԋ.Ư.u (the DES decryptor)
  - `A.txt`, `L.txt` — javap of the anti-tamper / resource-hash helpers

## Critical fixes already applied (do not re-derive)

1. **L.L needs class bytecode as resources**  
   ClassLoader must return the .class bytes via getResourceAsStream("cc/mochi/.../Foo.class") so L can hash them. Otherwise L.L returns -1 → NegativeArraySizeException (-2004742078) inside u.<clinit>.

2. **.bin resources**  
   e6cbc84a-7eac-4094-8193-5d89a0bab226.bin and 246a7a43-4c7a-4ea1-bb49-29fcc4aeeb2e.bin must be served (with and without leading /).

3. **Minecraft hierarchy stubs** (in mochi-classes.jar)  
   class_1297 ← class_1309 ← class_1657 ← class_746  
   class_1937 ← class_638  
   class_310 with static method_1551()/getInstance() and non-null fields  
   class_2960.method_60655(String,String)

4. **FabricLoader** must be an **interface** with static getInstance() and getConfigDir()/getGameDir() returning Path.

5. **GsonBuilder.create()** must return a Gson instance.

6. Run with `-Xverify:none`.

## How to continue (next account)

```bash
cd harness
java -Xverify:none -Dfile.encoding=UTF-8 -cp . Harness
```

To recover the remaining 1 name (the entry whose String fields currently hold texture paths), improve field selection or inspect that specific module class constructor for the correct decrypt call. Do not restart analysis from the original JAR.

## Recovered names (48)

See mapping/recovered_names_only.txt
