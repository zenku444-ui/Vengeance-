import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import java.io.*;
import java.util.jar.*;
import java.nio.charset.StandardCharsets;

public class DebugFirst {
    static Map<String, byte[]> classBytes = new HashMap<>();
    static Map<String, byte[]> resources = new HashMap<>();
    public static void main(String[] args) throws Exception {
        try (JarFile jf = new JarFile("mochi-classes.jar")) {
            Enumeration<JarEntry> en = jf.entries();
            while (en.hasMoreElements()) {
                JarEntry e = en.nextElement();
                try (InputStream is = jf.getInputStream(e)) {
                    byte[] data = is.readAllBytes();
                    if (e.getName().endsWith(".class")) {
                        String cname = e.getName().substring(0, e.getName().length()-6).replace('/', '.');
                        classBytes.put(cname, data);
                        resources.put(e.getName(), data);
                        resources.put("/" + e.getName(), data);
                    } else {
                        resources.put(e.getName(), data);
                        resources.put("/" + e.getName(), data);
                    }
                }
            }
        }
        ClassLoader cl = new ClassLoader(null) {
            protected Class<?> findClass(String name) throws ClassNotFoundException {
                byte[] b = classBytes.get(name);
                if (b != null) return defineClass(name, b, 0, b.length);
                if (name.startsWith("java.") || name.startsWith("javax.") || name.startsWith("jdk.") || name.startsWith("sun.") || name.startsWith("jdk.internal"))
                    throw new ClassNotFoundException(name);
                return defineClass(name, makeEmpty(name.replace('.', '/')), 0, makeEmpty(name.replace('.', '/')).length);
            }
            public InputStream getResourceAsStream(String name) {
                byte[] b = resources.get(name);
                if (b == null && name.startsWith("/")) b = resources.get(name.substring(1));
                if (b != null) return new ByteArrayInputStream(b);
                return null;
            }
            protected Class<?> loadClass(String name, boolean resolve) throws ClassNotFoundException {
                synchronized (getClassLoadingLock(name)) {
                    Class<?> c = findLoadedClass(name);
                    if (c != null) return c;
                    if (name.startsWith("java.") || name.startsWith("javax.") || name.startsWith("jdk.") || name.startsWith("sun.") || name.startsWith("com.sun.") || name.equals("DebugFirst") || name.startsWith("jdk.internal"))
                        return ClassLoader.getSystemClassLoader().loadClass(name);
                    try { c = findClass(name); }
                    catch (ClassNotFoundException e) {
                        try { c = ClassLoader.getSystemClassLoader().loadClass(name); }
                        catch (ClassNotFoundException e2) {
                            byte[] bc = makeEmpty(name.replace('.', '/'));
                            c = defineClass(name, bc, 0, bc.length);
                        }
                    }
                    if (resolve) resolveClass(c);
                    return c;
                }
            }
        };
        System.out.println("has key: " + classBytes.containsKey("net.minecraft.class_310")); System.out.println("keys sample: " + classBytes.keySet().stream().filter(k -> k.contains("class_310") || k.contains("minecraft")).toList()); Class<?> mc = Class.forName("net.minecraft.class_310", true, cl);
        System.out.println("methods: " + Arrays.toString(mc.getDeclaredMethods()));
        Method m = mc.getMethod("method_1551");
        System.out.println("method_1551: " + m);
        Object inst = m.invoke(null);
        System.out.println("instance: " + inst);

        try { Class.forName("L", true, cl); Class.forName("A", true, cl); System.out.println("A/L OK"); } catch (Throwable t) { t.printStackTrace(); }

        String first = Files.readAllLines(Paths.get("modules.txt"), StandardCharsets.UTF_8).get(0);
        System.out.println("Trying " + first);
        try {
            Class<?> clazz = Class.forName(first, true, cl);
            System.out.println("class init OK");
            Constructor<?> ctor = null;
            for (Constructor<?> c : clazz.getDeclaredConstructors()) if (c.getParameterCount()==0) { ctor=c; break; }
            ctor.setAccessible(true);
            Object o = ctor.newInstance();
            System.out.println("inst OK");
            Class<?> cur = clazz;
            while (cur != null) {
                for (Field f : cur.getDeclaredFields()) {
                    f.setAccessible(true);
                    try {
                        Object v = f.get(o);
                        if (v instanceof String && ((String)v).length() > 0 && ((String)v).length() < 80)
                            System.out.println("NAME CANDIDATE: " + v);
                    } catch (Throwable t) {}
                }
                cur = cur.getSuperclass();
            }
        } catch (Throwable t) {
            t.printStackTrace(System.out);
            Throwable c = t;
            while (c.getCause() != null) { c = c.getCause(); System.out.println("CAUSE: " + c); c.printStackTrace(System.out); }
        }
    }
    static byte[] makeEmpty(String internal) {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            DataOutputStream o = new DataOutputStream(baos);
            o.writeInt(0xCAFEBABE); o.writeShort(0); o.writeShort(65); o.writeShort(10);
            writeUtf(o, internal); o.writeByte(7); o.writeShort(1);
            writeUtf(o, "java/lang/Object"); o.writeByte(7); o.writeShort(3);
            writeUtf(o, "<init>"); writeUtf(o, "()V"); writeUtf(o, "Code");
            o.writeByte(12); o.writeShort(5); o.writeShort(6);
            o.writeByte(10); o.writeShort(4); o.writeShort(8);
            o.writeShort(0x0021); o.writeShort(2); o.writeShort(4); o.writeShort(0); o.writeShort(0); o.writeShort(1);
            o.writeShort(0x0001); o.writeShort(5); o.writeShort(6); o.writeShort(1); o.writeShort(7);
            byte[] code = new byte[]{0x2a, (byte)0xb7, 0x00, 0x09, (byte)0xb1};
            o.writeInt(2+2+4+code.length+2+2); o.writeShort(1); o.writeShort(1); o.writeInt(code.length); o.write(code); o.writeShort(0); o.writeShort(0); o.writeShort(0);
            return baos.toByteArray();
        } catch (IOException e) { throw new RuntimeException(e); }
    }
    static void writeUtf(DataOutputStream o, String s) throws IOException {
        byte[] b = s.getBytes("UTF-8"); o.writeByte(1); o.writeShort(b.length); o.write(b);
    }
}
