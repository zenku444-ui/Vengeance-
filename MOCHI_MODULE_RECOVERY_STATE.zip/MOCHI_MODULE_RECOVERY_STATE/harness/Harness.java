import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.jar.*;

public class Harness {
    static Map<String, byte[]> classBytes = new HashMap<>();
    static Map<String, byte[]> resources = new HashMap<>();

    public static void main(String[] args) throws Exception {
        try (JarFile jf = new JarFile("mochi-classes.jar")) {
            Enumeration<JarEntry> en = jf.entries();
            while (en.hasMoreElements()) {
                JarEntry e = en.nextElement();
                try (InputStream is = jf.getInputStream(e)) {
                    byte[] data = is.readAllBytes();
                    if (e.getName().endsWith(".class")) {
                        String cname = e.getName().substring(0, e.getName().length()-6).replace('/', '.');
                        classBytes.put(cname, data);
                        resources.put(e.getName(), data);
                        resources.put("/" + e.getName(), data);
                    } else {
                        resources.put(e.getName(), data);
                        resources.put("/" + e.getName(), data);
                    }
                }
            }
        }
        System.out.println("Loaded " + classBytes.size() + " classes, " + resources.size() + " resources");

        ClassLoader cl = new ClassLoader(null) {
            @Override
            protected Class<?> findClass(String name) throws ClassNotFoundException {
                byte[] b = classBytes.get(name);
                if (b != null) return defineClass(name, b, 0, b.length);
                if (name.startsWith("java.") || name.startsWith("javax.") || name.startsWith("jdk.") || name.startsWith("sun.") || name.startsWith("jdk.internal"))
                    throw new ClassNotFoundException(name);
                byte[] bc = makeEmpty(name.replace('.', '/'));
                return defineClass(name, bc, 0, bc.length);
            }
            @Override
            public InputStream getResourceAsStream(String name) {
                byte[] b = resources.get(name);
                if (b == null) b = resources.get(name.startsWith("/") ? name.substring(1) : name);
                if (b != null) return new ByteArrayInputStream(b);
                return super.getResourceAsStream(name);
            }
            @Override
            public URL getResource(String name) {
                if (resources.containsKey(name) || resources.containsKey(name.startsWith("/") ? name.substring(1) : name)) {
                    try { return new URL("memory", null, -1, name, new URLStreamHandler() {
                        protected URLConnection openConnection(URL u) { return new URLConnection(u) {
                            public void connect() {}
                            public InputStream getInputStream() { return getResourceAsStream(u.getFile()); }
                        }; }
                    }); } catch (Exception e) {}
                }
                return super.getResource(name);
            }
            @Override
            protected Class<?> loadClass(String name, boolean resolve) throws ClassNotFoundException {
                synchronized (getClassLoadingLock(name)) {
                    Class<?> c = findLoadedClass(name);
                    if (c != null) return c;
                    if (name.startsWith("java.") || name.startsWith("javax.") || name.startsWith("jdk.") ||
                        name.startsWith("sun.") || name.startsWith("com.sun.") || name.equals("Harness") ||
                        name.startsWith("jdk.internal")) {
                        return ClassLoader.getSystemClassLoader().loadClass(name);
                    }
                    try { c = findClass(name); }
                    catch (ClassNotFoundException e) {
                        try { c = ClassLoader.getSystemClassLoader().loadClass(name); }
                        catch (ClassNotFoundException e2) {
                            byte[] bc = makeEmpty(name.replace('.', '/'));
                            c = defineClass(name, bc, 0, bc.length);
                        }
                    }
                    if (resolve) resolveClass(c);
                    return c;
                }
            }
        };

        try { Class.forName("L", true, cl); System.out.println("L init OK"); }
        catch (Throwable t) { System.out.println("L init FAIL: " + t); if (t.getCause()!=null) System.out.println("  cause: " + t.getCause()); }

        List<String> modules = Files.readAllLines(Paths.get("modules.txt"), StandardCharsets.UTF_8);
        int ok = 0;
        for (String modName : modules) {
            if (modName.trim().isEmpty()) continue;
            try {
                Class<?> clazz = Class.forName(modName, false, cl);
                Class<?> sup = clazz.getSuperclass();
                if (sup == null || (!sup.getName().contains("ǜ") && !sup.getName().endsWith("ǜ"))) continue;

                Constructor<?> ctor = null;
                for (Constructor<?> c : clazz.getDeclaredConstructors()) {
                    if (c.getParameterCount() == 0) { ctor = c; break; }
                }
                if (ctor == null) { System.out.println("NO_CTOR|" + modName); continue; }
                ctor.setAccessible(true);
                Object inst;
                try {
                    inst = ctor.newInstance();
                } catch (InvocationTargetException ite) {
                    Throwable c = ite.getCause() != null ? ite.getCause() : ite;
                    System.out.println("CTOR_EX|" + modName + "|" + c.getClass().getSimpleName() + ":" + String.valueOf(c.getMessage()).replace("\n"," ").substring(0, Math.min(180, String.valueOf(c.getMessage()).length())));
                    continue;
                } catch (Throwable t) {
                    System.out.println("CTOR_FAIL|" + modName + "|" + t.getClass().getSimpleName() + ":" + t.getMessage());
                    continue;
                }

                String displayName = null, desc = null, cat = null;
                Class<?> cur = clazz;
                while (cur != null && !cur.getName().equals("java.lang.Object")) {
                    for (Field f : cur.getDeclaredFields()) {
                        f.setAccessible(true);
                        try {
                            Object v = f.get(inst);
                            if (v == null) continue;
                            if (f.getType() == String.class) {
                                String s = (String) v;
                                if (s.length() > 0 && s.length() < 80 && !s.contains("\0")) {
                                    if (displayName == null) displayName = s;
                                    else if (desc == null && !s.equals(displayName)) desc = s;
                                }
                            } else if (f.getType().isEnum()) {
                                cat = v.toString();
                            }
                        } catch (Throwable ignored) {}
                    }
                    cur = cur.getSuperclass();
                }
                for (Method m : clazz.getMethods()) {
                    if (m.getParameterCount() == 0 && m.getReturnType() == String.class) {
                        try {
                            Object v = m.invoke(inst);
                            if (v != null) {
                                String s = (String) v;
                                if (displayName == null) displayName = s;
                                else if (desc == null && !s.equals(displayName)) desc = s;
                            }
                        } catch (Throwable ignored) {}
                    }
                }
                if (displayName != null) {
                    System.out.println("OK|" + displayName + "|" + (desc==null?"":desc) + "|" + (cat==null?"":cat) + "|" + modName);
                    ok++;
                } else {
                    System.out.println("NO_NAME|" + modName);
                }
            } catch (Throwable t) {
                String msg = t.getClass().getSimpleName();
                if (t.getMessage() != null) msg += ":" + t.getMessage().replace("\n"," ").substring(0, Math.min(120, t.getMessage().length()));
                if (t.getCause() != null) msg += " cause:" + t.getCause().getClass().getSimpleName();
                System.out.println("FAIL|" + modName + "|" + msg);
            }
        }
        System.out.println("TOTAL_OK=" + ok);
    }

    static byte[] makeEmpty(String internal) {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            DataOutputStream o = new DataOutputStream(baos);
            o.writeInt(0xCAFEBABE); o.writeShort(0); o.writeShort(65); o.writeShort(10);
            writeUtf(o, internal); o.writeByte(7); o.writeShort(1);
            writeUtf(o, "java/lang/Object"); o.writeByte(7); o.writeShort(3);
            writeUtf(o, "<init>"); writeUtf(o, "()V"); writeUtf(o, "Code");
            o.writeByte(12); o.writeShort(5); o.writeShort(6);
            o.writeByte(10); o.writeShort(4); o.writeShort(8);
            o.writeShort(0x0021); o.writeShort(2); o.writeShort(4); o.writeShort(0); o.writeShort(0); o.writeShort(1);
            o.writeShort(0x0001); o.writeShort(5); o.writeShort(6); o.writeShort(1); o.writeShort(7);
            byte[] code = new byte[]{0x2a, (byte)0xb7, 0x00, 0x09, (byte)0xb1};
            o.writeInt(2+2+4+code.length+2+2); o.writeShort(1); o.writeShort(1); o.writeInt(code.length); o.write(code); o.writeShort(0); o.writeShort(0); o.writeShort(0);
            return baos.toByteArray();
        } catch (IOException e) { throw new RuntimeException(e); }
    }
    static void writeUtf(DataOutputStream o, String s) throws IOException {
        byte[] b = s.getBytes("UTF-8"); o.writeByte(1); o.writeShort(b.length); o.write(b);
    }
}
