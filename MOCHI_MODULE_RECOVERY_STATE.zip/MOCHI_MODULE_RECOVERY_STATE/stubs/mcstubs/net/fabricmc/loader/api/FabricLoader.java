package net.fabricmc.loader.api;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;
public interface FabricLoader {
  static FabricLoader getInstance() {
    return new FabricLoader() {};
  }
  default Object getModContainer(String id) { return null; }
  default Path getConfigDir() { return Paths.get("."); }
  default Path getGameDir() { return Paths.get("."); }
  default Optional getModContainerOpt(String id) { return Optional.empty(); }
}
