
package net.minecraft;
public class class_1297 {
  public class_1297() {}
  public boolean method_5805() { return false; }
  public double method_23317() { return 0; }
  public double method_23318() { return 0; }
  public double method_23321() { return 0; }
}
