
package net.minecraft;
public class class_1309 extends class_1297 {
  public class_1309() {}
  public float method_6032() { return 20f; }
  public boolean method_29504() { return false; }
}
