
package net.minecraft;
public class class_1657 extends class_1309 {
  public class_1657() {}
  public String method_7334() { return ""; }
}
