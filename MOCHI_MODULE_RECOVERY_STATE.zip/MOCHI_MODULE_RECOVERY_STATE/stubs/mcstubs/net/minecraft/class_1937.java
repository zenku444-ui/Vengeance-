
package net.minecraft;
public class class_1937 {
  public class_1937() {}
}
