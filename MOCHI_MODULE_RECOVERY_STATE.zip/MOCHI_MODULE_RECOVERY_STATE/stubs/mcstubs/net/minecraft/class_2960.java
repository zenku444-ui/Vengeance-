package net.minecraft;
public class class_2960 {
  public class_2960(String ns, String path) {}
  public static class_2960 method_60655(String ns, String path) { return new class_2960(ns, path); }
  public static class_2960 method_60654(String s) { return new class_2960("minecraft", s); }
  public String toString() { return "id"; }
}
