
package net.minecraft;
public class class_310 {
  private static final class_310 INSTANCE = new class_310();
  public class_746 field_1724 = new class_746();
  public class_638 field_1687 = new class_638();
  public Object field_1755;
  public Object field_1773;
  public Object field_1729;
  public Object field_1761;
  public Object field_1769;
  public Object field_1690;
  public boolean field_1756;
  public class_310() {}
  public static class_310 method_1551() { return INSTANCE; }
  public static class_310 getInstance() { return INSTANCE; }
}
