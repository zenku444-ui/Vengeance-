
package net.minecraft;
public class class_638 extends class_1937 {
  public class_638() {}
}
