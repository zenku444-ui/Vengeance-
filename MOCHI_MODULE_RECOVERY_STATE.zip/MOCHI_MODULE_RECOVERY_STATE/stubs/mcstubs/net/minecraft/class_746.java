
package net.minecraft;
public class class_746 extends class_1657 {
  public class_746() {}
  public void method_31483() {}
}
