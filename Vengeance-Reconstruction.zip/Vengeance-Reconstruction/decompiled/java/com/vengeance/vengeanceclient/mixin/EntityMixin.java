/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1313
 *  net.minecraft.class_1657
 *  net.minecraft.class_1937
 *  net.minecraft.class_2338
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_2680
 *  net.minecraft.class_310
 *  net.minecraft.class_4048
 *  net.minecraft.class_4050
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package com.vengeance.vengeanceclient.mixin;

import com.vengeance.vengeanceclient.r.q.q.zl;
import com.vengeance.vengeanceclient.r.q.u.zm;
import net.minecraft.class_1297;
import net.minecraft.class_1313;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4048;
import net.minecraft.class_4050;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_1297.class})
public abstract class EntityMixin {
    @Shadow
    public abstract class_2338 method_43260();

    @Shadow
    public abstract boolean method_24828();

    @Shadow
    public abstract class_1937 method_73183();

    @Shadow
    protected abstract void method_5623(double var1, boolean var3, class_2680 var4, class_2338 var5);

    @Shadow
    public abstract class_4048 method_18377(class_4050 var1);

    @Inject(method={"method_5851()Z"}, at={@At(value="HEAD")}, cancellable=true)
    private void onIsGlowing(CallbackInfoReturnable<Boolean> callbackInfoReturnable) {
        class_1297 class_12972;
        zm zm2 = zm.n();
        if (zm2 != null && zm2.l() && zm2.a(class_12972 = (class_1297)this)) {
            callbackInfoReturnable.setReturnValue((Object)true);
        }
    }

    @Inject(method={"method_22861()I"}, at={@At(value="HEAD")})
    private void onGetTeamColorValue(CallbackInfoReturnable<Integer> callbackInfoReturnable) {
    }

    @Inject(method={"method_5784(Lnet/minecraft/class_1313;Lnet/minecraft/class_243;)V"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_1297;method_31481()Z")})
    private void onMove(class_1313 class_13132, class_243 class_2432, CallbackInfo callbackInfo) {
        if (this.method_73183().method_8608()) {
            class_2338 class_23382 = this.method_43260();
            class_2680 class_26802 = this.method_73183().method_8320(class_23382);
            this.method_5623(class_2432.field_1351, this.method_24828(), class_26802, class_23382);
        }
    }

    @Inject(method={"method_5829()Lnet/minecraft/class_238;"}, at={@At(value="RETURN")}, cancellable=true)
    private void onGetBoundingBox(CallbackInfoReturnable<class_238> callbackInfoReturnable) {
        float f;
        if (!zl.a()) {
            return;
        }
        class_1297 class_12972 = (class_1297)this;
        class_310 class_3102 = class_310.method_1551();
        if (class_3102.field_1724 != null && class_12972 instanceof class_1657 && class_12972 != class_3102.field_1724 && (f = com.vengeance.vengeanceclient.r.q.q.zm.o()) > 0.0f) {
            class_238 class_2382 = (class_238)callbackInfoReturnable.getReturnValue();
            callbackInfoReturnable.setReturnValue((Object)class_2382.method_1014((double)f));
        }
    }
}

