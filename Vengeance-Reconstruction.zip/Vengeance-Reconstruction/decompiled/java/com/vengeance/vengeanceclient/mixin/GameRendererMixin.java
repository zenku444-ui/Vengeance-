/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.class_243
 *  net.minecraft.class_310
 *  net.minecraft.class_4184
 *  net.minecraft.class_4587
 *  net.minecraft.class_757
 *  net.minecraft.class_7833
 *  net.minecraft.class_9779
 *  org.joml.Matrix4f
 *  org.joml.Matrix4fc
 *  org.joml.Quaternionfc
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.ModifyArgs
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.invoke.arg.Args
 */
package com.vengeance.vengeanceclient.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import com.vengeance.vengeanceclient.VengeanceClient;
import com.vengeance.vengeanceclient.p.p.t.zb;
import com.vengeance.vengeanceclient.r.q.u.zc;
import com.vengeance.vengeanceclient.utils.w.q.q.zd;
import com.vengeance.vengeanceclient.utils.w.zr;
import java.lang.reflect.Method;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_7833;
import net.minecraft.class_9779;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Quaternionfc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin(value={class_757.class})
public class GameRendererMixin {
    @ModifyArgs(method={"method_22973(F)Lorg/joml/Matrix4f;"}, at=@At(value="INVOKE", target="Lorg/joml/Matrix4f;perspective(FFFF)Lorg/joml/Matrix4f;"))
    private void modifyAspectRatio(Args args) {
        float f = zc.o();
        if (f > 0.0f) {
            args.set(1, (Object)Float.valueOf(f));
        }
    }

    @Inject(method={"method_3188(Lnet/minecraft/class_9779;)V"}, at={@At(value="HEAD")})
    private void renderHand(class_9779 class_97792, CallbackInfo callbackInfo) {
        class_310 class_3102 = class_310.method_1551();
        class_4184 class_41842 = class_3102.field_1773.method_19418();
        float f = class_97792.method_60637(true);
        class_4587 class_45872 = new class_4587();
        class_45872.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(class_41842.method_19329()));
        class_45872.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees(class_41842.method_19330() + 180.0f));
        class_243 class_2432 = class_41842.method_71156();
        class_45872.method_22904(-class_2432.field_1352, -class_2432.field_1351, -class_2432.field_1350);
        GameRendererMixin.captureProjectionData(class_3102, class_45872, f);
        VengeanceClient.INSTANCE.getEventBus().post(new zb(class_45872));
    }

    private static void captureProjectionData(class_310 class_3102, class_4587 class_45872, float f) {
        Matrix4f matrix4f;
        Matrix4f matrix4f2 = GameRendererMixin.invokeGameRendererProjection(class_3102.field_1773, f);
        if (matrix4f2 == null) {
            matrix4f2 = GameRendererMixin.invokeRenderSystemMatrix("getProjectionMatrix");
        }
        if (matrix4f2 != null) {
            zr.a.set((Matrix4fc)matrix4f2);
            zd.a.set((Matrix4fc)matrix4f2);
        }
        if ((matrix4f = GameRendererMixin.invokeRenderSystemMatrix("getModelViewMatrix")) != null) {
            zr.b.set((Matrix4fc)matrix4f);
            zd.b.set((Matrix4fc)matrix4f);
        }
        Matrix4f matrix4f3 = class_45872.method_23760().method_23761();
        zr.c.set((Matrix4fc)matrix4f3);
        zd.c.set((Matrix4fc)matrix4f3);
    }

    private static Matrix4f invokeGameRendererProjection(class_757 class_7572, float f) {
        try {
            Method method = class_757.class.getDeclaredMethod("getProjectionMatrix", Float.TYPE);
            method.setAccessible(true);
            Object object = method.invoke((Object)class_7572, Float.valueOf(f));
            if (object instanceof Matrix4f) {
                Matrix4f matrix4f = (Matrix4f)object;
                return new Matrix4f((Matrix4fc)matrix4f);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        try {
            return new Matrix4f((Matrix4fc)class_7572.method_22973(70.0f));
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    private static Matrix4f invokeRenderSystemMatrix(String string) {
        try {
            Object object = RenderSystem.class.getMethod(string, new Class[0]).invoke(null, new Object[0]);
            if (object instanceof Matrix4f) {
                Matrix4f matrix4f = (Matrix4f)object;
                return new Matrix4f((Matrix4fc)matrix4f);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return null;
    }
}

