/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1735
 *  net.minecraft.class_1802
 *  net.minecraft.class_332
 *  net.minecraft.class_4587
 *  net.minecraft.class_465
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package com.vengeance.vengeanceclient.mixin;

import com.vengeance.vengeanceclient.VengeanceClient;
import com.vengeance.vengeanceclient.r.q.u.ze;
import com.vengeance.vengeanceclient.utils.w.q.za;
import net.minecraft.class_1735;
import net.minecraft.class_1802;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_465.class})
public class HandledScreenMixin {
    @Inject(method={"method_2385(Lnet/minecraft/class_332;Lnet/minecraft/class_1735;II)V"}, at={@At(value="TAIL")})
    public void postDrawSlot(class_332 class_3322, class_1735 class_17352, int n, int n2, CallbackInfo callbackInfo) {
        if (!VengeanceClient.INSTANCE.moduleManager.a(ze.class).get().l()) {
            return;
        }
        if (ze.e.b() && class_17352.method_7681() && class_17352.method_7677().method_7909() == class_1802.field_8288) {
            class_3322.method_25294(class_17352.field_7873, class_17352.field_7872, class_17352.field_7873 + 16, class_17352.field_7872 + 16, ze.f.h().getRGB());
        }
        if (ze.d.b()) {
            return;
        }
        if (ze.b.b("Inter")) {
            VengeanceClient.INSTANCE.fontManager.a(10, za.zb.a).a(new class_4587(), String.valueOf(class_17352.method_34266()), class_17352.field_7873, class_17352.field_7872, ze.c.h());
        } else {
            class_3322.method_51433(VengeanceClient.mc.field_1772, String.valueOf(class_17352.method_34266()), class_17352.field_7873, class_17352.field_7872, ze.c.h().getRGB(), false);
        }
    }
}

