/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.opengl.GlStateManager
 *  net.minecraft.class_329
 *  net.minecraft.class_332
 *  net.minecraft.class_9779
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package com.vengeance.vengeanceclient.mixin;

import com.mojang.blaze3d.opengl.GlStateManager;
import com.vengeance.vengeanceclient.VengeanceClient;
import com.vengeance.vengeanceclient.p.p.t.za;
import com.vengeance.vengeanceclient.utils.w.zn;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_329.class})
public class InGameHudMixin {
    @Inject(method={"method_1753(Lnet/minecraft/class_332;Lnet/minecraft/class_9779;)V"}, at={@At(value="TAIL")})
    private void onRender(class_332 class_3322, class_9779 class_97792, CallbackInfo callbackInfo) {
        zn.a();
        zn.b();
        GlStateManager._disableDepthTest();
        GlStateManager._enableBlend();
        GlStateManager._blendFuncSeparate((int)770, (int)771, (int)1, (int)771);
        GlStateManager._disableCull();
        if (com.vengeance.vengeanceclient.utils.w.r.za.a(class_3322)) {
            VengeanceClient.INSTANCE.getEventBus().post(new za(class_3322, class_3322.method_51421(), class_3322.method_51443()));
            com.vengeance.vengeanceclient.utils.w.r.za.e();
        }
        GlStateManager._enableDepthTest();
        GlStateManager._enableCull();
    }
}

