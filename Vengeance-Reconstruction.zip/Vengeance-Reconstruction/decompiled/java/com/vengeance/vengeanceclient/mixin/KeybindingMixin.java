/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_304
 *  net.minecraft.class_3675$class_306
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package com.vengeance.vengeanceclient.mixin;

import com.vengeance.vengeanceclient.VengeanceClient;
import com.vengeance.vengeanceclient.r.q.s.zd;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_304.class})
public class KeybindingMixin {
    @Shadow
    @Final
    private class_3675.class_306 field_1654;
    @Shadow
    private boolean field_1653;

    @Inject(method={"method_1434()Z"}, at={@At(value="HEAD")}, cancellable=true)
    public void onGetPressed(CallbackInfoReturnable<Boolean> callbackInfoReturnable) {
        if (!VengeanceClient.INSTANCE.moduleManager.a(zd.class).get().l()) {
            return;
        }
        if (this.field_1654.method_1444() == 65) {
            if (this.field_1653) {
                if (zd.c == 0L) {
                    callbackInfoReturnable.setReturnValue((Object)true);
                    callbackInfoReturnable.cancel();
                    return;
                }
                callbackInfoReturnable.setReturnValue((Object)(zd.c <= zd.b ? 1 : 0));
                callbackInfoReturnable.cancel();
            }
        } else if (this.field_1654.method_1444() == 68) {
            if (this.field_1653) {
                if (zd.b == 0L) {
                    callbackInfoReturnable.setReturnValue((Object)true);
                    callbackInfoReturnable.cancel();
                    return;
                }
                callbackInfoReturnable.setReturnValue((Object)(zd.b <= zd.c ? 1 : 0));
                callbackInfoReturnable.cancel();
            }
        } else if (this.field_1654.method_1444() == 87) {
            if (this.field_1653) {
                if (zd.e == 0L) {
                    callbackInfoReturnable.setReturnValue((Object)true);
                    callbackInfoReturnable.cancel();
                    return;
                }
                callbackInfoReturnable.setReturnValue((Object)(zd.e <= zd.d ? 1 : 0));
                callbackInfoReturnable.cancel();
            }
        } else if (this.field_1654.method_1444() == 83 && this.field_1653) {
            if (zd.d == 0L) {
                callbackInfoReturnable.setReturnValue((Object)true);
                callbackInfoReturnable.cancel();
                return;
            }
            callbackInfoReturnable.setReturnValue((Object)(zd.d <= zd.e ? 1 : 0));
            callbackInfoReturnable.cancel();
        }
    }

    @Inject(method={"method_23481(Z)V"}, at={@At(value="HEAD")})
    public void setPressed(boolean bl, CallbackInfo callbackInfo) {
        if (!VengeanceClient.INSTANCE.moduleManager.a(zd.class).get().l()) {
            return;
        }
        if (this.field_1654.method_1444() == 65) {
            zd.b = bl ? System.currentTimeMillis() : 0L;
        } else if (this.field_1654.method_1444() == 68) {
            zd.c = bl ? System.currentTimeMillis() : 0L;
        } else if (this.field_1654.method_1444() == 87) {
            zd.d = bl ? System.currentTimeMillis() : 0L;
        } else if (this.field_1654.method_1444() == 83) {
            zd.e = bl ? System.currentTimeMillis() : 0L;
        }
    }
}

