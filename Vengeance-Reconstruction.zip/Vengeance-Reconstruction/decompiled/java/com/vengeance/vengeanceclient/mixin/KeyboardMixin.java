/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_11908
 *  net.minecraft.class_309
 *  net.minecraft.class_310
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package com.vengeance.vengeanceclient.mixin;

import com.vengeance.vengeanceclient.VengeanceClient;
import com.vengeance.vengeanceclient.r.zb;
import com.vengeance.vengeanceclient.utils.r.za;
import net.minecraft.class_11908;
import net.minecraft.class_309;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_309.class})
public class KeyboardMixin {
    @Shadow
    @Final
    private class_310 field_1678;

    @Inject(method={"method_1466(JILnet/minecraft/class_11908;)V"}, at={@At(value="HEAD")})
    private void onPress(long l, int n, class_11908 class_119082, CallbackInfo callbackInfo) {
        int n2 = class_119082.method_74228();
        if (l == this.field_1678.method_22683().method_4490() && this.field_1678.field_1755 == null) {
            for (zb zb2 : VengeanceClient.INSTANCE.moduleManager.b()) {
                if (n2 != zb2.e()) continue;
                if (zb2.h().g()) {
                    if (n == 1 && !zb2.l()) {
                        zb2.a(true);
                        continue;
                    }
                    if (n != 0 || !zb2.l()) continue;
                    zb2.a(false);
                    continue;
                }
                if (n != 1 || !za.b(n2)) continue;
                zb2.a();
            }
        }
    }
}

