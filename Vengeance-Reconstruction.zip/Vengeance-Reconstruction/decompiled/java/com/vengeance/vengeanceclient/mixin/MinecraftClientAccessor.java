/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_310
 *  net.minecraft.class_312
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.gen.Accessor
 *  org.spongepowered.asm.mixin.gen.Invoker
 */
package com.vengeance.vengeanceclient.mixin;

import net.minecraft.class_310;
import net.minecraft.class_312;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(value={class_310.class})
public interface MinecraftClientAccessor {
    @Accessor(value="field_1752")
    public void setItemUseCooldown(int var1);

    @Accessor(value="field_1729")
    public class_312 getMouse();

    @Invoker(value="method_1583")
    public void invokeDoItemUse();

    @Invoker(value="method_1536")
    public boolean invokeDoAttack();
}

