/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_239
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_310
 *  net.minecraft.class_636
 *  net.minecraft.class_638
 *  net.minecraft.class_746
 *  net.minecraft.class_9779$class_9781
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package com.vengeance.vengeanceclient.mixin;

import com.vengeance.vengeanceclient.VengeanceClient;
import com.vengeance.vengeanceclient.p.p.r.za;
import com.vengeance.vengeanceclient.p.p.s.zc;
import com.vengeance.vengeanceclient.p.p.s.zd;
import com.vengeance.vengeanceclient.r.q.q.zb;
import java.util.Optional;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_636;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_310.class})
public class MinecraftClientMixin
implements com.vengeance.vengeanceclient.utils.zb {
    @Shadow
    public class_638 field_1687;
    @Shadow
    public class_239 field_1765;
    @Shadow
    public class_746 field_1724;
    @Shadow
    public class_636 field_1761;
    @Shadow
    @Final
    private class_9779.class_9781 field_52750;

    @Inject(method={"method_24287()Ljava/lang/String;"}, at={@At(value="HEAD")}, cancellable=true)
    public void setTitle(CallbackInfoReturnable<String> callbackInfoReturnable) {
        com.vengeance.vengeanceclient.r.q.p.za za2;
        if (VengeanceClient.INSTANCE == null || VengeanceClient.mc == null) {
            return;
        }
        Optional<com.vengeance.vengeanceclient.r.q.p.za> optional = VengeanceClient.INSTANCE.getModuleManager().a(com.vengeance.vengeanceclient.r.q.p.za.class);
        if (optional.isPresent() && (za2 = optional.get()).l() && za2.n()) {
            callbackInfoReturnable.setReturnValue((Object)"Vengeance Client 1.21.11");
        }
    }

    @Inject(method={"method_1508()V"}, at={@At(value="HEAD")})
    public void ravenZHandleInputEvents(CallbackInfo callbackInfo) {
        if (VengeanceClient.INSTANCE != null) {
            com.vengeance.vengeanceclient.p.p.q.za za2 = new com.vengeance.vengeanceclient.p.p.q.za();
            VengeanceClient.INSTANCE.getEventBus().post(za2);
        }
    }

    @Inject(method={"method_1574()V"}, at={@At(value="HEAD")})
    private void onTick(CallbackInfo callbackInfo) {
        if (VengeanceClient.INSTANCE == null || VengeanceClient.mc == null) {
            return;
        }
        if (this.field_1687 != null) {
            VengeanceClient.INSTANCE.getEventBus().post(new zd());
        }
    }

    @Inject(method={"method_1536()Z"}, at={@At(value="HEAD")}, cancellable=true)
    public final void doAttackInject(CallbackInfoReturnable<Boolean> callbackInfoReturnable) {
        Object object;
        try {
            object = VengeanceClient.INSTANCE.getModuleManager().a(zb.class);
            if (((Optional)object).isPresent() && ((zb)((Optional)object).get()).l() && (this.field_1765 == null || this.field_1765.method_17783() == class_239.class_240.field_1333)) {
                callbackInfoReturnable.setReturnValue((Object)false);
                return;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        object = new com.vengeance.vengeanceclient.p.p.s.zb();
        VengeanceClient.INSTANCE.getEventBus().post(object);
    }

    @Inject(method={"method_1490()V"}, at={@At(value="HEAD")})
    public void stopInject(CallbackInfo callbackInfo) {
        if (VengeanceClient.INSTANCE != null) {
            com.vengeance.vengeanceclient.s.za za2 = VengeanceClient.INSTANCE.getProfileManager();
            za2.a("default", true);
        }
    }

    @Inject(method={"method_18097(Lnet/minecraft/class_638;Z)V"}, at={@At(value="HEAD")})
    public void onWorldChangeInject(class_638 class_6382, boolean bl, CallbackInfo callbackInfo) {
        if (VengeanceClient.INSTANCE != null && VengeanceClient.mc != null) {
            VengeanceClient.INSTANCE.getEventBus().post(new com.vengeance.vengeanceclient.p.p.u.za(class_6382));
        }
    }

    @Inject(method={"method_55505()V"}, at={@At(value="HEAD")})
    public final void onDisconnected(CallbackInfo callbackInfo) {
        za za2 = new za();
        VengeanceClient.INSTANCE.getEventBus().post(za2);
    }

    @Inject(method={"method_1583()V"}, at={@At(value="HEAD")}, cancellable=true)
    public final void doItemUseInject(CallbackInfo callbackInfo) {
        zc zc2 = new zc();
        VengeanceClient.INSTANCE.getEventBus().post(zc2);
        if (zc2.d()) {
            callbackInfo.cancel();
        }
    }
}

