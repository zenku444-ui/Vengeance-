/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_11910
 *  net.minecraft.class_310
 *  net.minecraft.class_312
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package com.vengeance.vengeanceclient.mixin;

import com.vengeance.vengeanceclient.VengeanceClient;
import com.vengeance.vengeanceclient.p.p.q.zb;
import net.minecraft.class_11910;
import net.minecraft.class_310;
import net.minecraft.class_312;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_312.class})
public class MouseMixin {
    @Shadow
    @Final
    private class_310 field_1779;

    @Inject(method={"method_1601(JLnet/minecraft/class_11910;I)V"}, at={@At(value="HEAD")})
    private void onMouseButton(long l, class_11910 class_119102, int n, CallbackInfo callbackInfo) {
        if (VengeanceClient.INSTANCE == null) {
            return;
        }
        if (l != this.field_1779.method_22683().method_4490()) {
            return;
        }
        if (this.field_1779.field_1755 != null) {
            return;
        }
        zb zb2 = new zb(class_119102.comp_4801(), n, class_119102.comp_4797());
        VengeanceClient.INSTANCE.getEventBus().post(zb2);
    }
}

