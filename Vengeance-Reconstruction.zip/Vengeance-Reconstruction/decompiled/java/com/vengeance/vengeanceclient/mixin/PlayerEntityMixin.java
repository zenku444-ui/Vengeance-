/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1657
 *  net.minecraft.class_2680
 *  net.minecraft.class_310
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package com.vengeance.vengeanceclient.mixin;

import com.vengeance.vengeanceclient.VengeanceClient;
import com.vengeance.vengeanceclient.r.q.s.zc;
import com.vengeance.vengeanceclient.r.q.t.zk;
import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_1657.class})
public class PlayerEntityMixin {
    @Inject(method={"method_7351(Lnet/minecraft/class_2680;)F"}, at={@At(value="RETURN")}, cancellable=true)
    private void modifyBlockBreakingSpeed(class_2680 class_26802, CallbackInfoReturnable<Float> callbackInfoReturnable) {
        if (VengeanceClient.INSTANCE == null) {
            return;
        }
        Optional<zk> optional = VengeanceClient.INSTANCE.getModuleManager().a(zk.class);
        if (optional.isEmpty()) {
            return;
        }
        zk zk2 = optional.get();
        if (!zk2.l()) {
            return;
        }
        class_1657 class_16572 = (class_1657)this;
        if (class_16572 != class_310.method_1551().field_1724) {
            return;
        }
        float f = ((Float)callbackInfoReturnable.getReturnValue()).floatValue() * zk2.n();
        callbackInfoReturnable.setReturnValue((Object)Float.valueOf(f));
    }

    @Inject(method={"method_7324(Lnet/minecraft/class_1297;)V"}, at={@At(value="TAIL")})
    private void keepSprintTail(class_1297 class_12972, CallbackInfo callbackInfo) {
        class_1657 class_16572;
        if (VengeanceClient.INSTANCE == null) {
            return;
        }
        Optional<zc> optional = VengeanceClient.INSTANCE.getModuleManager().a(zc.class);
        if (optional.isPresent() && optional.get().l() && (class_16572 = (class_1657)this) == class_310.method_1551().field_1724) {
            class_16572.method_5728(true);
        }
    }
}

