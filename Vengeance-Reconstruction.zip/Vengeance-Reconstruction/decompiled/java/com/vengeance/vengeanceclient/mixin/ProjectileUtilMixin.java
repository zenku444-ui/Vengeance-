/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1675
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_3966
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package com.vengeance.vengeanceclient.mixin;

import com.vengeance.vengeanceclient.r.q.q.zl;
import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_1675;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3966;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_1675.class})
public class ProjectileUtilMixin {
    @Inject(method={"method_18075(Lnet/minecraft/class_1297;Lnet/minecraft/class_243;Lnet/minecraft/class_243;Lnet/minecraft/class_238;Ljava/util/function/Predicate;D)Lnet/minecraft/class_3966;"}, at={@At(value="HEAD")})
    private static void onRaycastStart(class_1297 class_12972, class_243 class_2432, class_243 class_2433, class_238 class_2382, Predicate<class_1297> predicate, double d, CallbackInfoReturnable<class_3966> callbackInfoReturnable) {
        zl.a(true);
    }

    @Inject(method={"method_18075(Lnet/minecraft/class_1297;Lnet/minecraft/class_243;Lnet/minecraft/class_243;Lnet/minecraft/class_238;Ljava/util/function/Predicate;D)Lnet/minecraft/class_3966;"}, at={@At(value="RETURN")})
    private static void onRaycastEnd(class_1297 class_12972, class_243 class_2432, class_243 class_2433, class_238 class_2382, Predicate<class_1297> predicate, double d, CallbackInfoReturnable<class_3966> callbackInfoReturnable) {
        zl.a(false);
    }
}

