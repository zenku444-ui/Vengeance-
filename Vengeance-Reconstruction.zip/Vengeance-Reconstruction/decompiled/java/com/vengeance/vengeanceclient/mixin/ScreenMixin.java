/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.opengl.GlStateManager
 *  net.minecraft.class_310
 *  net.minecraft.class_332
 *  net.minecraft.class_437
 *  org.jetbrains.annotations.Nullable
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package com.vengeance.vengeanceclient.mixin;

import com.mojang.blaze3d.opengl.GlStateManager;
import com.vengeance.vengeanceclient.q.zc;
import com.vengeance.vengeanceclient.r.q.p.zb;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_437.class})
public abstract class ScreenMixin {
    @Shadow
    @Nullable
    protected class_310 field_22787;

    @Inject(method={"method_25420(Lnet/minecraft/class_332;IIF)V"}, at={@At(value="HEAD")}, cancellable=true)
    private void renderBackgroundInject(class_332 class_3322, int n, int n2, float f, CallbackInfo callbackInfo) {
        if (this.field_22787 == null) {
            return;
        }
        class_437 class_4372 = this.field_22787.field_1755;
        if (class_4372 instanceof zc && !zb.r()) {
            callbackInfo.cancel();
        }
    }

    @Inject(method={"method_25394(Lnet/minecraft/class_332;IIF)V"}, at={@At(value="TAIL")})
    private void onRenderTail(class_332 class_3322, int n, int n2, float f, CallbackInfo callbackInfo) {
        if (this.field_22787 == null) {
            return;
        }
        class_437 class_4372 = this.field_22787.field_1755;
        if (class_4372 instanceof zc) {
            GlStateManager._enableBlend();
            GlStateManager._blendFuncSeparate((int)770, (int)771, (int)1, (int)771);
            GlStateManager._enableDepthTest();
            GlStateManager._depthFunc((int)515);
            GlStateManager._enableCull();
            GlStateManager._disableScissorTest();
            GlStateManager._colorMask((boolean)true, (boolean)true, (boolean)true, (boolean)true);
            GlStateManager._depthMask((boolean)true);
        }
    }
}

