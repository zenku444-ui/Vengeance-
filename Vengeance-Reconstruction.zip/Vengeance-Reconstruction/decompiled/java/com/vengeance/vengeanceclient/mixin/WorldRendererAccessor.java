/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_276
 *  net.minecraft.class_761
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.gen.Accessor
 *  org.spongepowered.asm.mixin.gen.Invoker
 */
package com.vengeance.vengeanceclient.mixin;

import net.minecraft.class_276;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(value={class_761.class})
public interface WorldRendererAccessor {
    @Accessor(value="field_53080")
    public class_276 getEntityOutlineFramebuffer();

    @Invoker(value="method_3270")
    public boolean invokeCanDrawEntityOutlines();
}

