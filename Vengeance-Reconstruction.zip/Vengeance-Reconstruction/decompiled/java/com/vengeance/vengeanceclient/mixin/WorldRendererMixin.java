/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_276
 *  net.minecraft.class_310
 *  net.minecraft.class_761
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package com.vengeance.vengeanceclient.mixin;

import com.vengeance.vengeanceclient.r.q.u.zf;
import com.vengeance.vengeanceclient.utils.w.zl;
import java.awt.Color;
import net.minecraft.class_276;
import net.minecraft.class_310;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_761.class})
public abstract class WorldRendererMixin {
    @Shadow
    @Final
    private class_310 field_4088;
    @Shadow
    private class_276 field_53080;

    @Inject(method={"method_3254()V"}, at={@At(value="HEAD")}, cancellable=true)
    private void onDrawEntityOutlines(CallbackInfo callbackInfo) {
        zf zf2 = zf.n();
        if (zf2 == null || !zf2.l()) {
            return;
        }
        if (this.field_53080 == null) {
            return;
        }
        zf2.o();
        Color color = zf2.p().stream().findFirst().map(zf2::b).orElse(new Color(255, 50, 50));
        zl.a(this.field_53080, color, zf2.q(), zf2.r(), zf2.s(), zf2.t());
        callbackInfo.cancel();
    }
}

