/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2596
 */
package com.vengeance.vengeanceclient.p.p.r;

import com.vengeance.vengeanceclient.p.q.za;
import com.vengeance.vengeanceclient.p.q.zc;
import net.minecraft.class_2596;

public class zb
extends za {
    private final zc a;
    private class_2596 b;

    public zb(class_2596 class_25962, zc zc2) {
        this.b = class_25962;
        this.a = zc2;
    }

    public zc a() {
        return this.a;
    }

    public class_2596 b() {
        return this.b;
    }

    public void a(class_2596 class_25962) {
        this.b = class_25962;
    }
}

