/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 */
package com.vengeance.vengeanceclient.p.p.s;

import net.minecraft.class_1297;

public class za
extends com.vengeance.vengeanceclient.p.q.za {
    class_1297 a;

    public za(class_1297 class_12972) {
        this.a = class_12972;
    }

    public class_1297 a() {
        return this.a;
    }
}

