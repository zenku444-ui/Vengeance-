/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_332
 */
package com.vengeance.vengeanceclient.p.p.t;

import com.vengeance.vengeanceclient.p.q.zb;
import net.minecraft.class_332;

public class za
implements zb {
    private class_332 a;
    private int b;
    private int c;

    public za(class_332 class_3322, int n, int n2) {
        this.a = class_3322;
        this.b = n;
        this.c = n2;
    }

    public class_332 a() {
        return this.a;
    }

    public int b() {
        return this.b;
    }

    public int c() {
        return this.c;
    }

    public void a(class_332 class_3322) {
        this.a = class_3322;
    }

    public void a(int n) {
        this.b = n;
    }

    public void b(int n) {
        this.c = n;
    }
}

