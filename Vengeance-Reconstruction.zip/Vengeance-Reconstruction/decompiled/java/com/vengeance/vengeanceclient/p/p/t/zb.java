/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_4587
 */
package com.vengeance.vengeanceclient.p.p.t;

import net.minecraft.class_4587;

public class zb
implements com.vengeance.vengeanceclient.p.q.zb {
    class_4587 a;

    public zb(class_4587 class_45872) {
        this.a = class_45872;
    }

    public class_4587 a() {
        return this.a;
    }
}

