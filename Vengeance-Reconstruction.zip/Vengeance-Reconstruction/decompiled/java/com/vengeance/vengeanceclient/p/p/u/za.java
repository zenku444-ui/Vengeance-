/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_638
 */
package com.vengeance.vengeanceclient.p.p.u;

import com.vengeance.vengeanceclient.p.q.zb;
import net.minecraft.class_638;

public class za
implements zb {
    class_638 a;

    public za(class_638 class_6382) {
        this.a = class_6382;
    }

    public class_638 a() {
        return this.a;
    }
}

