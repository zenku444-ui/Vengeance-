/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2561
 *  net.minecraft.class_310
 *  net.minecraft.class_332
 *  net.minecraft.class_342
 *  net.minecraft.class_364
 *  net.minecraft.class_4185
 *  net.minecraft.class_437
 */
package com.vengeance.vengeanceclient.q;

import com.vengeance.vengeanceclient.utils.p.za;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class za
extends class_437 {
    private class_342 a;
    private String b = "";
    private boolean c = false;
    private class_4185 d;

    public za() {
        super((class_2561)class_2561.method_43470((String)"Vengeance Client - Authentication"));
    }

    protected void method_25426() {
        super.method_25426();
        int n = this.field_22789 / 2;
        int n2 = this.field_22790 / 2;
        this.a = new class_342(this.field_22793, n - 150, n2 - 30, 300, 40, (class_2561)class_2561.method_43470((String)"Enter License Key"));
        this.a.method_1880(50);
        String string = com.vengeance.vengeanceclient.utils.p.za.b().g();
        if (string != null) {
            this.a.method_1852(string);
        }
        this.method_37063((class_364)this.a);
        this.d = class_4185.method_46430((class_2561)class_2561.method_43470((String)"LOGIN"), class_41852 -> this.a()).method_46434(n - 150, n2 + 30, 300, 40).method_46431();
        this.method_37063((class_364)this.d);
    }

    public void method_25394(class_332 class_3322, int n, int n2, float f) {
        class_3322.method_25294(0, 0, this.field_22789, this.field_22790, -871691502);
        int n3 = this.field_22789 / 2;
        int n4 = this.field_22790 / 2;
        class_3322.method_25294(n3 - 200, n4 - 100, n3 + 200, n4 + 150, -15066578);
        class_3322.method_25294(n3 - 200, n4 - 100, n3 + 200, n4 - 90, -9753253);
        class_3322.method_25294(n3 - 200, n4 + 140, n3 + 200, n4 + 150, -9753253);
        class_3322.method_25300(this.field_22793, "Vengeance Client", n3, n4 - 80, -9753253);
        class_3322.method_25300(this.field_22793, "Authentication Required", n3, n4 - 60, -5592406);
        class_3322.method_25300(this.field_22793, "Enter your license key to continue", n3, n4 - 45, -7829368);
        if (!this.b.isEmpty()) {
            int n5 = -43691;
            if (this.b.toLowerCase().contains("welcome") || this.b.toLowerCase().contains("success")) {
                n5 = -11141291;
            }
            class_3322.method_25300(this.field_22793, this.b, n3, n4 - 10, n5);
        }
        if (this.c) {
            class_3322.method_25300(this.field_22793, "Authenticating...", n3, n4 + 75, -171);
        }
        super.method_25394(class_3322, n, n2, f);
    }

    private void a() {
        if (this.c) {
            return;
        }
        String string = this.a.method_1882().trim();
        if (string.isEmpty()) {
            this.b = "Please enter a license key";
            return;
        }
        if (!string.startsWith("VNG-")) {
            this.b = "Invalid key format";
            return;
        }
        this.c = true;
        this.b = "";
        this.d.method_25355((class_2561)class_2561.method_43470((String)"AUTHENTICATING..."));
        com.vengeance.vengeanceclient.utils.p.za.b().a(string, new za.za(){

            @Override
            public void a(String string, String string2) {
                za.this.c = false;
                za.this.b = "Welcome! Tier: " + string2;
                if (class_310.method_1551() != null && class_310.method_1551().field_1724 != null) {
                    class_310.method_1551().execute(() -> {
                        try {
                            Thread.sleep(1500L);
                        }
                        catch (InterruptedException interruptedException) {
                            // empty catch block
                        }
                        if (class_310.method_1551().field_1755 instanceof za) {
                            class_310.method_1551().method_1507(null);
                        }
                    });
                }
            }

            @Override
            public void a(String string) {
                za.this.c = false;
                za.this.b = "Error: " + string;
                za.this.d.method_25355((class_2561)class_2561.method_43470((String)"LOGIN"));
            }
        });
    }

    public boolean method_25422() {
        return false;
    }

    public void method_25419() {
    }
}

