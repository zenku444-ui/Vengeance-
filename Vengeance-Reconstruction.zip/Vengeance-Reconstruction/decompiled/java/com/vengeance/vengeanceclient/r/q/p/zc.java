/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2596
 *  net.minecraft.class_2813
 */
package com.vengeance.vengeanceclient.r.q.p;

import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2596;
import net.minecraft.class_2813;

public class zc
extends zb {
    public zc() {
        super("Debugger", "Debugs inv packets (dev purposes)", -1, za.f);
    }

    @EventHandler
    public void onPacketSend(com.vengeance.vengeanceclient.p.p.r.zb zb2) {
        if (this.d()) {
            return;
        }
        if (zb2.b() == null) {
            return;
        }
        class_2596 class_25962 = zb2.b();
        if (!(class_25962 instanceof class_2813)) {
            return;
        }
        class_2813 class_28132 = (class_2813)class_25962;
        com.vengeance.vengeanceclient.utils.t.za.e("ClickSlotPacket\n  syncId: %s\n  revision: %s\n  slot: %s\n  button: %s\n  actionType: %s\n  modifiedItems: %s\n  cursor: %s\n".formatted(class_28132.comp_3842(), class_28132.comp_3843(), class_28132.comp_3844(), class_28132.comp_3845(), class_28132.comp_3846(), class_28132.comp_3847(), class_28132.comp_3848()));
    }
}

