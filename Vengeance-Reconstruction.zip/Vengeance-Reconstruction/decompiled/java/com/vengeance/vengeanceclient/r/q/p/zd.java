/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_437
 */
package com.vengeance.vengeanceclient.r.q.p;

import com.vengeance.vengeanceclient.q.zc;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import java.awt.Color;
import net.minecraft.class_437;

public class zd
extends zb {
    public zd() {
        super("RichModernGUI", "Rich Modern ClickGUI", 344, za.f);
    }

    @Override
    public void b() {
        if (zd.a.field_1755 == null) {
            a.method_1507((class_437)new zc());
        }
        this.a(false);
    }

    public static Color n() {
        return com.vengeance.vengeanceclient.r.q.p.zb.n();
    }
}

