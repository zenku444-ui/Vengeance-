/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_1743
 *  net.minecraft.class_1792
 *  net.minecraft.class_239
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_243
 *  net.minecraft.class_3489
 *  net.minecraft.class_3532
 *  net.minecraft.class_3966
 */
package com.vengeance.vengeanceclient.r.q.q;

import com.vengeance.vengeanceclient.r.q.r.zh;
import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.zb;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3489;
import net.minecraft.class_3532;
import net.minecraft.class_3966;

public class za
extends zb {
    private final ze b = new ze("FOV", 10.0, 180.0, 90.0, 1.0);
    private final ze c = new ze("Range", 1.0, 10.0, 5.0, 0.1);
    private final ze d = new ze("Speed", 1.0, 15.0, 10.0, 0.5);
    private final com.vengeance.vengeanceclient.r.r.za e = new com.vengeance.vengeanceclient.r.r.za("Target Players", true);
    private final com.vengeance.vengeanceclient.r.r.za f = new com.vengeance.vengeanceclient.r.r.za("Target Mobs", false);
    private final com.vengeance.vengeanceclient.r.r.za g = new com.vengeance.vengeanceclient.r.r.za("Weapons Only", false);
    private final com.vengeance.vengeanceclient.r.r.za h = new com.vengeance.vengeanceclient.r.r.za("Through Walls", false);
    private final com.vengeance.vengeanceclient.r.r.za i = new com.vengeance.vengeanceclient.r.r.za("Ignore Blocks", true);
    private final com.vengeance.vengeanceclient.r.r.za j = new com.vengeance.vengeanceclient.r.r.za("Only Outside Hitbox", true);
    private class_1297 k = null;
    private long l = 0L;

    public za() {
        super("Aim Assist", "Gives you assistance on your aim", com.vengeance.vengeanceclient.r.za.a);
        this.a(this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j);
    }

    @EventHandler
    private void onRender3D(com.vengeance.vengeanceclient.p.p.t.zb zb2) {
        if (this.d()) {
            return;
        }
        if (this.g.b() && !this.o()) {
            return;
        }
        if (za.a.field_1755 != null) {
            return;
        }
        if (za.a.field_1765 != null && za.a.field_1765.method_17783() == class_239.class_240.field_1332 && za.a.field_1690.field_1886.method_1434()) {
            return;
        }
        if (this.i.b() && za.a.field_1765 != null && za.a.field_1765.method_17783() == class_239.class_240.field_1332) {
            return;
        }
        this.k = this.n();
        if (this.k != null) {
            if (!this.h.b() && !za.a.field_1724.method_6057(this.k)) {
                return;
            }
            if (this.j.b() && this.b(this.k)) {
                return;
            }
            class_243 class_2432 = this.c(this.k);
            float[] fArray = this.a(class_2432);
            this.b(fArray[0], fArray[1]);
        }
    }

    private class_1297 n() {
        if (this.d()) {
            return null;
        }
        class_1297 class_12972 = null;
        double d = Double.MAX_VALUE;
        for (class_1297 class_12973 : za.a.field_1687.method_18112()) {
            double d2;
            class_243 class_2432;
            float[] fArray;
            double d3;
            double d4;
            if (!this.a(class_12973) || (d4 = (double)za.a.field_1724.method_5739(class_12973)) > (double)this.c.b() || !((d3 = this.a((fArray = this.a(class_2432 = this.c(class_12973)))[0], fArray[1])) <= (double)this.b.b() / 2.0) || !((d2 = d4 + d3 * 2.0) < d)) continue;
            d = d2;
            class_12972 = class_12973;
        }
        return class_12972;
    }

    private boolean a(class_1297 class_12972) {
        class_1657 class_16572;
        if (class_12972 == null || class_12972 == za.a.field_1724 || !(class_12972 instanceof class_1309)) {
            return false;
        }
        class_1309 class_13092 = (class_1309)class_12972;
        if (!class_13092.method_5805() || class_13092.method_29504()) {
            return false;
        }
        if (zh.a(class_12972)) {
            return false;
        }
        if (class_12972 instanceof class_1657 && com.vengeance.vengeanceclient.utils.q.za.c((class_16572 = (class_1657)class_12972).method_5667())) {
            return false;
        }
        return class_12972 instanceof class_1657 ? this.e.b() : this.f.b();
    }

    private boolean b(class_1297 class_12972) {
        class_3966 class_39662;
        class_239 class_2392 = za.a.field_1765;
        return class_2392 instanceof class_3966 && (class_39662 = (class_3966)class_2392).method_17782() == class_12972;
    }

    private class_243 c(class_1297 class_12972) {
        return new class_243(class_12972.method_23317(), class_12972.method_23320(), class_12972.method_23321());
    }

    private float[] a(class_243 class_2432) {
        class_243 class_2433 = class_2432.method_1020(za.a.field_1724.method_33571());
        double d = Math.sqrt(class_2433.field_1352 * class_2433.field_1352 + class_2433.field_1350 * class_2433.field_1350);
        float f = (float)Math.toDegrees(Math.atan2(class_2433.field_1350, class_2433.field_1352)) - 90.0f;
        float f2 = (float)(-Math.toDegrees(Math.atan2(class_2433.field_1351, d)));
        return new float[]{class_3532.method_15393((float)f), class_3532.method_15363((float)f2, (float)-89.0f, (float)89.0f)};
    }

    private double a(float f, float f2) {
        float f3 = class_3532.method_15393((float)(f - za.a.field_1724.method_36454()));
        float f4 = f2 - za.a.field_1724.method_36455();
        return Math.sqrt(f3 * f3 + f4 * f4);
    }

    private void b(float f, float f2) {
        long l = System.currentTimeMillis();
        if (this.l == 0L) {
            this.l = l;
            return;
        }
        float f3 = (float)(l - this.l) / 1000.0f;
        this.l = l;
        if (f3 < 0.001f || f3 > 0.1f) {
            return;
        }
        float f4 = za.a.field_1724.method_36454();
        float f5 = za.a.field_1724.method_36455();
        float f6 = this.a(f4, f, f3 * (this.d.b() / 10.0f));
        float f7 = this.a(f5, f2, f3 * (this.d.b() / 10.0f));
        za.a.field_1724.method_36456(f6);
        za.a.field_1724.method_36457(class_3532.method_15363((float)f7, (float)-89.0f, (float)89.0f));
    }

    private float a(float f, float f2, float f3) {
        float f4 = 1.70158f;
        float f5 = f4 + 1.0f;
        f3 = class_3532.method_15363((float)f3, (float)0.0f, (float)1.0f);
        float f6 = 1.0f - (float)Math.pow(1.0f - f3, 3.0);
        return f + class_3532.method_15393((float)(f2 - f)) * (1.0f + f5 * (float)Math.pow(f6 - 1.0f, 3.0) + f4 * (float)Math.pow(f6 - 1.0f, 2.0));
    }

    private boolean o() {
        if (za.a.field_1724 == null) {
            return false;
        }
        if (za.a.field_1724.method_6047().method_7960()) {
            return false;
        }
        class_1792 class_17922 = za.a.field_1724.method_6047().method_7909();
        return class_17922 instanceof class_1743 || za.a.field_1724.method_6047().method_31573(class_3489.field_42611);
    }

    @Override
    public void b() {
        super.b();
        this.l = System.currentTimeMillis();
    }

    @Override
    public void c() {
        super.c();
        this.k = null;
    }
}

