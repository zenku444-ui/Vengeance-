/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1268
 *  net.minecraft.class_1294
 *  net.minecraft.class_1296
 *  net.minecraft.class_1297
 *  net.minecraft.class_1511
 *  net.minecraft.class_1657
 *  net.minecraft.class_1743
 *  net.minecraft.class_1792
 *  net.minecraft.class_2246
 *  net.minecraft.class_239
 *  net.minecraft.class_2680
 *  net.minecraft.class_3489
 *  net.minecraft.class_3966
 *  net.minecraft.class_6025
 *  net.minecraft.class_8956
 *  org.lwjgl.glfw.GLFW
 */
package com.vengeance.vengeanceclient.r.q.q;

import com.vengeance.vengeanceclient.mixin.MinecraftClientAccessor;
import com.vengeance.vengeanceclient.r.q.r.zh;
import com.vengeance.vengeanceclient.r.r.zd;
import com.vengeance.vengeanceclient.r.r.zf;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import java.lang.runtime.SwitchBootstraps;
import java.util.Objects;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_3489;
import net.minecraft.class_3966;
import net.minecraft.class_6025;
import net.minecraft.class_8956;
import org.lwjgl.glfw.GLFW;

public final class zaa
extends zb {
    public static final zf b = new zf("Sword Threshold", 0.1, 1.0, 0.9, 0.95, 0.01);
    public static final zf c = new zf("Axe Threshold", 0.1, 1.0, 0.9, 0.95, 0.01);
    public static final zf d = new zf("Axe Post Delay", 1.0, 500.0, 120.0, 120.0, 0.5);
    public static final zf e = new zf("Reaction Time", 1.0, 350.0, 20.0, 95.0, 0.5);
    public static final zf f = new zf("Miss Chance", 0.0, 100.0, 0.0, 0.0, 1.0);
    public static final zd g = new zd("Cooldown Mode", "Smart", "Smart", "Strict", "None");
    public static final zd h = new zd("Criticals", "Strict", "None", "Strict");
    public static final com.vengeance.vengeanceclient.r.r.za i = new com.vengeance.vengeanceclient.r.r.za("No Passive", true);
    public static final com.vengeance.vengeanceclient.r.r.za j = new com.vengeance.vengeanceclient.r.r.za("No Invisible", true);
    public static final com.vengeance.vengeanceclient.r.r.za k = new com.vengeance.vengeanceclient.r.r.za("No Crystals", true);
    public static final com.vengeance.vengeanceclient.r.r.za l = new com.vengeance.vengeanceclient.r.r.za("Ignore Shields", false);
    public static final com.vengeance.vengeanceclient.r.r.za m = new com.vengeance.vengeanceclient.r.r.za("Only Sword or Axe", true);
    public static final com.vengeance.vengeanceclient.r.r.za n = new com.vengeance.vengeanceclient.r.r.za("Only Mouse Hold", false);
    public static final com.vengeance.vengeanceclient.r.r.za o = new com.vengeance.vengeanceclient.r.r.za("Disable on Load", false);
    public static final com.vengeance.vengeanceclient.r.r.za p = new com.vengeance.vengeanceclient.r.r.za("Same Player", false);
    private final com.vengeance.vengeanceclient.utils.s.zb s = new com.vengeance.vengeanceclient.utils.s.zb();
    private final com.vengeance.vengeanceclient.utils.s.zb t = new com.vengeance.vengeanceclient.utils.s.zb();
    private final com.vengeance.vengeanceclient.utils.s.zb u = new com.vengeance.vengeanceclient.utils.s.zb();
    public boolean q = false;
    private boolean v = false;
    private long x = 0L;
    private float y = 0.0f;
    private float z = 0.0f;
    private class_1297 aa;
    private String ab = null;

    public zaa() {
        super("Trigger Bot", "Makes you automatically attack once aimed at a target", -1, za.a);
        this.a(b, c, d, e, f, g, h, i, k, l, j, n, m, o, p);
    }

    @EventHandler
    private void onWorldChangeEvent(com.vengeance.vengeanceclient.p.p.u.za za2) {
        if (o.b() && this.l()) {
            this.a();
        }
    }

    @EventHandler
    private void handleInputEvent(com.vengeance.vengeanceclient.p.p.q.za za2) {
        if (this.d()) {
            return;
        }
        assert (zaa.a.field_1724 != null);
        if (zaa.a.field_1724.method_6115()) {
            return;
        }
        if (zaa.a.field_1755 != null) {
            return;
        }
        this.aa = zaa.a.field_1692;
        if (this.aa == null) {
            return;
        }
        if (!this.r()) {
            return;
        }
        if (n.b() && GLFW.glfwGetMouseButton((long)a.method_22683().method_4490(), (int)0) != 1) {
            return;
        }
        if (!this.a(this.aa)) {
            return;
        }
        if (l.b()) {
            class_1657 class_16572;
            class_1792 class_17922 = zaa.a.field_1724.method_6047().method_7909();
            Object object = this.aa;
            if (object instanceof class_1657 && com.vengeance.vengeanceclient.utils.t.zb.a(class_16572 = (class_1657)object) && zaa.a.field_1724.method_6047().method_31573(class_3489.field_42611)) {
                return;
            }
        }
        if (this.aa != null && !this.aa.method_5845().equals(this.ab)) {
            this.ab = this.aa.method_5845();
        }
        if (!this.v) {
            long l;
            this.v = true;
            this.u.a();
            switch (g.a()) {
                case "Smart": {
                    double d = zaa.a.field_1724.method_5739(this.aa);
                    double d2 = 3.0;
                    double d3 = d < d2 / 2.0 ? 0.66 : 1.0;
                    l = (long)com.vengeance.vengeanceclient.utils.s.za.a(e.c(), e.d());
                    l *= (long)d3;
                    break;
                }
                case "None": {
                    l = 0L;
                    break;
                }
                default: {
                    l = (long)com.vengeance.vengeanceclient.utils.s.za.a(e.c(), e.d());
                }
            }
            this.x = l;
        }
        if (this.v && this.u.a(this.x, true)) {
            if (h.a().equals("Strict")) {
                boolean bl;
                boolean bl2 = bl = zaa.a.field_1724.method_6101() || zaa.a.field_1724.method_5799() || zaa.a.field_1724.method_5869() || zaa.a.field_1687.method_8320(zaa.a.field_1724.method_24515()).method_27852(class_2246.field_10343);
                if (bl) {
                    if (this.q() && this.a(this.aa) && this.b(this.aa)) {
                        this.n();
                        this.v = false;
                    }
                } else if (!zaa.a.field_1724.method_24828() && !zaa.a.field_1724.method_6101()) {
                    if (this.o() && (double)zaa.a.field_1724.method_7261(0.0f) >= b.c() && this.a(this.aa) && this.b(this.aa)) {
                        this.n();
                        this.v = false;
                    }
                } else if (this.q() && this.a(this.aa) && this.b(this.aa)) {
                    this.n();
                    this.v = false;
                }
            } else if (this.q() && this.a(this.aa) && this.b(this.aa)) {
                this.n();
                this.v = false;
            }
        }
    }

    private boolean b(class_1297 class_12972) {
        if (!p.b()) {
            return true;
        }
        if (class_12972 == null) {
            return false;
        }
        if (this.ab == null || this.t.a(3000L, false)) {
            this.ab = class_12972.method_5845();
            this.t.a();
            return true;
        }
        return class_12972.method_5845().equals(this.ab);
    }

    private boolean o() {
        if (zaa.a.field_1724 == null) {
            return false;
        }
        return !zaa.a.field_1724.method_24828() && !zaa.a.field_1724.method_6101() && !zaa.a.field_1724.method_5771() && !zaa.a.field_1724.method_6059(class_1294.field_5919) && zaa.a.field_1724.field_6017 > (double)0.065f && zaa.a.field_1724.method_5854() == null;
    }

    private boolean p() {
        if (zaa.a.field_1724 == null || zaa.a.field_1687 == null) {
            return false;
        }
        String string = h.a();
        if (string.equals("None")) {
            return false;
        }
        if (zaa.a.field_1724.method_6059(class_1294.field_5902) || zaa.a.field_1724.method_6059(class_1294.field_5906) || zaa.a.field_1724.method_6059(class_1294.field_5919)) {
            return false;
        }
        class_239 class_2392 = zaa.a.field_1765;
        if (!(class_2392 instanceof class_3966)) {
            return false;
        }
        class_3966 class_39662 = (class_3966)class_2392;
        class_2392 = class_39662.method_17782();
        if (class_2392 != this.aa || !this.a((class_1297)class_2392)) {
            return false;
        }
        if (zaa.a.field_1724.method_5799() || zaa.a.field_1724.method_5771() || zaa.a.field_1724.method_5869() || zaa.a.field_1724.method_6101()) {
            return false;
        }
        class_2680 class_26802 = zaa.a.field_1687.method_8320(zaa.a.field_1724.method_24515());
        if (class_26802.method_27852(class_2246.field_10343) || class_26802.method_27852(class_2246.field_16999) || class_26802.method_27852(class_2246.field_10597) || class_26802.method_27852(class_2246.field_16492) || class_26802.method_27852(class_2246.field_10030) || class_26802.method_27852(class_2246.field_21211) || class_26802.method_27852(class_2246.field_27879)) {
            return false;
        }
        boolean bl = (double)zaa.a.field_1724.method_7261(0.0f) >= b.c();
        return string.equals("Strict") && bl && this.o();
    }

    private boolean q() {
        if (this.p()) {
            return false;
        }
        assert (zaa.a.field_1724 != null);
        class_1792 class_17922 = zaa.a.field_1724.method_6047().method_7909();
        float f = zaa.a.field_1724.method_7261(0.0f);
        if (class_17922 instanceof class_1743) {
            if (!this.q) {
                this.z = (float)com.vengeance.vengeanceclient.utils.s.za.a(c.c(), c.d());
                this.y = (float)com.vengeance.vengeanceclient.utils.s.za.a(d.c(), d.d());
                this.q = true;
            }
            if (f >= this.z) {
                if (this.s.a((long)this.y, true)) {
                    this.q = false;
                    return true;
                }
            } else {
                this.s.a();
            }
            return false;
        }
        float f2 = (float)com.vengeance.vengeanceclient.utils.s.za.a(b.c(), b.d());
        return f >= f2;
    }

    private boolean r() {
        if (!m.b()) {
            return true;
        }
        assert (zaa.a.field_1724 != null);
        class_1792 class_17922 = zaa.a.field_1724.method_6047().method_7909();
        return class_17922 instanceof class_1743 || zaa.a.field_1724.method_6047().method_31573(class_3489.field_42611);
    }

    public void n() {
        if (f.c() > 0.0 && Math.random() * 100.0 < f.c()) {
            zaa.a.field_1724.method_6104(class_1268.field_5808);
        } else {
            ((MinecraftClientAccessor)a).invokeDoAttack();
        }
        if (p.b() && this.aa != null) {
            this.ab = this.aa.method_5845();
            this.t.a();
        }
        this.q = false;
    }

    public boolean a(class_1297 class_12972) {
        boolean bl;
        class_1657 class_16572;
        if (class_12972 == zaa.a.field_1724 || class_12972 == zaa.a.field_1719 || !class_12972.method_5805()) {
            return false;
        }
        if (class_12972 instanceof class_1657 && com.vengeance.vengeanceclient.utils.q.za.c((class_16572 = (class_1657)class_12972).method_5667())) {
            return false;
        }
        if (zh.a(class_12972)) {
            return false;
        }
        if (class_12972 instanceof class_8956) {
            return false;
        }
        class_1297 class_12973 = class_12972;
        Objects.requireNonNull(class_12973);
        class_16572 = class_12973;
        int n = 0;
        block5: while (true) {
            switch (SwitchBootstraps.typeSwitch("typeSwitch", new Object[]{class_1511.class, class_6025.class, class_1296.class}, (Object)class_16572, n)) {
                case 0: {
                    class_1511 class_15112 = (class_1511)class_16572;
                    if (!k.b()) {
                        n = 1;
                        continue block5;
                    }
                    bl = false;
                    break block5;
                }
                case 1: {
                    class_6025 class_60252 = (class_6025)class_16572;
                    bl = false;
                    break block5;
                }
                case 2: {
                    class_1296 class_12962 = (class_1296)class_16572;
                    if (!i.b()) {
                        n = 3;
                        continue block5;
                    }
                    bl = false;
                    break block5;
                }
                default: {
                    if (!j.b() || !class_12972.method_5767()) {
                        bl = true;
                        break block5;
                    }
                    bl = false;
                    break block5;
                }
            }
            break;
        }
        return bl;
    }

    @Override
    public void b() {
        this.s.a();
        this.u.a();
        this.v = false;
        this.q = false;
        super.b();
    }

    @Override
    public void c() {
        this.s.a();
        this.u.a();
        this.v = false;
        this.q = false;
        super.c();
    }
}

