/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2596
 *  net.minecraft.class_2743
 */
package com.vengeance.vengeanceclient.r.q.q;

import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2596;
import net.minecraft.class_2743;

public final class zab
extends zb {
    public static final ze b = new ze("Chance (%)", 1.0, 100.0, 100.0, 1.0);
    public static final com.vengeance.vengeanceclient.r.r.za c = new com.vengeance.vengeanceclient.r.r.za("Ignore S press", true);
    public static final com.vengeance.vengeanceclient.r.r.za d = new com.vengeance.vengeanceclient.r.r.za("Ignore on fire", true);

    public zab() {
        super("Velocity", "Automatically jump resets to reduce your velocity", -1, za.a);
        this.a(b, c, d);
    }

    @EventHandler
    private void onPacketEvent(com.vengeance.vengeanceclient.p.p.r.zb zb2) {
        class_2743 class_27432;
        if (this.d()) {
            return;
        }
        class_2596 class_25962 = zb2.b();
        if (class_25962 instanceof class_2743 && (class_27432 = (class_2743)class_25962).method_11818() == zab.a.field_1724.method_5628() && this.n() && zab.a.field_1724.method_24828()) {
            if (c.b() && zab.a.field_1690.field_1881.method_1434()) {
                return;
            }
            if (d.b() && zab.a.field_1724.method_5809()) {
                return;
            }
            if (zab.a.field_1755 != null) {
                return;
            }
            zab.a.field_1724.method_6043();
        }
    }

    private boolean n() {
        return Math.random() * 100.0 < (double)b.b();
    }
}

