/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 */
package com.vengeance.vengeanceclient.r.q.q;

import com.vengeance.vengeanceclient.mixin.MinecraftClientAccessor;
import com.vengeance.vengeanceclient.p.p.s.zd;
import com.vengeance.vengeanceclient.r.r.zc;
import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.zb;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;

public final class zad
extends zb {
    private final zc b = new zc("Key", 86, true);
    private final ze c = new ze("Delay (ms)", 10.0, 500.0, 150.0, 25.0);
    private boolean d;
    private long e;
    private za f = za.a;

    public zad() {
        super("Xbow cart", "Rail \u2192 TNT cart \u2192 F&S \u2192 crossbow", -1, com.vengeance.vengeanceclient.r.za.a);
        this.a(this.b, this.c);
    }

    @EventHandler
    private void onTick(zd zd2) {
        if (this.d() || zad.a.field_1755 != null) {
            return;
        }
        boolean bl = com.vengeance.vengeanceclient.utils.r.za.b(this.b.e());
        long l = System.currentTimeMillis();
        if (bl && !this.d && this.f == za.a) {
            this.f = za.b;
            this.e = l;
        }
        this.d = bl;
        int n = this.c.a();
        switch (this.f.ordinal()) {
            case 0: {
                break;
            }
            case 1: {
                if (l - this.e < (long)n) break;
                if (this.n()) {
                    ((MinecraftClientAccessor)a).invokeDoItemUse();
                }
                this.f = za.c;
                this.e = l;
                break;
            }
            case 2: {
                if (l - this.e < (long)n) break;
                if (this.a(class_1802.field_8069)) {
                    ((MinecraftClientAccessor)a).invokeDoItemUse();
                }
                this.f = za.d;
                this.e = l;
                break;
            }
            case 3: {
                if (l - this.e < (long)n) break;
                if (this.a(class_1802.field_8884)) {
                    ((MinecraftClientAccessor)a).invokeDoItemUse();
                }
                this.f = za.e;
                this.e = l;
                break;
            }
            case 4: {
                if (l - this.e < (long)n) break;
                this.a(class_1802.field_8399);
                this.f = za.a;
            }
        }
    }

    private boolean n() {
        for (int i = 0; i < 9; ++i) {
            class_1792 class_17922;
            class_1799 class_17992 = zad.a.field_1724.method_31548().method_5438(i);
            if (class_17992.method_7960() || (class_17922 = class_17992.method_7909()) != class_1802.field_8129 && class_17922 != class_1802.field_8848 && class_17922 != class_1802.field_8211 && class_17922 != class_1802.field_8655) continue;
            zad.a.field_1724.method_31548().field_7545 = i;
            return true;
        }
        return false;
    }

    private boolean a(class_1792 class_17922) {
        for (int i = 0; i < 9; ++i) {
            class_1799 class_17992 = zad.a.field_1724.method_31548().method_5438(i);
            if (class_17992.method_7960() || class_17992.method_7909() != class_17922) continue;
            zad.a.field_1724.method_31548().field_7545 = i;
            return true;
        }
        return false;
    }

    @Override
    public void b() {
        this.d = false;
        this.f = za.a;
        super.b();
    }

    @Override
    public void c() {
        this.f = za.a;
        super.c();
    }

    private static final class za
    extends Enum<za> {
        public static final /* enum */ za a = new za();
        public static final /* enum */ za b = new za();
        public static final /* enum */ za c = new za();
        public static final /* enum */ za d = new za();
        public static final /* enum */ za e = new za();
        private static final /* synthetic */ za[] f;

        public static za[] values() {
            return (za[])f.clone();
        }

        public static za valueOf(String string) {
            return Enum.valueOf(za.class, string);
        }

        private static /* synthetic */ za[] a() {
            return new za[]{a, b, c, d, e};
        }

        static {
            f = za.a();
        }
    }
}

