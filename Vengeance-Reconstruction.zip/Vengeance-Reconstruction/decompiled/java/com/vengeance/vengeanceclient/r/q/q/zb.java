/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_239$class_240
 */
package com.vengeance.vengeanceclient.r.q.q;

import com.vengeance.vengeanceclient.r.za;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_239;

public final class zb
extends com.vengeance.vengeanceclient.r.zb {
    public zb() {
        super("Anti Miss", "Makes you not miss", -1, za.a);
    }

    @EventHandler
    private void onAttackEvent(com.vengeance.vengeanceclient.p.p.s.za za2) {
        if (this.d()) {
            return;
        }
        assert (zb.a.field_1765 != null);
        if (zb.a.field_1765.method_17783().equals((Object)class_239.class_240.field_1333)) {
            za2.c();
        }
    }
}

