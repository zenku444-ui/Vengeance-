/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_2338
 *  net.minecraft.class_239
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_243
 *  net.minecraft.class_3959
 *  net.minecraft.class_3959$class_242
 *  net.minecraft.class_3959$class_3960
 *  net.minecraft.class_3965
 */
package com.vengeance.vengeanceclient.r.q.q;

import com.vengeance.vengeanceclient.mixin.MinecraftClientAccessor;
import com.vengeance.vengeanceclient.r.r.zg;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

public final class zc
extends zb {
    private final com.vengeance.vengeanceclient.r.r.za b = new com.vengeance.vengeanceclient.r.r.za("Auto Switch", true);
    private boolean c = false;
    private class_2338 d = null;
    private int e = -1;
    private int f = 0;
    private boolean g = false;
    private boolean h = false;

    public zc() {
        super("Auto Cart", "Places TNT minecarts on rails when shooting arrows", -1, za.a);
        this.a(new zg[]{this.b});
    }

    @EventHandler
    private void onTickEvent(com.vengeance.vengeanceclient.p.p.q.za za2) {
        if (this.d()) {
            return;
        }
        if (zc.a.field_1724.method_6115() && zc.a.field_1724.method_6030().method_7909() == class_1802.field_8102) {
            if (!this.c) {
                this.n();
            }
        } else if (this.c && !zc.a.field_1724.method_6115() && this.f == 0) {
            this.f = 1;
        }
        if (!this.c) {
            return;
        }
        if (this.f == 1) {
            this.q();
            this.f = 2;
        } else if (this.f == 2) {
            this.r();
            this.o();
        }
    }

    private void n() {
        if (this.c) {
            return;
        }
        if (zc.a.field_1724.method_6047().method_7909() != class_1802.field_8102) {
            return;
        }
        class_2338 class_23382 = this.s();
        if (class_23382 == null) {
            return;
        }
        this.d = class_23382;
        this.c = true;
        this.f = 0;
        this.e = zc.a.field_1724.method_31548().field_7545;
    }

    private void o() {
        if (!this.c) {
            return;
        }
        if (this.b.b() && this.e != -1) {
            zc.a.field_1724.method_31548().field_7545 = this.e;
        }
        this.p();
    }

    private void p() {
        this.c = false;
        this.d = null;
        this.e = -1;
        this.f = 0;
        this.g = false;
        this.h = false;
    }

    private void q() {
        if (this.g) {
            return;
        }
        int n = this.u();
        if (n == -1) {
            return;
        }
        zc.a.field_1724.method_31548().field_7545 = n;
        ((MinecraftClientAccessor)a).invokeDoItemUse();
        this.g = true;
    }

    private void r() {
        if (this.h) {
            this.o();
            return;
        }
        int n = this.t();
        if (n == -1) {
            return;
        }
        zc.a.field_1724.method_31548().field_7545 = n;
        ((MinecraftClientAccessor)a).invokeDoItemUse();
        this.h = true;
    }

    private class_2338 s() {
        class_243 class_2432;
        class_243 class_2433;
        class_239 class_2392 = zc.a.field_1765;
        if (class_2392 == null) {
            return null;
        }
        if (class_2392.method_17783() == class_239.class_240.field_1332) {
            class_3965 class_39652 = (class_3965)class_2392;
            return class_39652.method_17777().method_10093(class_39652.method_17780());
        }
        if (class_2392.method_17783() == class_239.class_240.field_1331) {
            return zc.a.field_1724.method_24515().method_10069(0, 1, 0);
        }
        class_243 class_2434 = zc.a.field_1724.method_5836(1.0f);
        class_3965 class_39653 = zc.a.field_1687.method_17742(new class_3959(class_2434, class_2433 = class_2434.method_1019((class_2432 = zc.a.field_1724.method_5828(1.0f)).method_1021(5.0)), class_3959.class_3960.field_17559, class_3959.class_242.field_1348, (class_1297)zc.a.field_1724));
        if (class_39653 != null) {
            return class_39653.method_17777().method_10093(class_39653.method_17780());
        }
        return zc.a.field_1724.method_24515().method_10069(0, 1, 0);
    }

    private int t() {
        for (int i = 0; i < 9; ++i) {
            class_1799 class_17992 = zc.a.field_1724.method_31548().method_5438(i);
            if (class_17992.method_7960() || class_17992.method_7909() != class_1802.field_8069) continue;
            return i;
        }
        return -1;
    }

    private int u() {
        for (int i = 0; i < 9; ++i) {
            class_1799 class_17992 = zc.a.field_1724.method_31548().method_5438(i);
            if (class_17992.method_7960() || !this.a(class_17992.method_7909())) continue;
            return i;
        }
        return -1;
    }

    private boolean a(class_1792 class_17922) {
        return class_17922 == class_1802.field_8129 || class_17922 == class_1802.field_8848 || class_17922 == class_1802.field_8211 || class_17922 == class_1802.field_8655;
    }

    @Override
    public void b() {
        this.p();
    }

    @Override
    public void c() {
        if (this.c) {
            this.o();
        }
    }
}

