/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1294
 *  net.minecraft.class_1297
 *  net.minecraft.class_1511
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_2246
 *  net.minecraft.class_2248
 *  net.minecraft.class_2338
 *  net.minecraft.class_2382
 *  net.minecraft.class_239
 *  net.minecraft.class_243
 *  net.minecraft.class_3965
 *  net.minecraft.class_3966
 */
package com.vengeance.vengeanceclient.r.q.q;

import com.vengeance.vengeanceclient.mixin.MinecraftClientAccessor;
import com.vengeance.vengeanceclient.r.r.zc;
import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

public final class zd
extends zb {
    private final zc b = new zc("Crystal Key", 3, false);
    private final ze c = new ze("Delay (MS)", 1.0, 200.0, 50.0, 1.0);
    private final com.vengeance.vengeanceclient.r.r.za d = new com.vengeance.vengeanceclient.r.r.za("Anti Suicide", true);
    private final com.vengeance.vengeanceclient.r.r.za e = new com.vengeance.vengeanceclient.r.r.za("Auto Switch", true);
    private final com.vengeance.vengeanceclient.r.r.za f = new com.vengeance.vengeanceclient.r.r.za("Switch Back", true);
    private final com.vengeance.vengeanceclient.r.r.za g = new com.vengeance.vengeanceclient.r.r.za("Anti Weakness", true);
    private final com.vengeance.vengeanceclient.utils.s.zb h = new com.vengeance.vengeanceclient.utils.s.zb();
    private int i = -1;

    public zd() {
        super("Auto Crystal", "Hold key to spam crystals", -1, za.a);
        this.a(this.b, this.c, this.d, this.e, this.f, this.g);
        this.f().removeIf(zg2 -> zg2 instanceof zc && !zg2.equals(this.b));
    }

    @EventHandler
    private void onTickEvent(com.vengeance.vengeanceclient.p.p.q.za za2) {
        if (this.d()) {
            return;
        }
        if (zd.a.field_1755 != null) {
            return;
        }
        if (!com.vengeance.vengeanceclient.utils.r.za.b(this.b.e())) {
            return;
        }
        if (this.h.a(this.c.a())) {
            this.n();
            this.h.a();
        }
    }

    private void n() {
        class_3966 class_39662;
        class_1297 class_12972;
        if (this.d.b() && !zd.a.field_1724.method_24828()) {
            return;
        }
        class_239 class_2392 = zd.a.field_1765;
        if (class_2392 instanceof class_3966 && (class_12972 = (class_39662 = (class_3966)class_2392).method_17782()) instanceof class_1511) {
            class_2392 = (class_1511)class_12972;
            if (!class_2392.method_31481() && class_2392.method_5805() && zd.a.field_1687.method_8469(class_2392.method_5628()) != null && zd.a.field_1724.method_73189().method_1022(class_2392.method_73189()) <= 4.5) {
                if (this.g.b() && zd.a.field_1724.method_6059(class_1294.field_5911)) {
                    com.vengeance.vengeanceclient.utils.t.zd.b();
                }
                ((MinecraftClientAccessor)a).invokeDoAttack();
            }
            return;
        }
        class_2392 = zd.a.field_1765;
        if (class_2392 instanceof class_3965) {
            class_39662 = (class_3965)class_2392;
            class_2392 = class_39662.method_17777();
            class_12972 = class_2392.method_10093(class_39662.method_17780());
            if (this.a((class_2338)class_2392) && this.b((class_2338)class_12972)) {
                if (this.e.b() && this.o()) {
                    com.vengeance.vengeanceclient.utils.t.zd.a(class_1802.field_8301);
                }
                if (zd.a.field_1724.method_6047().method_7909() == class_1802.field_8301) {
                    ((MinecraftClientAccessor)a).invokeDoItemUse();
                }
            }
        }
    }

    private boolean o() {
        for (int i = 0; i < 9; ++i) {
            class_1799 class_17992 = zd.a.field_1724.method_31548().method_5438(i);
            if (class_17992.method_7960() || class_17992.method_7909() != class_1802.field_8301) continue;
            return true;
        }
        return false;
    }

    private boolean a(class_2338 class_23382) {
        if (zd.a.field_1687 == null) {
            return false;
        }
        class_2248 class_22482 = zd.a.field_1687.method_8320(class_23382).method_26204();
        return class_22482 == class_2246.field_10540 || class_22482 == class_2246.field_9987;
    }

    private boolean b(class_2338 class_23382) {
        if (zd.a.field_1687 == null) {
            return false;
        }
        if (zd.a.field_1724.method_73189().method_1022(class_243.method_24953((class_2382)class_23382)) > 4.5) {
            return false;
        }
        if (!zd.a.field_1687.method_8320(class_23382).method_26215()) {
            return false;
        }
        if (!zd.a.field_1687.method_8320(class_23382.method_10084()).method_26215()) {
            return false;
        }
        class_2338 class_23383 = zd.a.field_1724.method_24515();
        return !class_23382.equals((Object)class_23383) && !class_23382.equals((Object)class_23383.method_10084());
    }

    @Override
    public void b() {
        super.b();
        if (this.e.b()) {
            this.i = zd.a.field_1724.method_31548().field_7545;
        }
        this.h.a();
    }

    @Override
    public void c() {
        super.c();
        if (this.f.b() && this.i != -1) {
            zd.a.field_1724.method_31548().field_7545 = this.i;
        }
        this.i = -1;
    }

    @Override
    public int e() {
        return -1;
    }
}

