/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1296
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_1743
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_6025
 */
package com.vengeance.vengeanceclient.r.q.q;

import com.vengeance.vengeanceclient.mixin.MinecraftClientAccessor;
import com.vengeance.vengeanceclient.p.p.s.zd;
import com.vengeance.vengeanceclient.r.q.r.zh;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_6025;

public final class ze
extends zb {
    private final com.vengeance.vengeanceclient.r.r.ze b = new com.vengeance.vengeanceclient.r.r.ze("Min Fall Distance", 1.0, 10.0, 3.0, 0.5);
    private final com.vengeance.vengeanceclient.r.r.ze c = new com.vengeance.vengeanceclient.r.r.ze("Attack Delay", 0.0, 500.0, 100.0, 10.0);
    private final com.vengeance.vengeanceclient.r.r.ze d = new com.vengeance.vengeanceclient.r.r.ze("Density Threshold", 1.0, 20.0, 7.0, 0.5);
    private final com.vengeance.vengeanceclient.r.r.za e = new com.vengeance.vengeanceclient.r.r.za("Target Players", true);
    private final com.vengeance.vengeanceclient.r.r.za f = new com.vengeance.vengeanceclient.r.r.za("Target Mobs", false);
    private final com.vengeance.vengeanceclient.r.r.za g = new com.vengeance.vengeanceclient.r.r.za("Stun Slam", false);
    private final com.vengeance.vengeanceclient.r.r.za h = new com.vengeance.vengeanceclient.r.r.za("Only Axe", false);
    private final com.vengeance.vengeanceclient.r.r.za i = new com.vengeance.vengeanceclient.r.r.za("Auto Switch Mace", true);
    private final com.vengeance.vengeanceclient.r.r.za j = new com.vengeance.vengeanceclient.r.r.za("Stay On Mace", false);
    private final com.vengeance.vengeanceclient.utils.s.zb k = new com.vengeance.vengeanceclient.utils.s.zb();
    private int l = -1;
    private double m = -1.0;
    private boolean n = false;
    private boolean o = false;
    private boolean p = false;
    private int q = 0;

    public ze() {
        super("Auto Mace", "Automatically attacks with mace", -1, za.a);
        this.a(this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j);
    }

    @EventHandler
    private void preMotion(zd zd2) {
        if (this.d()) {
            return;
        }
        this.n();
        this.o();
    }

    private void n() {
        boolean bl = ze.a.field_1724.method_24828();
        boolean bl2 = ze.a.field_1724.method_18798().field_1351 < -0.1;
        boolean bl3 = ze.a.field_1724.method_18798().field_1351 > 0.1;
        double d = ze.a.field_1724.method_23318();
        if (bl) {
            if (this.n) {
                this.v();
            }
            if (this.l != -1 && !this.j.b()) {
                this.b(this.l);
                this.l = -1;
            }
            return;
        }
        if (bl3 && this.p) {
            this.p = false;
            this.m = d;
        }
        if (!this.n) {
            this.n = true;
            this.m = d;
            this.o = false;
            this.p = false;
            this.q = 0;
        } else if (bl2 && this.m != -1.0 && d > this.m) {
            this.m = d;
        }
    }

    private void o() {
        double d;
        if (!this.n || ze.a.field_1724.method_18798().field_1351 >= -0.1) {
            return;
        }
        double d2 = d = this.m == -1.0 ? 0.0 : Math.max(0.0, this.m - ze.a.field_1724.method_23318());
        if (d < (double)this.b.b()) {
            return;
        }
        class_1297 class_12972 = ze.a.field_1692;
        if (!this.b(class_12972) || com.vengeance.vengeanceclient.utils.q.za.c(class_12972.method_5667())) {
            return;
        }
        if (this.g.b()) {
            this.a(class_12972, d);
        }
        if (!this.g.b() || this.o || this.q == 0) {
            this.a(class_12972);
        }
    }

    private void a(class_1297 class_12972, double d) {
        class_1657 class_16572;
        boolean bl;
        boolean bl2 = bl = class_12972 instanceof class_1657 && (class_16572 = (class_1657)class_12972).method_24518(class_1802.field_8255) && class_16572.method_6039();
        if (this.h.b() && !this.a(ze.a.field_1724.method_6047())) {
            return;
        }
        if (bl && d > (double)this.b.b() && !this.o && this.q == 0) {
            if (this.l == -1) {
                this.l = ze.a.field_1724.method_31548().field_7545;
            }
            this.q = 1;
        }
        if (this.q == 1) {
            int n;
            int n2 = n = this.h.b() ? ze.a.field_1724.method_31548().field_7545 : this.p();
            if (n != -1) {
                ze.a.field_1724.method_31548().field_7545 = n;
                ((MinecraftClientAccessor)a).invokeDoAttack();
            }
            this.q = 2;
        } else if (this.q == 2) {
            this.r();
            this.o = true;
            this.q = 0;
        }
    }

    private void a(class_1297 class_12972) {
        double d;
        if (this.p) {
            return;
        }
        double d2 = d = this.m == -1.0 ? 0.0 : Math.max(0.0, this.m - ze.a.field_1724.method_23318());
        if (!this.q()) {
            if (this.l == -1) {
                this.l = ze.a.field_1724.method_31548().field_7545;
            }
            if (this.i.b()) {
                this.a(d);
            } else {
                this.r();
            }
        } else if (this.i.b()) {
            this.a(d);
        }
        if (this.q() && this.k.a((long)this.c.f(), true)) {
            ((MinecraftClientAccessor)a).invokeDoAttack();
            this.p = true;
        }
    }

    private boolean b(class_1297 class_12972) {
        if (class_12972 == null || class_12972 == ze.a.field_1724 || class_12972 == ze.a.field_1719) {
            return false;
        }
        if (!(class_12972 instanceof class_1309)) {
            return false;
        }
        class_1309 class_13092 = (class_1309)class_12972;
        if (!class_13092.method_5805() || class_13092.method_29504()) {
            return false;
        }
        if (zh.a(class_12972)) {
            return false;
        }
        if (class_12972 instanceof class_1657) {
            return this.e.b();
        }
        if (!this.f.b()) {
            return false;
        }
        return !(class_12972 instanceof class_1296) && !(class_12972 instanceof class_6025);
    }

    private int p() {
        for (int i = 0; i < 9; ++i) {
            class_1799 class_17992 = ze.a.field_1724.method_31548().method_5438(i);
            if (!this.a(class_17992)) continue;
            return i;
        }
        return -1;
    }

    private boolean a(class_1799 class_17992) {
        return class_17992.method_7909() instanceof class_1743;
    }

    private boolean q() {
        return ze.a.field_1724.method_6047().method_7909() == class_1802.field_49814;
    }

    private void r() {
        for (int i = 0; i < 9; ++i) {
            class_1799 class_17992 = ze.a.field_1724.method_31548().method_5438(i);
            if (class_17992.method_7909() != class_1802.field_49814) continue;
            ze.a.field_1724.method_31548().field_7545 = i;
            return;
        }
    }

    private void a(double d) {
        int n;
        boolean bl = d >= this.d.f();
        int n2 = n = bl ? this.s() : this.t();
        if (n == -1) {
            n = this.u();
        }
        if (n != -1) {
            ze.a.field_1724.method_31548().field_7545 = n;
        }
    }

    private int s() {
        for (int i = 0; i < 9; ++i) {
            class_1799 class_17992 = ze.a.field_1724.method_31548().method_5438(i);
            if (class_17992.method_7909() != class_1802.field_49814 || !this.b(class_17992)) continue;
            return i;
        }
        return -1;
    }

    private int t() {
        for (int i = 0; i < 9; ++i) {
            class_1799 class_17992 = ze.a.field_1724.method_31548().method_5438(i);
            if (class_17992.method_7909() != class_1802.field_49814 || !this.c(class_17992)) continue;
            return i;
        }
        return -1;
    }

    private int u() {
        for (int i = 0; i < 9; ++i) {
            class_1799 class_17992 = ze.a.field_1724.method_31548().method_5438(i);
            if (class_17992.method_7909() != class_1802.field_49814) continue;
            return i;
        }
        return -1;
    }

    private boolean b(class_1799 class_17992) {
        return class_17992.method_58657().method_57534().stream().anyMatch(class_68802 -> class_68802.method_55840().contains("density"));
    }

    private boolean c(class_1799 class_17992) {
        return class_17992.method_58657().method_57534().stream().anyMatch(class_68802 -> class_68802.method_55840().contains("breach"));
    }

    private void b(int n) {
        if (n >= 0 && n < 9) {
            ze.a.field_1724.method_31548().field_7545 = n;
        }
    }

    private void v() {
        this.n = false;
        this.m = -1.0;
        this.o = false;
        this.p = false;
        this.q = 0;
    }

    @Override
    public void b() {
        this.l = -1;
        this.m = -1.0;
        this.n = false;
        this.o = false;
        this.p = false;
        this.q = 0;
        this.k.a();
    }

    @Override
    public void c() {
        if (this.l != -1) {
            this.b(this.l);
        }
        this.w();
    }

    private void w() {
        this.l = -1;
        this.m = -1.0;
        this.n = false;
        this.o = false;
        this.p = false;
        this.q = 0;
        this.k.a();
    }
}

