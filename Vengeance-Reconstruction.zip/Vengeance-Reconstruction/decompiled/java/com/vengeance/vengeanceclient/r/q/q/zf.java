/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1294
 *  net.minecraft.class_1297
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_1842
 *  net.minecraft.class_1844
 *  net.minecraft.class_3532
 *  net.minecraft.class_6880
 *  net.minecraft.class_9334
 */
package com.vengeance.vengeanceclient.r.q.q;

import com.vengeance.vengeanceclient.mixin.MinecraftClientAccessor;
import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import java.util.ArrayList;
import java.util.List;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1842;
import net.minecraft.class_1844;
import net.minecraft.class_3532;
import net.minecraft.class_6880;
import net.minecraft.class_9334;

public final class zf
extends zb {
    private static final ze b = new ze("Health Threshold", 1.0, 20.0, 10.0, 0.5);
    private static final ze c = new ze("Throw Cooldown", 50.0, 1000.0, 250.0, 50.0);
    private static final ze d = new ze("Rotation Speed", 1.0, 20.0, 10.0, 0.5);
    private static final ze e = new ze("Swap Delay", 0.0, 200.0, 50.0, 10.0);
    private static final ze f = new ze("Min Player Distance", 0.0, 10.0, 0.0, 0.5);
    private static final com.vengeance.vengeanceclient.r.r.za g = new com.vengeance.vengeanceclient.r.r.za("Require On Ground", true);
    private final com.vengeance.vengeanceclient.utils.s.zb h = new com.vengeance.vengeanceclient.utils.s.zb();
    private final com.vengeance.vengeanceclient.utils.s.zb i = new com.vengeance.vengeanceclient.utils.s.zb();
    private final List<Integer> j = new ArrayList<Integer>();
    private int k = -1;
    private float l = 0.0f;
    private boolean m = false;
    private boolean n = false;
    private float o = 0.0f;
    private float p = 0.0f;

    public zf() {
        super("Auto Pot", "Automatically throws health potions when health is low", -1, za.a);
        this.a(b, c, d, e, f, g);
    }

    @EventHandler
    private void onTickEvent(com.vengeance.vengeanceclient.p.p.q.za za2) {
        if (this.d() || zf.a.field_1755 != null || zf.a.field_1724.method_6115()) {
            return;
        }
        if (this.n) {
            if (this.i.a(e.a())) {
                this.p();
            }
            return;
        }
        if (this.m) {
            this.n();
            return;
        }
        if (this.s()) {
            if (!this.t()) {
                return;
            }
            this.r();
            if (this.j.isEmpty()) {
                return;
            }
            if (this.k == -1) {
                this.k = zf.a.field_1724.method_31548().field_7545;
                this.l = zf.a.field_1724.method_36455();
            }
            this.a(89.9f);
        }
    }

    private void a(float f) {
        this.m = true;
        this.o = f;
        this.p = 0.0f;
    }

    private void n() {
        if (d.b() <= 1.0f) {
            zf.a.field_1724.method_36457(this.o);
            this.m = false;
            if (this.o == 89.9f) {
                this.o();
            } else {
                zf.a.field_1724.method_31548().field_7545 = this.k;
                this.q();
            }
        } else {
            float f = (d.b() - 1.0f) * 0.2f;
            this.p += f;
            if (this.p >= 1.0f) {
                zf.a.field_1724.method_36457(this.o);
                this.m = false;
                if (this.o == 89.9f) {
                    this.o();
                } else {
                    zf.a.field_1724.method_31548().field_7545 = this.k;
                    this.q();
                }
            } else {
                zf.a.field_1724.method_36457(class_3532.method_16439((float)this.p, (float)this.l, (float)this.o));
            }
        }
    }

    private void o() {
        if (e.a() <= 0) {
            this.p();
        } else {
            this.n = true;
            this.i.a();
        }
    }

    private void p() {
        zf.a.field_1724.method_31548().field_7545 = this.j.get(0);
        ((MinecraftClientAccessor)a).invokeDoItemUse();
        this.n = false;
        this.a(this.l);
    }

    private void q() {
        this.k = -1;
        this.l = 0.0f;
        this.p = 0.0f;
        this.n = false;
        this.j.clear();
    }

    private void r() {
        this.j.clear();
        for (int i = 0; i < 9; ++i) {
            if (!this.a(zf.a.field_1724.method_31548().method_5438(i))) continue;
            this.j.add(i);
        }
    }

    private boolean a(class_1799 class_17992) {
        if (class_17992.method_7909() != class_1802.field_8436) {
            return false;
        }
        class_1844 class_18442 = (class_1844)class_17992.method_58694(class_9334.field_49651);
        if (class_18442 == null) {
            return false;
        }
        if (class_18442.comp_2378().isPresent()) {
            class_6880 class_68802 = (class_6880)class_18442.comp_2378().get();
            return ((class_1842)class_68802.comp_349()).method_8049().stream().anyMatch(class_12932 -> class_12932.method_5579().equals((Object)class_1294.field_5915));
        }
        return class_18442.comp_2380().stream().anyMatch(class_12932 -> class_12932.method_5579().equals((Object)class_1294.field_5915));
    }

    @Override
    public void b() {
        this.q();
        this.h.a();
        this.i.a();
        super.b();
    }

    @Override
    public void c() {
        if (this.k != -1) {
            zf.a.field_1724.method_31548().field_7545 = this.k;
            zf.a.field_1724.method_36457(this.l);
        }
        this.q();
        super.c();
    }

    private boolean s() {
        return zf.a.field_1724.method_6032() <= b.b() && this.h.a(c.a());
    }

    private boolean t() {
        if (f.b() > 0.0f && this.u()) {
            return false;
        }
        return !g.b() || zf.a.field_1724.method_24828();
    }

    private boolean u() {
        if (zf.a.field_1687 == null) {
            return false;
        }
        double d = f.b();
        return zf.a.field_1687.method_18456().stream().anyMatch(class_7422 -> class_7422 != zf.a.field_1724 && (double)zf.a.field_1724.method_5739((class_1297)class_7422) < d);
    }

    @Override
    public int e() {
        return -1;
    }
}

