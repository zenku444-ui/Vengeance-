/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1309
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1887
 *  net.minecraft.class_1937
 *  net.minecraft.class_239
 *  net.minecraft.class_2960
 *  net.minecraft.class_3966
 *  net.minecraft.class_5321
 *  net.minecraft.class_7924
 *  net.minecraft.class_9362
 */
package com.vengeance.vengeanceclient.r.q.q;

import com.vengeance.vengeanceclient.mixin.MinecraftClientAccessor;
import com.vengeance.vengeanceclient.r.q.q.zs;
import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import com.vengeance.vengeanceclient.utils.t.zc;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_2960;
import net.minecraft.class_3966;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_9362;

public final class zg
extends zb {
    private final ze b = new ze("Switch Delay", 10.0, 100.0, 30.0, 1.0);
    private final com.vengeance.vengeanceclient.r.r.za c = new com.vengeance.vengeanceclient.r.r.za("Only on ground", true);
    private final com.vengeance.vengeanceclient.r.r.za d = new com.vengeance.vengeanceclient.r.r.za("Silent Swap", true);
    private int e = -1;
    private boolean f = false;
    private long g = 0L;
    private boolean h = false;

    public zg() {
        super("Breach Swap", "Switches to a Breach enchanted mace when attacking", za.a);
        this.a(this.b, this.c, this.d);
    }

    @EventHandler
    public void onAttack(com.vengeance.vengeanceclient.p.p.s.za za2) {
        if (this.d() || this.h) {
            return;
        }
        if (this.c.b() && !zg.a.field_1724.method_24828()) {
            return;
        }
        if (zs.b) {
            return;
        }
        if (!(za2.a() instanceof class_1309)) {
            return;
        }
        int n = this.n();
        if (n == -1) {
            return;
        }
        if (this.e == -1) {
            this.e = zg.a.field_1724.method_31548().field_7545;
        }
        if (this.d.b()) {
            int n2 = zg.a.field_1724.method_31548().field_7545;
            zg.a.field_1724.method_31548().field_7545 = n;
            this.h = true;
            ((MinecraftClientAccessor)a).invokeDoAttack();
            this.h = false;
            zg.a.field_1724.method_31548().field_7545 = n2;
        } else {
            zg.a.field_1724.method_31548().field_7545 = n;
            this.h = true;
            ((MinecraftClientAccessor)a).invokeDoAttack();
            this.h = false;
            this.f = true;
            this.g = System.currentTimeMillis();
        }
    }

    @EventHandler
    public void onTick(com.vengeance.vengeanceclient.p.p.q.za za2) {
        int n;
        class_3966 class_39662;
        class_239 class_2392;
        if (this.d()) {
            return;
        }
        if (zs.b) {
            return;
        }
        if (this.f && (double)(System.currentTimeMillis() - this.g) >= this.b.f()) {
            if (this.e != -1) {
                zg.a.field_1724.method_31548().field_7545 = this.e;
                this.e = -1;
            }
            this.f = false;
        }
        if (zg.a.field_1690.field_1886.method_1434() && (class_2392 = zg.a.field_1765) instanceof class_3966 && (class_39662 = (class_3966)class_2392).method_17782() instanceof class_1309 && (n = this.n()) != -1) {
            if (this.e == -1) {
                this.e = zg.a.field_1724.method_31548().field_7545;
            }
            if (this.d.b()) {
                int n2 = zg.a.field_1724.method_31548().field_7545;
                zg.a.field_1724.method_31548().field_7545 = n;
                ((MinecraftClientAccessor)a).invokeDoAttack();
                zg.a.field_1724.method_31548().field_7545 = n2;
            } else {
                zg.a.field_1724.method_31548().field_7545 = n;
                ((MinecraftClientAccessor)a).invokeDoAttack();
                this.g = System.currentTimeMillis();
                this.f = true;
            }
        }
    }

    private int n() {
        for (int i = 0; i < 9; ++i) {
            class_1799 class_17992 = zg.a.field_1724.method_31548().method_5438(i);
            class_1792 class_17922 = class_17992.method_7909();
            if (!(class_17922 instanceof class_9362) || !this.a(class_17992)) continue;
            return i;
        }
        return -1;
    }

    private boolean a(class_1799 class_17992) {
        class_5321 class_53212 = class_5321.method_29179((class_5321)class_7924.field_41265, (class_2960)class_2960.method_60655((String)"minecraft", (String)"breach"));
        return zc.a(class_17992, (class_1937)zg.a.field_1687, (class_5321<class_1887>)class_53212);
    }

    @Override
    public void c() {
        if (this.e != -1) {
            zg.a.field_1724.method_31548().field_7545 = this.e;
            this.e = -1;
        }
        this.f = false;
        this.h = false;
    }
}

