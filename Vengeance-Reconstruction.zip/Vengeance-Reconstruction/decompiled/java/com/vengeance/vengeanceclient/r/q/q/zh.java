/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1294
 *  net.minecraft.class_1309
 *  net.minecraft.class_2596
 *  net.minecraft.class_2828$class_2829
 */
package com.vengeance.vengeanceclient.r.q.q;

import com.vengeance.vengeanceclient.r.r.zd;
import com.vengeance.vengeanceclient.r.r.zg;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_2596;
import net.minecraft.class_2828;

public class zh
extends zb {
    public final zd b = new zd("Mode", "Vanilla", "Vanilla", "Watchdog Old", "Mospixel");

    public zh() {
        super("Criticals", "Makes you hit every crit (BLATANT)", -1, za.a);
        this.a((zg)this.b);
    }

    @EventHandler
    public void onAttack(com.vengeance.vengeanceclient.p.p.s.za za2) {
        boolean bl;
        if (this.d()) {
            return;
        }
        boolean bl2 = bl = zh.a.field_1724.field_6017 > 0.0 && !zh.a.field_1724.method_24828() && !zh.a.field_1724.method_6101() && !zh.a.field_1724.method_5799() && !zh.a.field_1724.method_6059(class_1294.field_5919) && !zh.a.field_1724.method_5765() && za2.a() instanceof class_1309;
        if (bl) {
            return;
        }
        switch (this.b.a()) {
            case "Vanilla": {
                zh.a.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2829(zh.a.field_1724.method_73189().field_1352, zh.a.field_1724.method_73189().field_1351 + 0.2, zh.a.field_1724.method_73189().field_1350, false, false));
                zh.a.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2829(zh.a.field_1724.method_73189().field_1352, zh.a.field_1724.method_73189().field_1351 + 0.1, zh.a.field_1724.method_73189().field_1350, false, false));
                break;
            }
            case "Watchdog Old": {
                if (!zh.a.field_1724.method_24828()) break;
                zh.a.field_1724.method_5814(zh.a.field_1724.method_23317(), zh.a.field_1724.method_23318() + 0.001, zh.a.field_1724.method_23321());
                break;
            }
            case "Mospixel": {
                zh.a.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2829(zh.a.field_1724.method_73189().field_1352, zh.a.field_1724.method_73189().field_1351 + 2.71875E-7, zh.a.field_1724.method_73189().field_1350, false, false));
                zh.a.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2829(zh.a.field_1724.method_73189().field_1352, zh.a.field_1724.method_73189().field_1351, zh.a.field_1724.method_73189().field_1350, false, false));
            }
        }
    }
}

