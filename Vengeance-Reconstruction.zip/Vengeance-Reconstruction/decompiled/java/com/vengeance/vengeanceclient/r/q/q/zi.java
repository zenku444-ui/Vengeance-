/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1293
 *  net.minecraft.class_1294
 *  net.minecraft.class_1297$class_5529
 *  net.minecraft.class_1511
 *  net.minecraft.class_1799
 *  net.minecraft.class_239
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_3489
 *  net.minecraft.class_3966
 */
package com.vengeance.vengeanceclient.r.q.q;

import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1799;
import net.minecraft.class_239;
import net.minecraft.class_3489;
import net.minecraft.class_3966;

public final class zi
extends zb {
    public zi() {
        super("Crystal Optimizer", "Makes crystals disappear faster client-side for quicker placement.", -1, za.a);
    }

    @EventHandler
    private void onAttackEvent(com.vengeance.vengeanceclient.p.p.s.zb zb2) {
        boolean bl;
        if (this.d()) {
            return;
        }
        if (zi.a.field_1765 == null) {
            return;
        }
        if (zi.a.field_1765.method_17783() != class_239.class_240.field_1331) {
            return;
        }
        class_239 class_2392 = zi.a.field_1765;
        if (!(class_2392 instanceof class_3966)) {
            return;
        }
        class_3966 class_39662 = (class_3966)class_2392;
        class_2392 = class_39662.method_17782();
        if (!(class_2392 instanceof class_1511)) {
            return;
        }
        class_1511 class_15112 = (class_1511)class_2392;
        class_1293 class_12932 = zi.a.field_1724.method_6112(class_1294.field_5911);
        class_1293 class_12933 = zi.a.field_1724.method_6112(class_1294.field_5910);
        class_1799 class_17992 = zi.a.field_1724.method_6047();
        boolean bl2 = bl = class_12932 == null || class_12933 != null && class_12933.method_5578() > class_12932.method_5578() || class_17992.method_31573(class_3489.field_42611) || class_17992.method_31573(class_3489.field_42612) || class_17992.method_31573(class_3489.field_42614) || class_17992.method_31573(class_3489.field_42615) || class_17992.method_31573(class_3489.field_42613);
        if (!bl) {
            return;
        }
        class_15112.method_31745(class_1297.class_5529.field_26998);
        class_15112.method_36209();
    }
}

