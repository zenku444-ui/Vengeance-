/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1304
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 */
package com.vengeance.vengeanceclient.r.q.q;

import com.vengeance.vengeanceclient.mixin.MinecraftClientAccessor;
import com.vengeance.vengeanceclient.r.r.zc;
import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.zb;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1802;

public final class zj
extends zb {
    private final zc b = new zc("Hotswap Key", 71, false);
    private final ze c = new ze("Swap Delay (MS)", 50.0, 500.0, 150.0, 25.0);
    private final com.vengeance.vengeanceclient.r.r.za d = new com.vengeance.vengeanceclient.r.r.za("Auto Switch Back", true);
    private final com.vengeance.vengeanceclient.r.r.za e = new com.vengeance.vengeanceclient.r.r.za("Silent Swap", true);
    private final com.vengeance.vengeanceclient.r.r.za f = new com.vengeance.vengeanceclient.r.r.za("Toggle Mode", true);
    private final com.vengeance.vengeanceclient.utils.s.zb g = new com.vengeance.vengeanceclient.utils.s.zb();
    private boolean h = false;
    private boolean i = false;
    private int j = -1;
    private class_1799 k = class_1799.field_8037;
    private boolean l = true;
    private za m = za.a;

    public zj() {
        super("Elytra HotSwap", "Quickly swap to elytra and equip it, or swap back to chestplate", -1, com.vengeance.vengeanceclient.r.za.a);
        this.a(this.b, this.c, this.d, this.e, this.f);
        this.f().removeIf(zg2 -> zg2 instanceof zc && !zg2.equals(this.b));
    }

    @EventHandler
    private void onTickEvent(com.vengeance.vengeanceclient.p.p.q.za za2) {
        if (this.d()) {
            return;
        }
        boolean bl = com.vengeance.vengeanceclient.utils.r.za.b(this.b.e());
        if (bl && !this.h) {
            this.n();
        }
        this.h = bl;
        if (!this.i) {
            return;
        }
        if (!this.g.a(this.c.a())) {
            return;
        }
        switch (this.m.ordinal()) {
            case 1: {
                this.o();
                break;
            }
            case 2: {
                this.p();
                break;
            }
            case 3: {
                this.s();
            }
        }
    }

    private void n() {
        if (this.i) {
            return;
        }
        boolean bl = this.w();
        if (this.f.b() && bl) {
            this.l = false;
            int n = this.v();
            if (n == -1 && this.k.method_7960()) {
                return;
            }
        } else {
            this.l = true;
            int n = this.u();
            if (n == -1) {
                return;
            }
            if (!bl) {
                this.k = zj.a.field_1724.method_6118(class_1304.field_6174).method_7972();
            }
        }
        this.i = true;
        this.j = zj.a.field_1724.method_31548().field_7545;
        this.m = za.b;
        this.g.a();
    }

    private void o() {
        int n = this.l ? this.u() : this.v();
        if (n == -1) {
            if (!this.l && !this.k.method_7960()) {
                this.m = za.c;
                this.g.a();
                return;
            }
            this.t();
            return;
        }
        if (!this.e.b()) {
            zj.a.field_1724.method_31548().field_7545 = n;
        }
        this.m = za.c;
        this.g.a();
    }

    private void p() {
        if (this.l) {
            this.q();
        } else {
            this.r();
        }
        if (this.d.b() && !this.e.b()) {
            this.m = za.d;
        } else {
            this.t();
        }
        this.g.a();
    }

    private void q() {
        int n;
        int n2 = n = this.e.b() ? this.u() : zj.a.field_1724.method_31548().field_7545;
        if (n == -1) {
            this.t();
            return;
        }
        class_1799 class_17992 = zj.a.field_1724.method_31548().method_5438(n);
        if (class_17992.method_7960() || class_17992.method_7909() != class_1802.field_8833) {
            this.t();
            return;
        }
        if (this.e.b()) {
            int n3 = zj.a.field_1724.method_31548().field_7545;
            zj.a.field_1724.method_31548().field_7545 = n;
            if (zj.a.field_1761 != null) {
                ((MinecraftClientAccessor)a).invokeDoItemUse();
            }
            zj.a.field_1724.method_31548().field_7545 = n3;
        } else if (zj.a.field_1761 != null) {
            ((MinecraftClientAccessor)a).invokeDoItemUse();
        }
    }

    private void r() {
        class_1799 class_17992;
        int n = this.v();
        if (n != -1 && !(class_17992 = zj.a.field_1724.method_31548().method_5438(n)).method_7960() && this.a(class_17992)) {
            if (this.e.b()) {
                int n2 = zj.a.field_1724.method_31548().field_7545;
                zj.a.field_1724.method_31548().field_7545 = n;
                if (zj.a.field_1761 != null) {
                    ((MinecraftClientAccessor)a).invokeDoItemUse();
                }
                zj.a.field_1724.method_31548().field_7545 = n2;
            } else if (zj.a.field_1761 != null) {
                ((MinecraftClientAccessor)a).invokeDoItemUse();
            }
            return;
        }
        if (!this.k.method_7960()) {
            zj.a.field_1724.method_31548().method_5447(36 + zj.a.field_1724.method_31548().field_7545, this.k.method_7972());
            if (zj.a.field_1761 != null) {
                ((MinecraftClientAccessor)a).invokeDoItemUse();
            }
            this.k = class_1799.field_8037;
        }
    }

    private void s() {
        if (this.j != -1) {
            zj.a.field_1724.method_31548().field_7545 = this.j;
        }
        this.t();
    }

    private void t() {
        this.i = false;
        this.m = za.a;
        this.j = -1;
        this.l = true;
    }

    private int u() {
        for (int i = 0; i < 9; ++i) {
            class_1799 class_17992 = zj.a.field_1724.method_31548().method_5438(i);
            if (class_17992.method_7960() || class_17992.method_7909() != class_1802.field_8833) continue;
            return i;
        }
        return -1;
    }

    private int v() {
        for (int i = 0; i < 9; ++i) {
            class_1799 class_17992 = zj.a.field_1724.method_31548().method_5438(i);
            if (class_17992.method_7960() || !this.a(class_17992)) continue;
            return i;
        }
        return -1;
    }

    private boolean a(class_1799 class_17992) {
        if (class_17992.method_7960()) {
            return false;
        }
        return class_17992.method_7909() == class_1802.field_8058 || class_17992.method_7909() == class_1802.field_8523 || class_17992.method_7909() == class_1802.field_8678 || class_17992.method_7909() == class_1802.field_8577 || class_17992.method_7909() == class_1802.field_8873 || class_17992.method_7909() == class_1802.field_22028;
    }

    private boolean w() {
        class_1799 class_17992 = zj.a.field_1724.method_6118(class_1304.field_6174);
        return !class_17992.method_7960() && class_17992.method_7909() == class_1802.field_8833;
    }

    @Override
    public void b() {
        this.h = false;
        this.i = false;
        this.j = -1;
        this.k = class_1799.field_8037;
        this.l = true;
        this.m = za.a;
        super.b();
    }

    @Override
    public void c() {
        if (this.i) {
            this.t();
        }
        this.k = class_1799.field_8037;
        super.c();
    }

    @Override
    public int e() {
        return -1;
    }

    @Override
    public void a(int n) {
    }

    private static final class za
    extends Enum<za> {
        public static final /* enum */ za a = new za();
        public static final /* enum */ za b = new za();
        public static final /* enum */ za c = new za();
        public static final /* enum */ za d = new za();
        private static final /* synthetic */ za[] e;

        public static za[] values() {
            return (za[])e.clone();
        }

        public static za valueOf(String string) {
            return Enum.valueOf(za.class, string);
        }

        private static /* synthetic */ za[] a() {
            return new za[]{a, b, c, d};
        }

        static {
            e = za.a();
        }
    }
}

