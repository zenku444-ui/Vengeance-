/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1268
 *  net.minecraft.class_1297
 *  net.minecraft.class_1657
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_2246
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 *  net.minecraft.class_2374
 *  net.minecraft.class_2382
 *  net.minecraft.class_243
 *  net.minecraft.class_3532
 *  net.minecraft.class_3965
 */
package com.vengeance.vengeanceclient.r.q.q;

import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2374;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3965;

public class zk
extends zb {
    private static final double b = 0.05;
    private static final double c = 0.13;
    private static final double d = 0.26;

    public zk() {
        super("Hit Cob", "Places cobweb at player feet when you hit them (DO NOT USE ITS BEING TESTED)", za.a);
    }

    @EventHandler
    private void onAttack(com.vengeance.vengeanceclient.p.p.s.za za2) {
        class_2338 class_23382;
        class_1297 class_12972;
        if (this.d() || !((class_12972 = za2.a()) instanceof class_1657)) {
            return;
        }
        class_1657 class_16572 = (class_1657)class_12972;
        int n = this.n();
        if (n == -1) {
            return;
        }
        class_2338 class_23383 = class_16572.method_24515();
        if (zk.a.field_1687.method_8320(class_23383).method_26204() == class_2246.field_10343) {
            return;
        }
        if (zk.a.field_1687.method_8320(class_23383).method_26204() == class_2246.field_10382) {
            return;
        }
        double d = zk.a.field_1724.method_73189().method_1022(class_243.method_24953((class_2382)class_23383));
        if (d > 4.5) {
            return;
        }
        double d2 = Math.hypot(class_16572.method_18798().field_1352, class_16572.method_18798().field_1350);
        class_243 class_2432 = class_16572.method_73189().method_1020(zk.a.field_1724.method_73189()).method_1029();
        double d3 = d2 < 0.05 ? (zk.a.field_1724.method_5624() ? 1.8 : 1.2) : (d2 < 0.13 ? (zk.a.field_1724.method_5624() ? 1.5 : 1.0) : (d2 < 0.26 ? (zk.a.field_1724.method_5624() ? 1.2 : 0.8) : (zk.a.field_1724.method_5624() ? 1.0 : 0.7)));
        class_243 class_2433 = class_16572.method_73189().method_1019(class_2432.method_1021(d3));
        class_2338 class_23384 = class_2338.method_49638((class_2374)class_2433);
        if (zk.a.field_1687.method_8320(class_23384).method_26204() == class_2246.field_10343) {
            return;
        }
        if (zk.a.field_1687.method_8320(class_23384).method_26204() == class_2246.field_10382) {
            return;
        }
        if (!zk.a.field_1687.method_8320(class_23384).method_26215()) {
            class_23384 = class_23383;
        }
        if (zk.a.field_1687.method_8320(class_23382 = class_23384.method_10074()).method_26215()) {
            return;
        }
        if (zk.a.field_1724.method_73189().method_1022(class_243.method_24953((class_2382)class_23384)) > 4.5) {
            return;
        }
        int n2 = zk.a.field_1724.method_31548().field_7545;
        float f = zk.a.field_1724.method_36454();
        float f2 = zk.a.field_1724.method_36455();
        class_243 class_2434 = class_243.method_24953((class_2382)class_23382).method_1031(0.0, 0.5, 0.0);
        float[] fArray = this.a(class_2434);
        zk.a.field_1724.method_36456(fArray[0]);
        zk.a.field_1724.method_36457(fArray[1]);
        zk.a.field_1724.method_31548().field_7545 = n;
        class_3965 class_39652 = new class_3965(class_2434, class_2350.field_11036, class_23382, false);
        if (zk.a.field_1761 != null) {
            zk.a.field_1761.method_2896(zk.a.field_1724, class_1268.field_5808, class_39652);
        }
        zk.a.field_1724.method_31548().field_7545 = n2;
        zk.a.field_1724.method_36456(f);
        zk.a.field_1724.method_36457(f2);
    }

    private int n() {
        for (int i = 0; i < 9; ++i) {
            class_1799 class_17992 = zk.a.field_1724.method_31548().method_5438(i);
            if (class_17992.method_7960() || class_17992.method_7909() != class_1802.field_8786) continue;
            return i;
        }
        return -1;
    }

    private float[] a(class_243 class_2432) {
        class_243 class_2433 = class_2432.method_1020(zk.a.field_1724.method_33571());
        double d = Math.sqrt(class_2433.field_1352 * class_2433.field_1352 + class_2433.field_1350 * class_2433.field_1350);
        float f = (float)Math.toDegrees(Math.atan2(class_2433.field_1350, class_2433.field_1352)) - 90.0f;
        float f2 = (float)(-Math.toDegrees(Math.atan2(class_2433.field_1351, d)));
        return new float[]{class_3532.method_15393((float)f), class_3532.method_15363((float)f2, (float)-89.0f, (float)89.0f)};
    }
}

