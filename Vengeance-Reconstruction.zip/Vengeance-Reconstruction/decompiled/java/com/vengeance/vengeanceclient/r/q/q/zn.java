/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_2246
 *  net.minecraft.class_2338
 *  net.minecraft.class_2382
 *  net.minecraft.class_239
 *  net.minecraft.class_243
 *  net.minecraft.class_2680
 *  net.minecraft.class_2769
 *  net.minecraft.class_3489
 *  net.minecraft.class_3965
 *  net.minecraft.class_4969
 */
package com.vengeance.vengeanceclient.r.q.q;

import com.vengeance.vengeanceclient.mixin.MinecraftClientAccessor;
import com.vengeance.vengeanceclient.r.r.zc;
import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.minecraft.class_3489;
import net.minecraft.class_3965;
import net.minecraft.class_4969;

public final class zn
extends zb {
    private final zc b = new zc("Anchor Key", 88, false);
    private final ze c = new ze("Delay (MS)", 1.0, 500.0, 50.0, 1.0);
    private final ze d = new ze("Restore Delay", 1.0, 20.0, 2.0, 1.0);
    private final com.vengeance.vengeanceclient.utils.s.zb e = new com.vengeance.vengeanceclient.utils.s.zb();
    private boolean f = false;
    private boolean g = false;
    private int h = -1;
    private boolean i = false;
    private boolean j = false;
    private int k = 0;

    public zn() {
        super("Key Anchor", "Automatically places and explodes respawn anchors for PvP", -1, za.a);
        this.a(this.b, this.c, this.d);
        this.f().removeIf(zg2 -> zg2 instanceof zc && !zg2.equals(this.b));
    }

    @EventHandler
    private void onTickEvent(com.vengeance.vengeanceclient.p.p.q.za za2) {
        if (this.d() || !this.l()) {
            return;
        }
        if (zn.a.field_1755 != null) {
            return;
        }
        boolean bl = com.vengeance.vengeanceclient.utils.r.za.b(this.b.e());
        if (bl && !this.f) {
            this.n();
        } else if (!bl && this.f) {
            this.o();
        } else if (!bl) {
            this.i = false;
        }
        this.f = bl;
        if (this.g && this.e.a(this.c.a())) {
            this.p();
            this.e.a();
        }
        if (this.j) {
            if (this.k <= 0) {
                this.r();
                this.j = false;
            } else {
                --this.k;
            }
        }
    }

    private void n() {
        if (this.g) {
            return;
        }
        this.g = true;
        this.h = zn.a.field_1724.method_31548().field_7545;
        this.i = false;
        this.e.a();
    }

    private void o() {
        if (!this.g) {
            return;
        }
        if (this.h != -1) {
            zn.a.field_1724.method_31548().field_7545 = this.h;
        }
        this.g = false;
        this.h = -1;
        this.j = false;
        this.k = 0;
    }

    private void p() {
        class_239 class_2392 = zn.a.field_1765;
        if (!(class_2392 instanceof class_3965)) {
            return;
        }
        class_3965 class_39652 = (class_3965)class_2392;
        class_2392 = class_39652.method_17777();
        class_2680 class_26802 = zn.a.field_1687.method_8320((class_2338)class_2392);
        if (class_26802.method_26215()) {
            return;
        }
        if (class_26802.method_26204() == class_2246.field_23152) {
            int n = (Integer)class_26802.method_11654((class_2769)class_4969.field_23153);
            if (n > 0) {
                if (this.a(class_1802.field_8288) || this.q()) {
                    ((MinecraftClientAccessor)a).invokeDoItemUse();
                    this.s();
                    this.i = true;
                }
            } else if (this.a(class_1802.field_8801)) {
                ((MinecraftClientAccessor)a).invokeDoItemUse();
                this.i = true;
            }
            return;
        }
        class_2338 class_23382 = class_2392.method_10093(class_39652.method_17780());
        if (this.a(class_23382) && !this.i && this.a(class_1802.field_23141)) {
            this.i = true;
            ((MinecraftClientAccessor)a).invokeDoItemUse();
        }
    }

    private boolean a(class_2338 class_23382) {
        if (zn.a.field_1687 == null || zn.a.field_1724 == null) {
            return false;
        }
        if (zn.a.field_1724.method_73189().method_1022(class_243.method_24953((class_2382)class_23382)) > 4.5) {
            return false;
        }
        if (!zn.a.field_1687.method_8320(class_23382).method_26215()) {
            return false;
        }
        class_2338 class_23383 = zn.a.field_1724.method_24515();
        return !class_23382.equals((Object)class_23383) && !class_23382.equals((Object)class_23383.method_10084());
    }

    private boolean a(class_1792 class_17922) {
        for (int i = 0; i < 9; ++i) {
            class_1799 class_17992 = zn.a.field_1724.method_31548().method_5438(i);
            if (class_17992.method_7960() || class_17992.method_7909() != class_17922) continue;
            zn.a.field_1724.method_31548().field_7545 = i;
            return true;
        }
        return false;
    }

    private boolean q() {
        for (int i = 0; i < 9; ++i) {
            class_1799 class_17992 = zn.a.field_1724.method_31548().method_5438(i);
            if (class_17992.method_7960() || !class_17992.method_31573(class_3489.field_42611)) continue;
            zn.a.field_1724.method_31548().field_7545 = i;
            return true;
        }
        return false;
    }

    private void r() {
        if (this.h != -1) {
            zn.a.field_1724.method_31548().field_7545 = this.h;
        }
    }

    private void s() {
        if (this.h != -1) {
            this.j = true;
            this.k = this.d.a();
        }
    }

    @Override
    public void b() {
        this.f = false;
        this.g = false;
        this.h = -1;
        this.i = false;
        this.j = false;
        this.k = 0;
        this.e.a();
        super.b();
    }

    @Override
    public void c() {
        this.o();
        super.c();
    }

    @Override
    public int e() {
        return -1;
    }
}

