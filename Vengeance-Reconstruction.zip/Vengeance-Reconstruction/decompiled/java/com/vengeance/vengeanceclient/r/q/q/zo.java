/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1294
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1511
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_2246
 *  net.minecraft.class_2248
 *  net.minecraft.class_2338
 *  net.minecraft.class_2382
 *  net.minecraft.class_239
 *  net.minecraft.class_243
 *  net.minecraft.class_3965
 *  net.minecraft.class_3966
 */
package com.vengeance.vengeanceclient.r.q.q;

import com.vengeance.vengeanceclient.mixin.MinecraftClientAccessor;
import com.vengeance.vengeanceclient.r.r.zc;
import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import com.vengeance.vengeanceclient.utils.t.zd;
import java.util.List;
import java.util.Random;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1511;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

public final class zo
extends zb {
    private final zc b = new zc("Crystal Key", 3, false);
    private final com.vengeance.vengeanceclient.r.r.za c = new com.vengeance.vengeanceclient.r.r.za("Anti Suicide", true);
    private final com.vengeance.vengeanceclient.r.r.za d = new com.vengeance.vengeanceclient.r.r.za("Anti Weakness", true);
    private final com.vengeance.vengeanceclient.r.r.za e = new com.vengeance.vengeanceclient.r.r.za("Stop On Kill", false);
    private final ze f = new ze("Place Chance (%)", 0.0, 100.0, 100.0, 1.0);
    private final ze g = new ze("Break Chance (%)", 0.0, 100.0, 100.0, 1.0);
    private final ze h = new ze("Min Break Delay (MS)", 10.0, 500.0, 50.0, 1.0);
    private final ze i = new ze("Max Break Delay (MS)", 10.0, 500.0, 100.0, 1.0);
    private final ze j = new ze("Min Place Delay (MS)", 10.0, 500.0, 30.0, 1.0);
    private final ze k = new ze("Max Place Delay (MS)", 10.0, 500.0, 80.0, 1.0);
    private final com.vengeance.vengeanceclient.utils.s.zb l = new com.vengeance.vengeanceclient.utils.s.zb();
    private final com.vengeance.vengeanceclient.utils.s.zb m = new com.vengeance.vengeanceclient.utils.s.zb();
    private final Random n = new Random();
    private boolean o = false;
    private boolean p = false;
    private int q = -1;
    private boolean r = false;
    private long s;
    private long t;

    public zo() {
        super("Key Crystal", "Automatically places and explodes crystals and obsidian for PvP", -1, za.a);
        this.a(this.b, this.f, this.g, this.e, this.h, this.i, this.j, this.k, this.c, this.d);
        this.f().removeIf(zg2 -> zg2 instanceof zc && !zg2.equals(this.b));
    }

    @EventHandler
    private void onTickEvent(com.vengeance.vengeanceclient.p.p.q.za za2) {
        boolean bl;
        if (this.d() || zo.a.field_1755 != null) {
            return;
        }
        if (this.h.b() >= this.i.b()) {
            this.h.a(this.i.b() - 1.0f);
        }
        if (this.j.b() >= this.k.b()) {
            this.j.a(this.k.b() - 1.0f);
        }
        if ((bl = com.vengeance.vengeanceclient.utils.r.za.b(this.b.e())) && !this.o) {
            this.n();
        } else if (!bl && this.o) {
            this.o();
        }
        this.o = bl;
        if (this.p) {
            this.q();
        }
    }

    private void n() {
        if (this.p) {
            return;
        }
        this.p = true;
        this.q = zo.a.field_1724.method_31548().field_7545;
        this.r = false;
        this.p();
    }

    private void o() {
        if (!this.p) {
            return;
        }
        if (this.q != -1) {
            zo.a.field_1724.method_31548().field_7545 = this.q;
        }
        this.p = false;
        this.q = -1;
        this.r = false;
        this.p();
    }

    private void p() {
        this.l.a();
        this.m.a();
        int n = this.h.a();
        int n2 = this.i.a();
        int n3 = this.j.a();
        int n4 = this.k.a();
        if (n >= n2) {
            n2 = n + 1;
            this.i.a(n2);
        }
        if (n3 >= n4) {
            n4 = n3 + 1;
            this.k.a(n4);
        }
        this.s = n + this.n.nextInt(n2 - n);
        this.t = n3 + this.n.nextInt(n4 - n3);
    }

    private void q() {
        class_1297 class_12972;
        class_3966 class_39662;
        if (this.c.b() && !zo.a.field_1724.method_24828()) {
            return;
        }
        if (this.e.b() && this.r()) {
            return;
        }
        int n = this.n.nextInt(100) + 1;
        class_239 class_2392 = zo.a.field_1765;
        if (class_2392 instanceof class_3966) {
            class_39662 = (class_3966)class_2392;
            if (this.l.a(this.s) && (class_12972 = class_39662.method_17782()) instanceof class_1511) {
                class_2392 = (class_1511)class_12972;
                if (n <= this.g.a()) {
                    if (zo.a.field_1724.method_73189().method_1022(class_2392.method_73189()) <= 6.0) {
                        if (this.d.b() && zo.a.field_1724.method_6059(class_1294.field_5911)) {
                            zd.b();
                        }
                        ((MinecraftClientAccessor)a).invokeDoAttack();
                        this.l.a();
                        this.s = this.n.nextLong(this.h.a(), this.i.a());
                    }
                    return;
                }
            }
        }
        if ((class_2392 = zo.a.field_1765) instanceof class_3965) {
            class_39662 = (class_3965)class_2392;
            if (this.m.a(this.t)) {
                class_2338 class_23382;
                class_2392 = class_39662.method_17777();
                class_12972 = class_2392.method_10093(class_39662.method_17780());
                if (this.b((class_2338)class_2392) && this.c((class_2338)class_12972) && n <= this.f.a()) {
                    if (this.a(class_1802.field_8301)) {
                        zd.a(class_1802.field_8301);
                        ((MinecraftClientAccessor)a).invokeDoItemUse();
                        this.m.a();
                        this.t = this.n.nextLong(this.j.a(), this.k.a());
                    }
                } else if (this.a((class_2338)class_12972) && !this.r && !zo.a.field_1687.method_8320(class_23382 = class_12972.method_10074()).method_26215() && this.a(class_1802.field_8281)) {
                    zd.a(class_1802.field_8281);
                    ((MinecraftClientAccessor)a).invokeDoItemUse();
                    this.r = true;
                    this.m.a();
                    this.t = this.n.nextLong(this.j.a(), this.k.a());
                }
            }
        }
    }

    private boolean a(class_1792 class_17922) {
        for (int i = 0; i < 9; ++i) {
            class_1799 class_17992 = zo.a.field_1724.method_31548().method_5438(i);
            if (class_17992.method_7960() || class_17992.method_7909() != class_17922) continue;
            return true;
        }
        return false;
    }

    private boolean a(class_2338 class_23382) {
        if (zo.a.field_1687 == null) {
            return false;
        }
        if (zo.a.field_1724.method_73189().method_1022(class_243.method_24953((class_2382)class_23382)) > 4.5) {
            return false;
        }
        if (!zo.a.field_1687.method_8320(class_23382).method_26215()) {
            return false;
        }
        class_2338 class_23383 = zo.a.field_1724.method_24515();
        return !class_23382.equals((Object)class_23383) && !class_23382.equals((Object)class_23383.method_10084());
    }

    private boolean b(class_2338 class_23382) {
        if (zo.a.field_1687 == null) {
            return false;
        }
        class_2248 class_22482 = zo.a.field_1687.method_8320(class_23382).method_26204();
        return class_22482 == class_2246.field_10540 || class_22482 == class_2246.field_9987;
    }

    private boolean c(class_2338 class_23382) {
        if (zo.a.field_1687 == null) {
            return false;
        }
        if (zo.a.field_1724.method_73189().method_1022(class_243.method_24953((class_2382)class_23382)) > 4.5) {
            return false;
        }
        if (!zo.a.field_1687.method_8320(class_23382).method_26215()) {
            return false;
        }
        if (!zo.a.field_1687.method_8320(class_23382.method_10084()).method_26215()) {
            return false;
        }
        class_2338 class_23383 = zo.a.field_1724.method_24515();
        return !class_23382.equals((Object)class_23383) && !class_23382.equals((Object)class_23383.method_10084()) && !class_23382.method_10084().equals((Object)class_23383) && !class_23382.method_10084().equals((Object)class_23383.method_10084());
    }

    private boolean r() {
        if (zo.a.field_1687 == null) {
            return false;
        }
        List list = zo.a.field_1687.method_18456();
        for (class_1297 class_12972 : list) {
            if (class_12972 == zo.a.field_1724 || !class_12972.method_31481() && !(((class_1309)class_12972).method_6032() <= 0.0f) || !(class_12972.method_5858((class_1297)zo.a.field_1724) < 36.0)) continue;
            return true;
        }
        return false;
    }

    @Override
    public void c() {
        super.c();
        this.o();
    }

    @Override
    public int e() {
        return -1;
    }
}

