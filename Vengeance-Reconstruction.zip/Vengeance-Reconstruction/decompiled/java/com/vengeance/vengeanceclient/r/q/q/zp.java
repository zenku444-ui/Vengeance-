/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_2338
 *  net.minecraft.class_239
 *  net.minecraft.class_2680
 *  net.minecraft.class_3965
 */
package com.vengeance.vengeanceclient.r.q.q;

import com.vengeance.vengeanceclient.mixin.MinecraftClientAccessor;
import com.vengeance.vengeanceclient.p.p.s.zd;
import com.vengeance.vengeanceclient.r.r.zc;
import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_3965;

public final class zp
extends zb {
    private final zc b = new zc("Lava Key", 76, false);
    private final ze c = new ze("Restore Delay", 1.0, 20.0, 2.0, 1.0);
    private boolean d = false;
    private int e = -1;
    private int f = 0;
    private boolean g = false;
    private boolean h = false;
    private int i = 0;

    public zp() {
        super("Key Lava", "Places lava bucket and picks it back up in a 2-tick cycle", -1, za.a);
        this.a(this.b, this.c);
        this.f().removeIf(zg2 -> zg2 instanceof zc && !zg2.equals(this.b));
    }

    @EventHandler
    private void onTickEvent(zd zd2) {
        if (this.d() || !this.l()) {
            return;
        }
        if (zp.a.field_1755 != null) {
            return;
        }
        boolean bl = com.vengeance.vengeanceclient.utils.r.za.b(this.b.e());
        if (bl && !this.d) {
            this.n();
        } else if (!bl && this.d) {
            this.o();
        }
        this.d = bl;
        if (this.d && !this.g) {
            this.p();
        }
        if (this.h) {
            if (this.i <= 0) {
                this.r();
                this.h = false;
            } else {
                --this.i;
            }
        }
    }

    private void n() {
        this.e = zp.a.field_1724.method_31548().field_7545;
        this.f = 0;
        this.g = false;
    }

    private void o() {
        if (this.e != -1 && !this.h) {
            zp.a.field_1724.method_31548().field_7545 = this.e;
        }
        this.e = -1;
        this.f = 0;
        this.g = false;
        this.h = false;
        this.i = 0;
    }

    private void p() {
        class_239 class_2392 = zp.a.field_1765;
        if (!(class_2392 instanceof class_3965)) {
            return;
        }
        class_3965 class_39652 = (class_3965)class_2392;
        class_2392 = class_39652.method_17777();
        class_2680 class_26802 = zp.a.field_1687.method_8320((class_2338)class_2392);
        if (class_26802.method_26215()) {
            return;
        }
        if (this.f == 0) {
            if (this.a(class_1802.field_8187)) {
                ((MinecraftClientAccessor)a).invokeDoItemUse();
                ++this.f;
            }
        } else if (this.f == 1) {
            ((MinecraftClientAccessor)a).invokeDoItemUse();
            this.q();
            this.g = true;
        }
    }

    private void q() {
        if (this.e != -1) {
            this.h = true;
            this.i = this.c.a();
        }
    }

    private boolean a(class_1792 class_17922) {
        for (int i = 0; i < 9; ++i) {
            class_1799 class_17992 = zp.a.field_1724.method_31548().method_5438(i);
            if (class_17992.method_7960() || class_17992.method_7909() != class_17922) continue;
            zp.a.field_1724.method_31548().field_7545 = i;
            return true;
        }
        return false;
    }

    private void r() {
        if (this.e != -1) {
            zp.a.field_1724.method_31548().field_7545 = this.e;
        }
    }

    @Override
    public void b() {
        this.d = false;
        this.e = -1;
        this.f = 0;
        this.g = false;
        this.h = false;
        this.i = 0;
        super.b();
    }

    @Override
    public void c() {
        this.o();
        super.c();
    }

    @Override
    public int e() {
        return -1;
    }
}

