/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 */
package com.vengeance.vengeanceclient.r.q.q;

import com.vengeance.vengeanceclient.p.p.s.zd;
import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;

public class zq
extends zb {
    public static final ze b = new ze("Chance (%)", 1.0, 100.0, 100.0, 1.0);
    private final ze e = new ze("Ms", 1.0, 500.0, 60.0, 1.0);
    private final com.vengeance.vengeanceclient.r.r.za f = new com.vengeance.vengeanceclient.r.r.za("Only on ground", true);
    boolean c;
    com.vengeance.vengeanceclient.utils.s.zb d = new com.vengeance.vengeanceclient.utils.s.zb();

    public zq() {
        super("STap", "Makes you automatically STAP", -1, za.a);
        this.a(this.e, b, this.f);
    }

    @EventHandler
    private void onAttackEvent(com.vengeance.vengeanceclient.p.p.s.zb zb2) {
        if (this.d()) {
            return;
        }
        class_1297 class_12972 = zq.a.field_1692;
        if (class_12972 == null) {
            return;
        }
        if (!class_12972.method_5805()) {
            return;
        }
        if (!zq.a.field_1724.method_24828() && this.f.b()) {
            return;
        }
        if (Math.random() * 100.0 > (double)b.b()) {
            return;
        }
        if (!com.vengeance.vengeanceclient.utils.r.za.b(87)) {
            return;
        }
        if (zq.a.field_1724.method_5624()) {
            this.c = true;
            zq.a.field_1690.field_1881.method_23481(true);
        }
    }

    @EventHandler
    private void onTickEvent(zd zd2) {
        if (this.d()) {
            return;
        }
        if (!com.vengeance.vengeanceclient.utils.r.za.b(87)) {
            return;
        }
        if (this.d.a(this.e.a(), true) && this.c) {
            zq.a.field_1690.field_1881.method_23481(false);
            this.c = false;
        }
    }
}

