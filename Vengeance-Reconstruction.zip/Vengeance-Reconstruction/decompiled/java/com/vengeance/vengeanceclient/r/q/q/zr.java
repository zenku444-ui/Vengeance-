/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1268
 *  net.minecraft.class_1792
 *  net.minecraft.class_1802
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 *  net.minecraft.class_239
 *  net.minecraft.class_243
 *  net.minecraft.class_310
 *  net.minecraft.class_3965
 */
package com.vengeance.vengeanceclient.r.q.q;

import net.minecraft.class_1268;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3965;

public class zr {
    public void a(class_310 class_3102) {
        if (class_3102.field_1724 == null || class_3102.field_1687 == null || class_3102.field_1761 == null) {
            return;
        }
        int n = this.a(class_3102, class_1802.field_23141);
        int n2 = this.a(class_3102, class_1802.field_8801);
        if (n == -1 || n2 == -1) {
            return;
        }
        class_239 class_2392 = class_3102.field_1765;
        if (!(class_2392 instanceof class_3965)) {
            return;
        }
        class_3965 class_39652 = (class_3965)class_2392;
        class_3102.field_1724.method_31548().field_7545 = n;
        class_3102.field_1761.method_2896(class_3102.field_1724, class_1268.field_5808, class_39652);
        class_3102.field_1724.method_31548().field_7545 = n2;
        float f = class_3102.field_1724.method_36455();
        float f2 = class_3102.field_1724.method_36454();
        class_3102.field_1724.method_36457(80.0f);
        class_2338 class_23382 = class_3102.field_1724.method_24515();
        class_3965 class_39653 = new class_3965(new class_243((double)class_23382.method_10263() + 0.5, (double)class_23382.method_10264(), (double)class_23382.method_10260() + 0.5), class_2350.field_11036, class_23382, false);
        class_3102.field_1761.method_2896(class_3102.field_1724, class_1268.field_5808, class_39653);
        class_3102.field_1724.method_36457(f);
        class_3102.field_1724.method_36456(f2);
    }

    private int a(class_310 class_3102, class_1792 class_17922) {
        for (int i = 0; i < 9; ++i) {
            if (!class_3102.field_1724.method_31548().method_5438(i).method_31574(class_17922)) continue;
            return i;
        }
        return -1;
    }
}

