/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_1799
 *  net.minecraft.class_243
 *  net.minecraft.class_2960
 *  net.minecraft.class_3532
 *  net.minecraft.class_7923
 */
package com.vengeance.vengeanceclient.r.q.q;

import com.vengeance.vengeanceclient.r.q.r.zh;
import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import java.util.stream.StreamSupport;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_7923;

public final class zt
extends zb {
    private final com.vengeance.vengeanceclient.r.r.za b = new com.vengeance.vengeanceclient.r.r.za("Target Players Only", true);
    private final com.vengeance.vengeanceclient.r.r.za c = new com.vengeance.vengeanceclient.r.r.za("Ignore Friends", true);
    private final ze d = new ze("Lunge Strength", 0.0, 10.0, 5.0, 0.1);
    private final ze e = new ze("Lock Range", 1.0, 256.0, 64.0, 1.0);
    private final ze f = new ze("Charge Ticks", 1.0, 40.0, 10.0, 1.0);
    private int g = 0;
    private class_1297 h;

    public zt() {
        super("SpearKill", "Locks and lunges with spear while using it", za.a);
        this.a(this.b, this.c, this.d, this.e, this.f);
    }

    @EventHandler
    private void onHandleInput(com.vengeance.vengeanceclient.p.p.q.za za2) {
        class_1309 class_13092;
        class_1297 class_12972;
        if (this.d() || zt.a.field_1755 != null) {
            return;
        }
        if (!zt.a.field_1690.field_1904.method_1434() || !this.o()) {
            this.p();
            return;
        }
        ++this.g;
        if (this.h == null || !this.h.method_5805()) {
            this.h = this.n();
        }
        if (!((class_12972 = this.h) instanceof class_1309) || !(class_13092 = (class_1309)class_12972).method_5805()) {
            return;
        }
        if (!this.c((class_1297)class_13092)) {
            this.h = null;
            return;
        }
        this.a((class_1297)class_13092);
        if (this.g >= this.f.a()) {
            class_12972 = class_243.method_1030((float)zt.a.field_1724.method_36455(), (float)zt.a.field_1724.method_36454());
            zt.a.field_1724.method_5728(true);
            zt.a.field_1724.method_18799(class_12972.method_1021(this.d.f()));
        }
    }

    private void a(class_1297 class_12972) {
        class_243 class_2432 = zt.a.field_1724.method_33571();
        class_243 class_2433 = class_12972.method_5829().method_1005();
        class_243 class_2434 = class_2433.method_1020(class_2432).method_1029();
        float f = (float)(Math.toDegrees(Math.atan2(class_2434.field_1350, class_2434.field_1352)) - 90.0);
        float f2 = (float)(-Math.toDegrees(Math.asin(class_2434.field_1351)));
        zt.a.field_1724.method_36456(class_3532.method_15393((float)f));
        zt.a.field_1724.method_5847(class_3532.method_15393((float)f));
        zt.a.field_1724.method_36457(class_3532.method_15363((float)f2, (float)-89.0f, (float)89.0f));
    }

    private class_1297 n() {
        class_1309 class_13092;
        class_1297 class_12974 = zt.a.field_1692;
        if (class_12974 instanceof class_1309 && this.c((class_1297)(class_13092 = (class_1309)class_12974))) {
            return class_13092;
        }
        return StreamSupport.stream(zt.a.field_1687.method_18112().spliterator(), false).filter(class_12972 -> class_12972 instanceof class_1309).filter(this::c).filter(class_12972 -> class_12972.method_5858((class_1297)zt.a.field_1724) <= this.e.f() * this.e.f()).max((class_12972, class_12973) -> Double.compare(this.b((class_1297)class_12972), this.b((class_1297)class_12973))).orElse(null);
    }

    private double b(class_1297 class_12972) {
        class_243 class_2432 = zt.a.field_1724.method_33571();
        class_243 class_2433 = zt.a.field_1724.method_5828(1.0f).method_1029();
        class_243 class_2434 = class_12972.method_5829().method_1005().method_1020(class_2432).method_1029();
        double d = class_2433.method_1026(class_2434);
        double d2 = class_2432.method_1025(class_12972.method_5829().method_1005()) * 5.0E-4;
        return d - d2;
    }

    private boolean c(class_1297 class_12972) {
        if (!(class_12972 instanceof class_1309)) {
            return false;
        }
        if (class_12972 == zt.a.field_1724 || !class_12972.method_5805()) {
            return false;
        }
        if (class_12972.method_5739((class_1297)zt.a.field_1724) > this.e.b()) {
            return false;
        }
        if (this.b.b() && !(class_12972 instanceof class_1657)) {
            return false;
        }
        if (class_12972 instanceof class_1657) {
            class_1657 class_16572 = (class_1657)class_12972;
            if (zh.a((class_1297)class_16572)) {
                return false;
            }
            if (this.c.b() && com.vengeance.vengeanceclient.utils.q.za.c(class_16572.method_5667())) {
                return false;
            }
        }
        return true;
    }

    private boolean o() {
        return this.a(zt.a.field_1724.method_6047()) || this.a(zt.a.field_1724.method_6079());
    }

    private boolean a(class_1799 class_17992) {
        if (class_17992 == null || class_17992.method_7960()) {
            return false;
        }
        class_2960 class_29602 = class_7923.field_41178.method_10221((Object)class_17992.method_7909());
        if (class_29602 == null) {
            return false;
        }
        String string = class_29602.method_12832();
        return string.equals("spear") || string.endsWith("_spear") || string.contains("spear");
    }

    private void p() {
        this.g = 0;
        this.h = null;
    }

    @Override
    public void c() {
        this.p();
    }
}

