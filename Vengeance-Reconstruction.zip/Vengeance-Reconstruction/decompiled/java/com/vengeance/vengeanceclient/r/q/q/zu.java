/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1799
 *  net.minecraft.class_2960
 *  net.minecraft.class_7923
 */
package com.vengeance.vengeanceclient.r.q.q;

import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.r.zg;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class zu
extends zb {
    private final ze b = new ze("Switch Back Delay", 0.0, 200.0, 30.0, 1.0);
    private int c = -1;
    private int d = -1;
    private long e = 0L;
    private boolean f = false;
    private boolean g = false;

    public zu() {
        super("Auto Lunge", "Swaps to a lunge spear on left click then switches back", za.a);
        this.a(new zg[]{this.b});
    }

    @EventHandler
    private void onHandleInput(com.vengeance.vengeanceclient.p.p.q.za za2) {
        if (this.d()) {
            this.o();
            this.g = false;
            return;
        }
        if (this.f && System.currentTimeMillis() - this.e >= (long)this.b.a()) {
            if (this.c >= 0 && this.c < 9 && zu.a.field_1724.method_31548().field_7545 == this.d) {
                zu.a.field_1724.method_31548().field_7545 = this.c;
            }
            this.o();
        }
        boolean bl = zu.a.field_1690.field_1886.method_1434();
        if (zu.a.field_1755 != null || !bl || this.g) {
            this.g = bl;
            return;
        }
        this.g = true;
        int n = this.n();
        if (n == -1) {
            return;
        }
        int n2 = zu.a.field_1724.method_31548().field_7545;
        if (n2 == n) {
            return;
        }
        this.c = n2;
        this.d = n;
        zu.a.field_1724.method_31548().field_7545 = n;
        this.e = System.currentTimeMillis();
        this.f = true;
    }

    private int n() {
        for (int i = 0; i < 9; ++i) {
            class_1799 class_17992 = zu.a.field_1724.method_31548().method_5438(i);
            if (!this.a(class_17992) || !this.b(class_17992)) continue;
            return i;
        }
        return -1;
    }

    private boolean a(class_1799 class_17992) {
        if (class_17992 == null || class_17992.method_7960()) {
            return false;
        }
        class_2960 class_29602 = class_7923.field_41178.method_10221((Object)class_17992.method_7909());
        if (class_29602 == null) {
            return false;
        }
        String string = class_29602.method_12832();
        return string.equals("spear") || string.endsWith("_spear") || string.contains("spear");
    }

    private boolean b(class_1799 class_17992) {
        return class_17992.method_58657().method_57534().stream().anyMatch(class_68802 -> {
            String string = class_68802.method_55840().toLowerCase();
            return string.contains("lunge") || string.contains("lung");
        });
    }

    private void o() {
        this.c = -1;
        this.d = -1;
        this.e = 0L;
        this.f = false;
    }

    @Override
    public void c() {
        this.o();
        this.g = false;
    }
}

