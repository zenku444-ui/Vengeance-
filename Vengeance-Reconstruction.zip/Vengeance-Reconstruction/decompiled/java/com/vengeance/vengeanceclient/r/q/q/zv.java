/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1268
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_1922
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 *  net.minecraft.class_243
 *  net.minecraft.class_3965
 */
package com.vengeance.vengeanceclient.r.q.q;

import com.vengeance.vengeanceclient.p.p.s.zd;
import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_3965;

public class zv
extends zb {
    private final ze b = new ze("Prediction Time", 0.1, 2.0, 0.5, 0.1);
    private final ze c = new ze("Place Delay", 0.0, 200.0, 50.0, 10.0);
    private final com.vengeance.vengeanceclient.r.r.za d = new com.vengeance.vengeanceclient.r.r.za("Target Players", true);
    private final com.vengeance.vengeanceclient.r.r.za e = new com.vengeance.vengeanceclient.r.r.za("Target Mobs", false);
    private final com.vengeance.vengeanceclient.r.r.za f = new com.vengeance.vengeanceclient.r.r.za("Require Cobweb", true);
    private class_1297 g = null;
    private long h = 0L;

    public zv() {
        super("Stun Cob", "Predicts player movement and places cobweb", -1, za.a);
        this.a(this.b, this.c, this.d, this.e, this.f);
    }

    @EventHandler
    private void onAttack(com.vengeance.vengeanceclient.p.p.s.za za2) {
        if (this.d()) {
            return;
        }
        class_1297 class_12972 = za2.a();
        if (class_12972 == null || !this.b(class_12972)) {
            return;
        }
        this.g = class_12972;
        this.h = System.currentTimeMillis();
    }

    @EventHandler
    private void onTick(zd zd2) {
        if (this.d()) {
            return;
        }
        if (this.g == null) {
            return;
        }
        if ((double)(System.currentTimeMillis() - this.h) < this.c.f()) {
            return;
        }
        if (this.f.b() && !this.o()) {
            return;
        }
        class_243 class_2432 = this.a(this.g);
        if (class_2432 != null) {
            this.a(class_2432);
        }
        this.g = null;
    }

    private class_243 a(class_1297 class_12972) {
        class_2338 class_23382;
        if (!(class_12972 instanceof class_1309)) {
            return null;
        }
        class_243 class_2432 = class_12972.method_73189();
        class_243 class_2433 = class_12972.method_18798();
        boolean bl = zv.a.field_1724.method_5624();
        double d = bl ? 1.5 : 1.0;
        class_243 class_2434 = new class_243(class_2433.field_1352 * d, class_2433.field_1351, class_2433.field_1350 * d);
        double d2 = this.b.b();
        double d3 = 0.08;
        double d4 = 0.98;
        class_243 class_2435 = class_2432;
        class_243 class_2436 = class_2434;
        for (double d5 = 0.0; d5 < d2; d5 += 0.05) {
            class_2436 = new class_243(class_2436.field_1352 * d4, class_2436.field_1351 - d3 * 0.05, class_2436.field_1350 * d4);
            class_2435 = class_2435.method_1019(class_2436.method_1021(0.05));
            if (!(class_2435.field_1351 <= 0.0)) continue;
            class_2435 = new class_243(class_2435.field_1352, 0.0, class_2435.field_1350);
            break;
        }
        if (this.a(class_23382 = new class_2338((int)Math.floor(class_2435.field_1352), (int)Math.floor(class_2435.field_1351), (int)Math.floor(class_2435.field_1350)))) {
            return new class_243((double)class_23382.method_10263() + 0.5, (double)class_23382.method_10264(), (double)class_23382.method_10260() + 0.5);
        }
        return null;
    }

    private boolean a(class_2338 class_23382) {
        if (zv.a.field_1687 == null) {
            return false;
        }
        if (!zv.a.field_1687.method_8320(class_23382).method_26215()) {
            return false;
        }
        if (!zv.a.field_1687.method_8320(class_23382.method_10074()).method_26212((class_1922)zv.a.field_1687, class_23382.method_10074())) {
            return false;
        }
        double d = zv.a.field_1724.method_73189().method_1022(new class_243((double)class_23382.method_10263() + 0.5, (double)class_23382.method_10264(), (double)class_23382.method_10260() + 0.5));
        return d <= 4.5;
    }

    private void a(class_243 class_2432) {
        class_2338 class_23382 = new class_2338((int)Math.floor(class_2432.field_1352), (int)Math.floor(class_2432.field_1351), (int)Math.floor(class_2432.field_1350));
        if (!this.a(class_23382)) {
            return;
        }
        int n = this.n();
        if (n == -1) {
            return;
        }
        int n2 = zv.a.field_1724.method_31548().field_7545;
        zv.a.field_1724.method_31548().field_7545 = n;
        zv.a.field_1761.method_2896(zv.a.field_1724, class_1268.field_5808, new class_3965(class_2432, class_2350.field_11036, class_23382, false));
        zv.a.field_1724.method_31548().field_7545 = n2;
    }

    private int n() {
        for (int i = 0; i < 9; ++i) {
            class_1799 class_17992 = zv.a.field_1724.method_31548().method_5438(i);
            if (class_17992.method_7909() != class_1802.field_8786) continue;
            return i;
        }
        return -1;
    }

    private boolean o() {
        return this.n() != -1;
    }

    private boolean b(class_1297 class_12972) {
        if (class_12972 == null || class_12972 == zv.a.field_1724 || class_12972 == zv.a.field_1719) {
            return false;
        }
        if (!(class_12972 instanceof class_1309)) {
            return false;
        }
        class_1309 class_13092 = (class_1309)class_12972;
        if (!class_13092.method_5805() || class_13092.method_29504()) {
            return false;
        }
        if (com.vengeance.vengeanceclient.utils.q.za.c(class_12972.method_5667())) {
            return false;
        }
        if (class_12972 instanceof class_1657) {
            return this.d.b();
        }
        return this.e.b();
    }

    @Override
    public void b() {
        this.g = null;
        this.h = 0L;
    }

    @Override
    public void c() {
        this.g = null;
        this.h = 0L;
    }
}

