/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1511
 *  net.minecraft.class_1743
 *  net.minecraft.class_1792
 *  net.minecraft.class_239
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_3489
 *  net.minecraft.class_3966
 *  net.minecraft.class_9362
 */
package com.vengeance.vengeanceclient.r.q.q;

import com.vengeance.vengeanceclient.mixin.MinecraftClientAccessor;
import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.r.zg;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_239;
import net.minecraft.class_3489;
import net.minecraft.class_3966;
import net.minecraft.class_9362;

public class zx
extends zb {
    private final ze b = new ze("Switch Delay", 10.0, 100.0, 30.0, 1.0);
    private int c = -1;
    private boolean d = false;
    private long e = 0L;
    private boolean f = false;

    public zx() {
        super("Sword Swap", "Switches to sword when attacking with any non-axe/mace item", za.a);
        this.a(new zg[]{this.b});
    }

    @EventHandler
    public void onTick(com.vengeance.vengeanceclient.p.p.q.za za2) {
        boolean bl;
        if (this.d()) {
            return;
        }
        if (this.d && (double)(System.currentTimeMillis() - this.e) >= this.b.f()) {
            if (this.c != -1) {
                zx.a.field_1724.method_31548().field_7545 = this.c;
                this.c = -1;
            }
            this.d = false;
        }
        if ((bl = zx.a.field_1690.field_1886.method_1434()) && !this.f) {
            int n;
            class_1297 class_12972;
            class_239 class_2392;
            class_1792 class_17922 = zx.a.field_1724.method_6047().method_7909();
            boolean bl2 = class_17922 instanceof class_1743;
            boolean bl3 = class_17922 instanceof class_9362;
            boolean bl4 = zx.a.field_1724.method_6047().method_31573(class_3489.field_42611);
            if (!(bl2 || bl3 || bl4 || (class_2392 = zx.a.field_1765) == null || class_2392.method_17783() != class_239.class_240.field_1331 || (class_12972 = ((class_3966)class_2392).method_17782()) == null || class_12972 instanceof class_1511 || (n = this.n()) == -1)) {
                this.c = zx.a.field_1724.method_31548().field_7545;
                zx.a.field_1724.method_31548().field_7545 = n;
                ((MinecraftClientAccessor)a).invokeDoAttack();
                this.e = System.currentTimeMillis();
                this.d = true;
            }
        }
        this.f = bl;
    }

    private int n() {
        for (int i = 0; i < 9; ++i) {
            if (!zx.a.field_1724.method_31548().method_5438(i).method_31573(class_3489.field_42611)) continue;
            return i;
        }
        return -1;
    }

    @Override
    public void c() {
        if (this.c != -1) {
            zx.a.field_1724.method_31548().field_7545 = this.c;
            this.c = -1;
        }
        this.d = false;
        this.f = false;
    }
}

