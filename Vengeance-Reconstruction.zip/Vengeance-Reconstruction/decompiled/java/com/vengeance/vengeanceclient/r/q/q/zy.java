/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1294
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_1842
 *  net.minecraft.class_1844
 *  net.minecraft.class_6880
 *  net.minecraft.class_9334
 */
package com.vengeance.vengeanceclient.r.q.q;

import com.vengeance.vengeanceclient.mixin.MinecraftClientAccessor;
import com.vengeance.vengeanceclient.r.r.zc;
import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import java.util.ArrayList;
import java.util.List;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1294;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1842;
import net.minecraft.class_1844;
import net.minecraft.class_6880;
import net.minecraft.class_9334;

public final class zy
extends zb {
    private static final zc b = new zc("Throw Key", 71, false);
    private static final ze c = new ze("Throw Delay", 50.0, 1000.0, 250.0, 50.0);
    private static final ze d = new ze("Health Threshold", 1.0, 20.0, 10.0, 0.5);
    private static final com.vengeance.vengeanceclient.r.r.za e = new com.vengeance.vengeanceclient.r.r.za("Multi Throw", true);
    private static final ze f = new ze("Pot Delay", 50.0, 500.0, 150.0, 25.0);
    private static final com.vengeance.vengeanceclient.r.r.za g = new com.vengeance.vengeanceclient.r.r.za("Auto Switch Back", true);
    private static final com.vengeance.vengeanceclient.r.r.za h = new com.vengeance.vengeanceclient.r.r.za("Look Down", true);
    private final com.vengeance.vengeanceclient.utils.s.zb i = new com.vengeance.vengeanceclient.utils.s.zb();
    private final com.vengeance.vengeanceclient.utils.s.zb j = new com.vengeance.vengeanceclient.utils.s.zb();
    private final List<Integer> k = new ArrayList<Integer>();
    private int l = -1;
    private float m = 0.0f;
    private boolean n = false;
    private boolean o = false;
    private int p = 0;
    private int q = 0;

    public zy() {
        super("Throw Pot", "Throws instant health potions based on health levels", -1, za.a);
        this.a(b, c, d, e, f, g, h);
        this.f().removeIf(zg2 -> zg2 instanceof zc && !zg2.equals(b));
    }

    @EventHandler
    private void onTickEvent(com.vengeance.vengeanceclient.p.p.q.za za2) {
        if (this.d()) {
            return;
        }
        boolean bl = com.vengeance.vengeanceclient.utils.r.za.b(b.e());
        if (bl && !this.n && !this.o && this.i.a(c.a()) && zy.a.field_1724.method_6032() <= d.b()) {
            this.n();
            this.i.a();
        }
        this.n = bl;
        if (this.o && this.j.a(f.a()) && this.q < this.p) {
            this.o();
        }
        if (this.o && this.q >= this.p && this.i.a(100L)) {
            this.p();
        }
    }

    private void n() {
        this.q();
        if (this.k.isEmpty()) {
            return;
        }
        if (this.l == -1) {
            this.l = zy.a.field_1724.method_31548().field_7545;
        }
        if (h.b()) {
            this.m = zy.a.field_1724.method_36455();
            zy.a.field_1724.method_36457(89.9f);
        }
        this.p = e.b() ? Math.min(3, this.k.size()) : 1;
        this.q = 0;
        this.o = true;
        this.j.a();
    }

    private void o() {
        int n;
        zy.a.field_1724.method_31548().field_7545 = n = this.k.get(this.q % this.k.size()).intValue();
        ((MinecraftClientAccessor)a).invokeDoItemUse();
        ++this.q;
        this.j.a();
    }

    private void p() {
        if (g.b() && this.l != -1) {
            zy.a.field_1724.method_31548().field_7545 = this.l;
        }
        if (h.b()) {
            zy.a.field_1724.method_36457(this.m);
        }
        this.o = false;
        this.p = 0;
        this.q = 0;
    }

    private void q() {
        this.k.clear();
        for (int i = 0; i < 9; ++i) {
            if (!this.a(zy.a.field_1724.method_31548().method_5438(i))) continue;
            this.k.add(i);
        }
    }

    private boolean a(class_1799 class_17992) {
        if (class_17992.method_7909() != class_1802.field_8436) {
            return false;
        }
        class_1844 class_18442 = (class_1844)class_17992.method_58694(class_9334.field_49651);
        if (class_18442 == null) {
            return false;
        }
        if (class_18442.comp_2378().isPresent()) {
            class_6880 class_68802 = (class_6880)class_18442.comp_2378().get();
            return ((class_1842)class_68802.comp_349()).method_8049().stream().anyMatch(class_12932 -> class_12932.method_5579().equals((Object)class_1294.field_5915));
        }
        return class_18442.comp_2380().stream().anyMatch(class_12932 -> class_12932.method_5579().equals((Object)class_1294.field_5915));
    }

    @Override
    public void b() {
        this.n = false;
        this.l = -1;
        this.m = 0.0f;
        this.o = false;
        this.p = 0;
        this.q = 0;
        this.k.clear();
        this.i.a();
        this.j.a();
        super.b();
    }

    @Override
    public void c() {
        if (g.b() && this.l != -1) {
            zy.a.field_1724.method_31548().field_7545 = this.l;
        }
        if (h.b()) {
            zy.a.field_1724.method_36457(this.m);
        }
        this.k.clear();
        this.l = -1;
        this.m = 0.0f;
        this.n = false;
        this.o = false;
        this.p = 0;
        this.q = 0;
        super.c();
    }

    @Override
    public int e() {
        return -1;
    }
}

