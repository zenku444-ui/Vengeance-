/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1802
 *  net.minecraft.class_239
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_3489
 *  net.minecraft.class_3966
 */
package com.vengeance.vengeanceclient.r.q.q;

import com.vengeance.vengeanceclient.mixin.MinecraftClientAccessor;
import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.r.zg;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1802;
import net.minecraft.class_239;
import net.minecraft.class_3489;
import net.minecraft.class_3966;

public class zz
extends zb {
    private final ze b = new ze("Switch Delay", 10.0, 100.0, 30.0, 1.0);
    private int c = -1;
    private boolean d = false;
    private long e = 0L;
    private boolean f = false;

    public zz() {
        super("Totem Hit", "Switches to sword when attacking with totem", za.a);
        this.a(new zg[]{this.b});
    }

    @EventHandler
    public void onTick(com.vengeance.vengeanceclient.p.p.q.za za2) {
        int n;
        class_1297 class_12972;
        class_239 class_2392;
        boolean bl;
        if (this.d()) {
            return;
        }
        if (this.d && (double)(System.currentTimeMillis() - this.e) >= this.b.f()) {
            if (this.c != -1) {
                zz.a.field_1724.method_31548().field_7545 = this.c;
                this.c = -1;
            }
            this.d = false;
        }
        if ((bl = zz.a.field_1690.field_1886.method_1434()) && !this.f && zz.a.field_1724.method_6047().method_7909() == class_1802.field_8288 && (class_2392 = zz.a.field_1765) != null && class_2392.method_17783() == class_239.class_240.field_1331 && (class_12972 = ((class_3966)class_2392).method_17782()) != null && (n = this.n()) != -1) {
            this.c = zz.a.field_1724.method_31548().field_7545;
            zz.a.field_1724.method_31548().field_7545 = n;
            ((MinecraftClientAccessor)a).invokeDoAttack();
            this.e = System.currentTimeMillis();
            this.d = true;
        }
        this.f = bl;
    }

    private int n() {
        for (int i = 0; i < 9; ++i) {
            if (!zz.a.field_1724.method_31548().method_5438(i).method_31573(class_3489.field_42611)) continue;
            return i;
        }
        return -1;
    }

    @Override
    public void c() {
        if (this.c != -1) {
            zz.a.field_1724.method_31548().field_7545 = this.c;
            this.c = -1;
        }
        this.d = false;
        this.f = false;
    }
}

