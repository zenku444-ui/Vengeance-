/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1753
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_2338
 *  net.minecraft.class_239
 *  net.minecraft.class_3965
 */
package com.vengeance.vengeanceclient.r.q.r;

import com.vengeance.vengeanceclient.mixin.MinecraftClientAccessor;
import com.vengeance.vengeanceclient.p.p.s.zd;
import com.vengeance.vengeanceclient.r.r.zc;
import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.zb;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1753;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_3965;

public final class za
extends zb {
    private final zc b = new zc("Key", 67, true);
    private final ze c = new ze("Delay", 50.0, 500.0, 150.0, 25.0);
    private final com.vengeance.vengeanceclient.r.r.za d = new com.vengeance.vengeanceclient.r.r.za("Silent", true);
    private final com.vengeance.vengeanceclient.r.r.za e = new com.vengeance.vengeanceclient.r.r.za("Switch Back", true);
    private final ze f = new ze("Switch Delay", 100.0, 1000.0, 250.0, 50.0);
    private final com.vengeance.vengeanceclient.r.r.za g = new com.vengeance.vengeanceclient.r.r.za("Auto Bow", true);
    private final ze h = new ze("Bow Window", 500.0, 2000.0, 1000.0, 100.0);
    private boolean i;
    private boolean j;
    private int k = -1;
    private long l;
    private long m;
    private za n = za.a;

    public za() {
        super("Cart Key", "Places rail + TNT cart, auto switches to bow", -1, com.vengeance.vengeanceclient.r.za.e);
        this.a(this.b, this.c, this.d, this.e, this.f, this.g, this.h);
    }

    @EventHandler
    private void onTickEvent(zd zd2) {
        if (this.d() || za.a.field_1755 != null) {
            return;
        }
        boolean bl = com.vengeance.vengeanceclient.utils.r.za.b(this.b.e());
        boolean bl2 = za.a.field_1690.field_1904.method_1434();
        long l = System.currentTimeMillis();
        if (bl && !this.i && this.n == za.a && this.n()) {
            this.k = za.a.field_1724.method_31548().field_7545;
            this.n = za.b;
            this.l = l;
        }
        this.i = bl;
        switch (this.n.ordinal()) {
            case 0: {
                break;
            }
            case 1: {
                if (l - this.l < (long)this.c.a()) break;
                this.a(l);
                break;
            }
            case 2: {
                if (l - this.l < (long)this.c.a()) break;
                this.b(l);
                break;
            }
            case 3: {
                if (l - this.l < (long)this.f.a()) break;
                this.o();
                break;
            }
            case 4: {
                if (bl2) {
                    this.p();
                    break;
                }
                if (l - this.m < (long)this.h.a()) break;
                this.s();
                break;
            }
            case 5: {
                if (bl2 || !this.j) break;
                this.q();
            }
        }
    }

    private boolean n() {
        class_239 class_2392 = za.a.field_1765;
        if (!(class_2392 instanceof class_3965)) {
            return false;
        }
        class_3965 class_39652 = (class_3965)class_2392;
        class_2392 = class_39652.method_17777().method_10093(class_39652.method_17780());
        return za.a.field_1687 != null && za.a.field_1724 != null && za.a.field_1724.method_73189().method_1022(class_2392.method_46558()) <= 4.5 && za.a.field_1687.method_8320((class_2338)class_2392).method_26215() && this.a(class_1802.field_8129) && this.a(class_1802.field_8069);
    }

    private void a(long l) {
        if (this.b(class_1802.field_8129)) {
            this.n = za.c;
            this.l = l;
        } else {
            this.s();
        }
    }

    private void b(long l) {
        if (this.b(class_1802.field_8069)) {
            if (this.g.b()) {
                this.n = za.e;
                this.m = l;
            } else if (this.e.b() && this.k != -1) {
                this.n = za.d;
                this.l = l;
            } else {
                this.s();
            }
        } else {
            this.s();
        }
    }

    private void o() {
        if (this.k != -1) {
            za.a.field_1724.method_31548().field_7545 = this.k;
        }
        this.s();
    }

    private void p() {
        int n = this.r();
        if (n != -1) {
            za.a.field_1724.method_31548().field_7545 = n;
            this.n = za.f;
            this.j = true;
        } else {
            this.s();
        }
    }

    private void q() {
        this.j = false;
        if (this.e.b() && this.k != -1) {
            int n = this.k;
            this.s();
            new Thread(() -> {
                try {
                    Thread.sleep(100L);
                }
                catch (InterruptedException interruptedException) {
                    // empty catch block
                }
                if (za.a.field_1724 != null) {
                    za.a.field_1724.method_31548().field_7545 = n;
                }
            }).start();
        } else {
            this.s();
        }
    }

    private boolean a(class_1792 class_17922) {
        return this.c(class_17922) != -1;
    }

    private boolean b(class_1792 class_17922) {
        int n = this.c(class_17922);
        if (n == -1) {
            return false;
        }
        if (this.d.b()) {
            int n2 = za.a.field_1724.method_31548().field_7545;
            za.a.field_1724.method_31548().field_7545 = n;
            ((MinecraftClientAccessor)a).invokeDoItemUse();
            za.a.field_1724.method_31548().field_7545 = n2;
        } else {
            za.a.field_1724.method_31548().field_7545 = n;
            ((MinecraftClientAccessor)a).invokeDoItemUse();
        }
        return true;
    }

    private int c(class_1792 class_17922) {
        for (int i = 0; i < 9; ++i) {
            class_1799 class_17992 = za.a.field_1724.method_31548().method_5438(i);
            if (class_17992.method_7960() || class_17992.method_7909() != class_17922) continue;
            return i;
        }
        return -1;
    }

    private int r() {
        for (int i = 0; i < 9; ++i) {
            class_1799 class_17992 = za.a.field_1724.method_31548().method_5438(i);
            if (class_17992.method_7960() || !(class_17992.method_7909() instanceof class_1753)) continue;
            return i;
        }
        return -1;
    }

    private void s() {
        this.n = za.a;
        this.k = -1;
        this.j = false;
    }

    @Override
    public void b() {
        this.i = false;
        this.s();
        super.b();
    }

    @Override
    public void c() {
        this.s();
        super.c();
    }

    private static final class za
    extends Enum<za> {
        public static final /* enum */ za a = new za();
        public static final /* enum */ za b = new za();
        public static final /* enum */ za c = new za();
        public static final /* enum */ za d = new za();
        public static final /* enum */ za e = new za();
        public static final /* enum */ za f = new za();
        private static final /* synthetic */ za[] g;

        public static za[] values() {
            return (za[])g.clone();
        }

        public static za valueOf(String string) {
            return Enum.valueOf(za.class, string);
        }

        private static /* synthetic */ za[] a() {
            return new za[]{a, b, c, d, e, f};
        }

        static {
            g = za.a();
        }
    }
}

