/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Multimap
 *  com.mojang.authlib.GameProfile
 *  net.minecraft.class_1293
 *  net.minecraft.class_1294
 *  net.minecraft.class_1297
 *  net.minecraft.class_1304
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_1935
 *  net.minecraft.class_2394
 *  net.minecraft.class_2398
 *  net.minecraft.class_3417
 *  net.minecraft.class_745
 */
package com.vengeance.vengeanceclient.r.q.r;

import com.google.common.collect.Multimap;
import com.mojang.authlib.GameProfile;
import com.vengeance.vengeanceclient.r.za;
import java.util.UUID;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1935;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_3417;
import net.minecraft.class_745;

public class zb
extends com.vengeance.vengeanceclient.r.zb {
    private final com.vengeance.vengeanceclient.r.r.za b = new com.vengeance.vengeanceclient.r.r.za("Invincible", false);
    private final com.vengeance.vengeanceclient.r.r.za c = new com.vengeance.vengeanceclient.r.r.za("Critical Hits", true);
    private final com.vengeance.vengeanceclient.r.r.za d = new com.vengeance.vengeanceclient.r.r.za("Use Totem", false);
    private class_745 e;
    private float f = 20.0f;
    private long g = 0L;
    private int h = 0;

    public zb() {
        super("Fake Player", "Spawns a fake player for making configs (Only works in single player)", za.e);
        this.a(this.b, this.c, this.d);
    }

    @Override
    public void b() {
        super.b();
        this.q();
    }

    @Override
    public void c() {
        super.c();
        this.r();
    }

    @EventHandler
    private void onWorldChange(com.vengeance.vengeanceclient.p.p.u.za za2) {
        this.r();
    }

    @EventHandler
    private void onAttack(com.vengeance.vengeanceclient.p.p.s.za za2) {
        if (this.e == null || this.d()) {
            return;
        }
        if (za2.a() == this.e) {
            this.c(this.n());
        }
    }

    private boolean n() {
        if (zb.a.field_1724 == null) {
            return false;
        }
        boolean bl = zb.a.field_1724.method_18798().field_1351 < (double)-0.08f;
        boolean bl2 = zb.a.field_1724.method_5715();
        boolean bl3 = zb.a.field_1724.method_24828();
        boolean bl4 = zb.a.field_1724.method_6115();
        boolean bl5 = zb.a.field_1724.method_5854() != null;
        boolean bl6 = zb.a.field_1724.method_5799();
        boolean bl7 = zb.a.field_1724.method_5771();
        return bl && !bl2 && !bl3 && !bl4 && !bl5 && !bl6 && !bl7;
    }

    private void c(boolean bl) {
        float f;
        float f2;
        if (System.currentTimeMillis() - this.g < 500L) {
            return;
        }
        this.g = System.currentTimeMillis();
        ++this.h;
        boolean bl2 = false;
        if (this.d.b()) {
            if (this.b.b()) {
                if (this.h % 2 == 0) {
                    bl2 = true;
                }
            } else {
                f2 = 2.0f + (float)(Math.random() * 4.0);
                float f3 = f = bl ? f2 * 1.5f : f2;
                if (this.f - f <= 0.0f) {
                    bl2 = true;
                    this.f = 1.0f;
                }
            }
        }
        if (bl2) {
            this.p();
        }
        if (!this.b.b() && !bl2) {
            f2 = 2.0f + (float)(Math.random() * 4.0);
            f = bl ? f2 * 1.5f : f2;
            this.f = Math.max(0.0f, this.f - f);
        }
        this.d(bl);
        if (this.f <= 0.0f && !this.b.b()) {
            this.o();
        }
    }

    private void d(boolean bl) {
        double d;
        double d2;
        double d3;
        int n;
        if (this.e == null || zb.a.field_1687 == null) {
            return;
        }
        int n2 = bl ? 8 : 5;
        for (n = 0; n < n2; ++n) {
            d3 = (Math.random() - 0.5) * 0.5;
            d2 = Math.random() * 1.8;
            d = (Math.random() - 0.5) * 0.5;
            zb.a.field_1687.method_8406((class_2394)class_2398.field_11209, this.e.method_23317() + d3, this.e.method_23318() + d2, this.e.method_23321() + d, 0.0, 0.0, 0.0);
        }
        if (bl && this.c.b()) {
            for (n = 0; n < 5; ++n) {
                d3 = (Math.random() - 0.5) * 0.8;
                d2 = Math.random() * 1.8;
                d = (Math.random() - 0.5) * 0.8;
                zb.a.field_1687.method_8406((class_2394)class_2398.field_11205, this.e.method_23317() + d3, this.e.method_23318() + d2, this.e.method_23321() + d, 0.0, 0.0, 0.0);
            }
        }
        if (bl && this.c.b()) {
            zb.a.field_1687.method_8396((class_1297)zb.a.field_1724, this.e.method_24515(), class_3417.field_15016, this.e.method_5634(), 1.0f, 1.0f);
        } else {
            zb.a.field_1687.method_8396((class_1297)zb.a.field_1724, this.e.method_24515(), class_3417.field_15115, this.e.method_5634(), 1.0f, 1.0f);
        }
        this.e.field_6235 = 10;
    }

    private void o() {
        this.r();
        this.f = 20.0f;
        this.h = 0;
        new Thread(() -> {
            try {
                Thread.sleep(1000L);
                if (this.l()) {
                    this.q();
                }
            }
            catch (InterruptedException interruptedException) {
                Thread.currentThread().interrupt();
            }
        }).start();
    }

    private void p() {
        if (this.e == null || zb.a.field_1687 == null) {
            return;
        }
        this.e.method_6092(new class_1293(class_1294.field_5898, 100, 1));
        this.e.method_6092(new class_1293(class_1294.field_5924, 800, 1));
        zb.a.field_1687.method_43128(null, this.e.method_23317(), this.e.method_23318(), this.e.method_23321(), class_3417.field_14931, this.e.method_5634(), 1.0f, 1.0f);
        for (int i = 0; i < 30; ++i) {
            double d = (zb.a.field_1687.field_9229.method_43058() - 0.5) * 2.0;
            double d2 = zb.a.field_1687.field_9229.method_43058() * 2.0;
            double d3 = (zb.a.field_1687.field_9229.method_43058() - 0.5) * 2.0;
            zb.a.field_1687.method_8406((class_2394)class_2398.field_11220, this.e.method_23317() + d, this.e.method_23318() + d2, this.e.method_23321() + d3, 0.0, 0.1, 0.0);
        }
        this.e.method_5673(class_1304.field_6171, new class_1799((class_1935)class_1802.field_8288));
        new Thread(() -> {
            try {
                Thread.sleep(500L);
                if (this.e != null) {
                    this.e.method_5673(class_1304.field_6171, class_1799.field_8037);
                }
            }
            catch (InterruptedException interruptedException) {
                Thread.currentThread().interrupt();
            }
        }).start();
    }

    private void q() {
        if (this.d()) {
            return;
        }
        if (!a.method_1542()) {
            return;
        }
        if (this.e != null) {
            return;
        }
        GameProfile gameProfile = zb.a.field_1724.method_7334();
        GameProfile gameProfile2 = new GameProfile(UUID.randomUUID(), gameProfile.name());
        gameProfile2.properties().putAll((Multimap)gameProfile.properties());
        class_745 class_7452 = new class_745(zb.a.field_1687, gameProfile2);
        class_7452.method_5719((class_1297)zb.a.field_1724);
        class_7452.method_36456(zb.a.field_1724.method_36454());
        class_7452.method_36457(zb.a.field_1724.method_36455());
        for (class_1304 class_13042 : class_1304.values()) {
            class_1799 class_17992 = zb.a.field_1724.method_6118(class_13042);
            if (class_17992.method_7960()) continue;
            class_7452.method_5673(class_13042, class_17992.method_7972());
        }
        zb.a.field_1687.method_53875((class_1297)class_7452);
        this.e = class_7452;
    }

    private void r() {
        if (this.e == null) {
            return;
        }
        if (!this.d()) {
            this.e.method_31472();
        }
        this.e = null;
    }
}

