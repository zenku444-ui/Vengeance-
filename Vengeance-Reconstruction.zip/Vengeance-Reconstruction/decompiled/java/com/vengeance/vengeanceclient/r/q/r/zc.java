/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_437
 */
package com.vengeance.vengeanceclient.r.q.r;

import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import net.minecraft.class_437;

public class zc
extends zb {
    public zc() {
        super("Friends", "Manage your friends list", za.e);
    }

    @Override
    public void b() {
        if (zc.a.field_1724 != null) {
            a.method_1507((class_437)new com.vengeance.vengeanceclient.q.zc());
        }
        this.a(false);
    }
}

