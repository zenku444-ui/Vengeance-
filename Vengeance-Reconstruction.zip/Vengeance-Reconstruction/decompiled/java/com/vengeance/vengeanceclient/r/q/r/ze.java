/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1657
 *  net.minecraft.class_239
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_2561
 *  net.minecraft.class_3966
 */
package com.vengeance.vengeanceclient.r.q.r;

import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_239;
import net.minecraft.class_2561;
import net.minecraft.class_3966;

public final class ze
extends zb {
    public ze() {
        super("Middle Click Friend", "Middle click on players to add/remove them from friends list", -1, za.e);
    }

    @EventHandler
    private void onMouseClick(com.vengeance.vengeanceclient.p.p.q.zb zb2) {
        if (zb2.a() == 2 && zb2.b() == 1) {
            class_3966 class_39662;
            class_1297 class_12972;
            if (this.d()) {
                return;
            }
            class_239 class_2392 = ze.a.field_1765;
            if (class_2392 != null && class_2392.method_17783() == class_239.class_240.field_1331 && (class_12972 = (class_39662 = (class_3966)class_2392).method_17782()) instanceof class_1657) {
                class_1657 class_16572 = (class_1657)class_12972;
                if (class_16572 == ze.a.field_1724) {
                    return;
                }
                com.vengeance.vengeanceclient.utils.q.za.d(class_16572.method_5667());
                if (com.vengeance.vengeanceclient.utils.q.za.c(class_16572.method_5667())) {
                    ze.a.field_1724.method_7353((class_2561)class_2561.method_43470((String)("\u00a7a" + class_16572.method_5477().getString() + " added to friends")), false);
                } else {
                    ze.a.field_1724.method_7353((class_2561)class_2561.method_43470((String)("\u00a7c" + class_16572.method_5477().getString() + " removed from friends")), false);
                }
            }
        }
    }
}

