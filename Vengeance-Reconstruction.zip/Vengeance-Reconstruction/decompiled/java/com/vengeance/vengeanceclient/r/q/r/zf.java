/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_1935
 */
package com.vengeance.vengeanceclient.r.q.r;

import com.vengeance.vengeanceclient.mixin.MinecraftClientAccessor;
import com.vengeance.vengeanceclient.p.p.s.zd;
import com.vengeance.vengeanceclient.r.r.zc;
import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1935;

public final class zf
extends zb {
    private final zc b = new zc("Pearl Charge Key", 72, true);
    private final ze c = new ze("Wind Delay", 0.0, 2000.0, 200.0, 1.0);
    private final ze d = new ze("Switch Delay", 0.0, 500.0, 50.0, 10.0);
    private final com.vengeance.vengeanceclient.utils.s.zb e = new com.vengeance.vengeanceclient.utils.s.zb();
    private final com.vengeance.vengeanceclient.utils.s.zb f = new com.vengeance.vengeanceclient.utils.s.zb();
    private boolean g = false;
    private boolean h = false;
    private int i = -1;
    private boolean j = false;

    public zf() {
        super("Pearl Catch", "Throws pearl then windcharge", -1, za.e);
        this.a(this.b, this.c, this.d);
        this.f().removeIf(zg2 -> zg2 instanceof zc && !zg2.equals(this.b));
    }

    @EventHandler
    private void onTickEvent(zd zd2) {
        if (this.d() || zf.a.field_1755 != null) {
            return;
        }
        boolean bl = com.vengeance.vengeanceclient.utils.r.za.b(this.b.e());
        if (bl && !this.g) {
            this.n();
        }
        if (this.h && this.e.a(this.c.a())) {
            this.o();
            this.h = false;
        }
        if (this.j && this.f.a(this.d.a())) {
            zf.a.field_1724.method_31548().field_7545 = this.i;
            this.j = false;
            this.i = -1;
        }
        this.g = bl;
    }

    private void n() {
        int n = this.p();
        if (n == -1) {
            return;
        }
        if (zf.a.field_1724.method_7357().method_7904(new class_1799((class_1935)class_1802.field_8634))) {
            return;
        }
        this.i = zf.a.field_1724.method_31548().field_7545;
        zf.a.field_1724.method_31548().field_7545 = n;
        ((MinecraftClientAccessor)a).invokeDoItemUse();
        this.j = true;
        this.f.a();
        this.h = true;
        this.e.a();
    }

    private void o() {
        int n = this.q();
        if (n == -1) {
            return;
        }
        if (zf.a.field_1724.method_7357().method_7904(new class_1799((class_1935)class_1802.field_49098))) {
            return;
        }
        this.i = zf.a.field_1724.method_31548().field_7545;
        zf.a.field_1724.method_31548().field_7545 = n;
        ((MinecraftClientAccessor)a).invokeDoItemUse();
        this.j = true;
        this.f.a();
    }

    private int p() {
        for (int i = 0; i < 9; ++i) {
            if (zf.a.field_1724.method_31548().method_5438(i).method_7909() != class_1802.field_8634) continue;
            return i;
        }
        return -1;
    }

    private int q() {
        for (int i = 0; i < 9; ++i) {
            if (zf.a.field_1724.method_31548().method_5438(i).method_7909() != class_1802.field_49098) continue;
            return i;
        }
        return -1;
    }

    @Override
    public void b() {
        this.g = false;
        this.h = false;
        this.i = -1;
        this.j = false;
        this.e.a();
        this.f.a();
        super.b();
    }

    @Override
    public void c() {
        this.h = false;
        super.c();
    }

    @Override
    public int e() {
        return -1;
    }
}

