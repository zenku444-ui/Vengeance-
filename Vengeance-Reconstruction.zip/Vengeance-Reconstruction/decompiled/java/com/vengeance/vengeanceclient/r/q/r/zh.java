/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_310
 */
package com.vengeance.vengeanceclient.r.q.r;

import com.vengeance.vengeanceclient.VengeanceClient;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_310;

public class zh
extends zb {
    public zh() {
        super("Teams", "Stops you from targeting teammates", za.e);
    }

    public static boolean a(class_1297 class_12972) {
        zh zh2 = VengeanceClient.INSTANCE.getModuleManager().a(zh.class).get();
        if (!zh2.l()) {
            return false;
        }
        if (class_12972 == null || class_12972.method_5477() == null || !(class_12972 instanceof class_1309)) {
            return false;
        }
        try {
            class_310 class_3102 = class_310.method_1551();
            if (class_3102.field_1724 == null || class_3102.field_1724.method_5781() == null) {
                return false;
            }
            return class_3102.field_1724.method_5722(class_12972);
        }
        catch (IllegalStateException illegalStateException) {
            return false;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return false;
        }
    }
}

