/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2246
 *  net.minecraft.class_2338
 *  net.minecraft.class_2680
 */
package com.vengeance.vengeanceclient.r.q.s;

import com.vengeance.vengeanceclient.p.p.s.zd;
import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.za;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public final class zb
extends com.vengeance.vengeanceclient.r.zb {
    private final ze b = new ze("Jump Delay", 0.0, 500.0, 100.0, 10.0);
    private final com.vengeance.vengeanceclient.r.r.za c = new com.vengeance.vengeanceclient.r.r.za("Holding Space", false);
    private final com.vengeance.vengeanceclient.utils.s.zb d = new com.vengeance.vengeanceclient.utils.s.zb();

    public zb() {
        super("Auto Head Hitter", "Auto jumps when there's a solid block above to make u go fast", -1, za.c);
        this.a(this.b, this.c);
    }

    @EventHandler
    private void onTickEvent(zd zd2) {
        if (this.d()) {
            return;
        }
        if (this.c.b() && !zb.a.field_1690.field_1903.method_1434()) {
            return;
        }
        if (this.b.a() > 0 && !this.d.a(this.b.a())) {
            return;
        }
        if (!zb.a.field_1724.method_24828()) {
            return;
        }
        class_2338 class_23382 = zb.a.field_1724.method_24515();
        class_2338 class_23383 = class_23382.method_10086(2);
        class_2680 class_26802 = zb.a.field_1687.method_8320(class_23383);
        if (!class_26802.method_26215() && class_26802.method_26204() != class_2246.field_10382 && class_26802.method_26204() != class_2246.field_10164) {
            zb.a.field_1724.method_6043();
            this.d.a();
        }
    }
}

