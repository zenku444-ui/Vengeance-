/*
 * Decompiled with CFR 0.152.
 */
package com.vengeance.vengeanceclient.r.q.s;

import com.vengeance.vengeanceclient.p.p.s.zd;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import meteordevelopment.orbit.EventHandler;

public final class ze
extends zb {
    public ze() {
        super("Sprint", "Makes you automatically sprint", -1, za.c);
    }

    @EventHandler
    private void onTickEvent(zd zd2) {
        if (this.d()) {
            return;
        }
        if (((Boolean)ze.a.field_1690.method_42450().method_41753()).booleanValue()) {
            ze.a.field_1690.method_42450().method_41748((Object)false);
        }
        ze.a.field_1690.field_1867.method_23481(true);
    }
}

