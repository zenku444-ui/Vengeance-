/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1657
 *  net.minecraft.class_1713
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_479
 */
package com.vengeance.vengeanceclient.r.q.t;

import com.vengeance.vengeanceclient.p.p.s.zd;
import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.zb;
import java.lang.invoke.MethodHandle;
import java.lang.runtime.ObjectMethods;
import java.util.Arrays;
import java.util.List;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_479;

public final class za
extends zb {
    private static final List<za> b = Arrays.asList(new za(class_1802.field_8802, class_1802.field_8477, 2, class_1802.field_8600, 1, new int[]{-1, 1, -1, -1, 1, -1, -1, 2, -1}), new za(class_1802.field_8377, class_1802.field_8477, 3, class_1802.field_8600, 2, new int[]{1, 1, 1, -1, 2, -1, -1, 2, -1}), new za(class_1802.field_8556, class_1802.field_8477, 3, class_1802.field_8600, 2, new int[]{1, 1, -1, 1, 2, -1, -1, 2, -1}), new za(class_1802.field_8250, class_1802.field_8477, 1, class_1802.field_8600, 2, new int[]{-1, 1, -1, -1, 2, -1, -1, 2, -1}), new za(class_1802.field_8371, class_1802.field_8620, 2, class_1802.field_8600, 1, new int[]{-1, 1, -1, -1, 1, -1, -1, 2, -1}), new za(class_1802.field_8403, class_1802.field_8620, 3, class_1802.field_8600, 2, new int[]{1, 1, 1, -1, 2, -1, -1, 2, -1}), new za(class_1802.field_8475, class_1802.field_8620, 3, class_1802.field_8600, 2, new int[]{1, 1, -1, 1, 2, -1, -1, 2, -1}), new za(class_1802.field_8699, class_1802.field_8620, 1, class_1802.field_8600, 2, new int[]{-1, 1, -1, -1, 2, -1, -1, 2, -1}), new za(class_1802.field_8845, class_1802.field_8695, 2, class_1802.field_8600, 1, new int[]{-1, 1, -1, -1, 1, -1, -1, 2, -1}), new za(class_1802.field_8335, class_1802.field_8695, 3, class_1802.field_8600, 2, new int[]{1, 1, 1, -1, 2, -1, -1, 2, -1}), new za(class_1802.field_8825, class_1802.field_8695, 3, class_1802.field_8600, 2, new int[]{1, 1, -1, 1, 2, -1, -1, 2, -1}), new za(class_1802.field_8322, class_1802.field_8695, 1, class_1802.field_8600, 2, new int[]{-1, 1, -1, -1, 2, -1, -1, 2, -1}), new za(class_1802.field_8091, class_1802.field_8118, 2, class_1802.field_8600, 1, new int[]{-1, 1, -1, -1, 1, -1, -1, 2, -1}), new za(class_1802.field_8647, class_1802.field_8118, 3, class_1802.field_8600, 2, new int[]{1, 1, 1, -1, 2, -1, -1, 2, -1}), new za(class_1802.field_8406, class_1802.field_8118, 3, class_1802.field_8600, 2, new int[]{1, 1, -1, 1, 2, -1, -1, 2, -1}), new za(class_1802.field_8876, class_1802.field_8118, 1, class_1802.field_8600, 2, new int[]{-1, 1, -1, -1, 2, -1, -1, 2, -1}), new za(class_1802.field_8805, class_1802.field_8477, 5, new int[]{1, 1, 1, 1, -1, 1, -1, -1, -1}), new za(class_1802.field_8058, class_1802.field_8477, 8, new int[]{1, -1, 1, 1, 1, 1, 1, 1, 1}), new za(class_1802.field_8348, class_1802.field_8477, 7, new int[]{1, 1, 1, 1, -1, 1, 1, -1, 1}), new za(class_1802.field_8285, class_1802.field_8477, 4, new int[]{-1, -1, -1, 1, -1, 1, 1, -1, 1}), new za(class_1802.field_8743, class_1802.field_8620, 5, new int[]{1, 1, 1, 1, -1, 1, -1, -1, -1}), new za(class_1802.field_8523, class_1802.field_8620, 8, new int[]{1, -1, 1, 1, 1, 1, 1, 1, 1}), new za(class_1802.field_8396, class_1802.field_8620, 7, new int[]{1, 1, 1, 1, -1, 1, 1, -1, 1}), new za(class_1802.field_8660, class_1802.field_8620, 4, new int[]{-1, -1, -1, 1, -1, 1, 1, -1, 1}), new za(class_1802.field_8862, class_1802.field_8695, 5, new int[]{1, 1, 1, 1, -1, 1, -1, -1, -1}), new za(class_1802.field_8678, class_1802.field_8695, 8, new int[]{1, -1, 1, 1, 1, 1, 1, 1, 1}), new za(class_1802.field_8416, class_1802.field_8695, 7, new int[]{1, 1, 1, 1, -1, 1, 1, -1, 1}), new za(class_1802.field_8753, class_1802.field_8695, 4, new int[]{-1, -1, -1, 1, -1, 1, 1, -1, 1}), new za(class_1802.field_8267, class_1802.field_8745, 5, new int[]{1, 1, 1, 1, -1, 1, -1, -1, -1}), new za(class_1802.field_8577, class_1802.field_8745, 8, new int[]{1, -1, 1, 1, 1, 1, 1, 1, 1}), new za(class_1802.field_8570, class_1802.field_8745, 7, new int[]{1, 1, 1, 1, -1, 1, 1, -1, 1}), new za(class_1802.field_8370, class_1802.field_8745, 4, new int[]{-1, -1, -1, 1, -1, 1, 1, -1, 1}), new za(class_1802.field_8463, class_1802.field_8695, 8, class_1802.field_8279, 1, new int[]{1, 1, 1, 1, 2, 1, 1, 1, 1}));
    private final com.vengeance.vengeanceclient.r.r.za c = new com.vengeance.vengeanceclient.r.r.za("Swords", true);
    private final com.vengeance.vengeanceclient.r.r.za d = new com.vengeance.vengeanceclient.r.r.za("Pickaxes", true);
    private final com.vengeance.vengeanceclient.r.r.za e = new com.vengeance.vengeanceclient.r.r.za("Axes", true);
    private final com.vengeance.vengeanceclient.r.r.za f = new com.vengeance.vengeanceclient.r.r.za("Shovels", true);
    private final com.vengeance.vengeanceclient.r.r.za g = new com.vengeance.vengeanceclient.r.r.za("Helmets", true);
    private final com.vengeance.vengeanceclient.r.r.za h = new com.vengeance.vengeanceclient.r.r.za("Chestplates", true);
    private final com.vengeance.vengeanceclient.r.r.za i = new com.vengeance.vengeanceclient.r.r.za("Leggings", true);
    private final com.vengeance.vengeanceclient.r.r.za j = new com.vengeance.vengeanceclient.r.r.za("Boots", true);
    private final com.vengeance.vengeanceclient.r.r.za k = new com.vengeance.vengeanceclient.r.r.za("Golden Apples", true);
    private final ze l = new ze("Craft Delay", 0.0, 500.0, 100.0, 10.0);
    private final com.vengeance.vengeanceclient.utils.s.zb m = new com.vengeance.vengeanceclient.utils.s.zb();
    private boolean n = false;

    public za() {
        super("Auto Crafter", "Automatically crafts items when crafting table is open", -1, com.vengeance.vengeanceclient.r.za.b);
        this.a(this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j, this.k, this.l);
    }

    @EventHandler
    private void onTickEvent(zd zd2) {
        if (!this.n()) {
            return;
        }
        if (!this.m.a(this.l.a())) {
            return;
        }
        if (this.n) {
            this.s();
        } else if (this.o()) {
            this.p();
        }
    }

    private boolean n() {
        return za.a.field_1724 != null && za.a.field_1687 != null && za.a.field_1755 instanceof class_479;
    }

    private boolean o() {
        return this.c.b() || this.d.b() || this.e.b() || this.f.b() || this.g.b() || this.h.b() || this.i.b() || this.j.b() || this.k.b();
    }

    private void p() {
        za za2 = this.q();
        if (za2 != null) {
            this.c(za2);
        }
    }

    private za q() {
        Object object;
        if (this.k.b() && (object = this.t()) != null && this.b((za)object)) {
            return object;
        }
        for (za za2 : b) {
            if (za2.a == class_1802.field_8463 || !this.a(za2) || !this.b(za2) || !this.a(za2.a) || this.k.b() && this.e(za2)) continue;
            return za2;
        }
        return null;
    }

    private boolean a(za za2) {
        class_1792 class_17922 = za2.a;
        if (this.i(class_17922)) {
            return this.c.b();
        }
        if (this.j(class_17922)) {
            return this.d.b();
        }
        if (this.k(class_17922)) {
            return this.e.b();
        }
        if (this.l(class_17922)) {
            return this.f.b();
        }
        if (this.e(class_17922)) {
            return this.g.b();
        }
        if (this.f(class_17922)) {
            return this.h.b();
        }
        if (this.g(class_17922)) {
            return this.i.b();
        }
        if (this.h(class_17922)) {
            return this.j.b();
        }
        return false;
    }

    private boolean b(za za2) {
        if (this.c(za2.b) < za2.c) {
            return false;
        }
        return za2.d == null || this.c(za2.d) >= za2.e;
    }

    private boolean a(class_1792 class_17922) {
        if (class_17922 == class_1802.field_8463) {
            return true;
        }
        return !this.d(class_17922);
    }

    private void c(za za2) {
        this.r();
        this.d(za2);
        this.n = true;
        this.m.a();
    }

    private void d(za za2) {
        for (int i = 0; i < za2.f.length; ++i) {
            class_1792 class_17922;
            int n = za2.f[i];
            if (n == -1) continue;
            class_1792 class_17923 = class_17922 = n == 1 ? za2.b : za2.d;
            if (class_17922 == null) continue;
            this.a(class_17922, i + 1);
        }
    }

    private void a(class_1792 class_17922, int n) {
        int n2 = this.b(class_17922);
        if (n2 != -1) {
            za.a.field_1761.method_2906(za.a.field_1724.field_7512.field_7763, n2, 1, class_1713.field_7790, (class_1657)za.a.field_1724);
            za.a.field_1761.method_2906(za.a.field_1724.field_7512.field_7763, n, 1, class_1713.field_7790, (class_1657)za.a.field_1724);
        }
    }

    private void r() {
        for (int i = 1; i <= 9; ++i) {
            class_1799 class_17992 = za.a.field_1724.field_7512.method_7611(i).method_7677();
            if (class_17992.method_7960()) continue;
            za.a.field_1761.method_2906(za.a.field_1724.field_7512.field_7763, i, 0, class_1713.field_7794, (class_1657)za.a.field_1724);
        }
    }

    private void s() {
        class_1799 class_17992 = za.a.field_1724.field_7512.method_7611(0).method_7677();
        if (!class_17992.method_7960()) {
            za.a.field_1761.method_2906(za.a.field_1724.field_7512.field_7763, 0, 0, class_1713.field_7794, (class_1657)za.a.field_1724);
        }
        this.n = false;
        this.m.a();
    }

    private int b(class_1792 class_17922) {
        int n = -1;
        int n2 = 0;
        for (int i = 1; i < za.a.field_1724.field_7512.field_7761.size(); ++i) {
            class_1799 class_17992 = za.a.field_1724.field_7512.method_7611(i).method_7677();
            if (class_17992.method_7960() || class_17992.method_7909() != class_17922 || class_17992.method_7947() <= n2) continue;
            n2 = class_17992.method_7947();
            n = i;
        }
        return n;
    }

    private int c(class_1792 class_17922) {
        int n = 0;
        for (int i = 0; i < za.a.field_1724.method_31548().method_5439(); ++i) {
            class_1799 class_17992 = za.a.field_1724.method_31548().method_5438(i);
            if (class_17992.method_7960() || class_17992.method_7909() != class_17922) continue;
            n += class_17992.method_7947();
        }
        return n;
    }

    private boolean d(class_1792 class_17922) {
        return this.c(class_17922) > 0;
    }

    private za t() {
        return b.stream().filter(za2 -> za2.a == class_1802.field_8463).findFirst().orElse(null);
    }

    private boolean e(za za2) {
        return za2.b == class_1802.field_8695 || za2.d == class_1802.field_8695;
    }

    private boolean e(class_1792 class_17922) {
        return class_17922 == class_1802.field_8805 || class_17922 == class_1802.field_8743 || class_17922 == class_1802.field_8862 || class_17922 == class_1802.field_8267;
    }

    private boolean f(class_1792 class_17922) {
        return class_17922 == class_1802.field_8058 || class_17922 == class_1802.field_8523 || class_17922 == class_1802.field_8678 || class_17922 == class_1802.field_8577;
    }

    private boolean g(class_1792 class_17922) {
        return class_17922 == class_1802.field_8348 || class_17922 == class_1802.field_8396 || class_17922 == class_1802.field_8416 || class_17922 == class_1802.field_8570;
    }

    private boolean h(class_1792 class_17922) {
        return class_17922 == class_1802.field_8285 || class_17922 == class_1802.field_8660 || class_17922 == class_1802.field_8753 || class_17922 == class_1802.field_8370;
    }

    private boolean i(class_1792 class_17922) {
        return class_17922 == class_1802.field_8802 || class_17922 == class_1802.field_8371 || class_17922 == class_1802.field_8845 || class_17922 == class_1802.field_8091;
    }

    private boolean j(class_1792 class_17922) {
        return class_17922 == class_1802.field_8377 || class_17922 == class_1802.field_8403 || class_17922 == class_1802.field_8335 || class_17922 == class_1802.field_8647;
    }

    private boolean k(class_1792 class_17922) {
        return class_17922 == class_1802.field_8556 || class_17922 == class_1802.field_8475 || class_17922 == class_1802.field_8825 || class_17922 == class_1802.field_8406;
    }

    private boolean l(class_1792 class_17922) {
        return class_17922 == class_1802.field_8250 || class_17922 == class_1802.field_8699 || class_17922 == class_1802.field_8322 || class_17922 == class_1802.field_8876;
    }

    @Override
    public void b() {
        this.u();
        super.b();
    }

    @Override
    public void c() {
        this.u();
        super.c();
    }

    private void u() {
        this.n = false;
        this.m.a();
    }

    private record za(class_1792 a, class_1792 b, int c, class_1792 d, int e, int[] f) {
        za(class_1792 class_17922, class_1792 class_17923, int n, int[] nArray) {
            this(class_17922, class_17923, n, null, 0, nArray);
        }

        @Override
        public final String toString() {
            return ObjectMethods.bootstrap("toString", new MethodHandle[]{za.class, "result;material1;count1;material2;count2;pattern", "a", "b", "c", "d", "e", "f"}, this);
        }

        @Override
        public final int hashCode() {
            return (int)ObjectMethods.bootstrap("hashCode", new MethodHandle[]{za.class, "result;material1;count1;material2;count2;pattern", "a", "b", "c", "d", "e", "f"}, this);
        }

        @Override
        public final boolean equals(Object object) {
            return (boolean)ObjectMethods.bootstrap("equals", new MethodHandle[]{za.class, "result;material1;count1;material2;count2;pattern", "a", "b", "c", "d", "e", "f"}, this, object);
        }
    }
}

