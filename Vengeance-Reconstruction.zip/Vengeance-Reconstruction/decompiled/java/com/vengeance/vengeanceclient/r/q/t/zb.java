/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1802
 *  net.minecraft.class_490
 */
package com.vengeance.vengeanceclient.r.q.t;

import com.vengeance.vengeanceclient.p.p.s.zd;
import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.utils.zc;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1802;
import net.minecraft.class_490;

public final class zb
extends com.vengeance.vengeanceclient.r.zb {
    private static final com.vengeance.vengeanceclient.r.r.za b = new com.vengeance.vengeanceclient.r.r.za("Inventory Switch", true);
    private static final ze c = new ze("Totem Slot", 1.0, 9.0, 9.0, 1.0);
    private static final com.vengeance.vengeanceclient.r.r.za d = new com.vengeance.vengeanceclient.r.r.za("Health Switch", false);
    private static final ze e = new ze("Health Threshold", 1.0, 20.0, 15.0, 0.5);
    private int f = -1;

    public zb() {
        super("Auto Double Hand", "Automatically switches to totem based on conditions", -1, za.b);
        this.a(b, c, d, e);
    }

    @EventHandler
    private void onTick(zd zd2) {
        if (this.d()) {
            return;
        }
        boolean bl = this.n();
        boolean bl2 = this.p();
        if (bl && !bl2) {
            this.q();
        } else if (!bl && bl2 && this.f != -1) {
            this.r();
        }
    }

    private boolean n() {
        if (this.d()) {
            return false;
        }
        if (b.b() && zb.a.field_1755 instanceof class_490) {
            return true;
        }
        return d.b() && this.o();
    }

    private boolean o() {
        if ((double)zb.a.field_1724.method_6032() > e.f()) {
            return false;
        }
        if (zb.a.field_1724.method_6115()) {
            return false;
        }
        return !zc.a(zb.a.field_1724.method_6047());
    }

    private boolean p() {
        if (this.d()) {
            return false;
        }
        int n = zb.a.field_1724.method_31548().field_7545;
        if (this.f != -1 && n == c.a() - 1) {
            return true;
        }
        return zb.a.field_1724.method_31548().method_5438(n).method_7909() == class_1802.field_8288;
    }

    private void q() {
        if (this.d()) {
            return;
        }
        int n = this.s();
        if (n == -1 && b.b() && zb.a.field_1755 instanceof class_490) {
            n = c.a() - 1;
        }
        if (n != -1) {
            this.f = zb.a.field_1724.method_31548().field_7545;
            zb.a.field_1724.method_31548().field_7545 = n;
        }
    }

    private void r() {
        if (this.d()) {
            return;
        }
        zb.a.field_1724.method_31548().field_7545 = this.f;
        this.f = -1;
    }

    private int s() {
        if (this.d()) {
            return -1;
        }
        for (int i = 0; i < 9; ++i) {
            if (zb.a.field_1724.method_31548().method_5438(i).method_7909() != class_1802.field_8288) continue;
            return i;
        }
        return -1;
    }

    @Override
    public void c() {
        if (!this.d() && this.f != -1) {
            zb.a.field_1724.method_31548().field_7545 = this.f;
            this.f = -1;
        }
        super.c();
    }
}

