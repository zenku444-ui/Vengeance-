/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_2246
 *  net.minecraft.class_2338
 *  net.minecraft.class_238
 *  net.minecraft.class_239
 *  net.minecraft.class_2680
 *  net.minecraft.class_3610
 *  net.minecraft.class_3612
 *  net.minecraft.class_3965
 */
package com.vengeance.vengeanceclient.r.q.t;

import com.vengeance.vengeanceclient.mixin.MinecraftClientAccessor;
import com.vengeance.vengeanceclient.p.p.s.zd;
import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3965;

public final class zc
extends zb {
    private static final ze b = new ze("Cooldown MS", 50.0, 2000.0, 250.0, 1.0);
    private static final ze c = new ze("SwitchBack MS", 0.0, 500.0, 75.0, 1.0);
    private final com.vengeance.vengeanceclient.utils.s.zb d = new com.vengeance.vengeanceclient.utils.s.zb();
    private final com.vengeance.vengeanceclient.utils.s.zb e = new com.vengeance.vengeanceclient.utils.s.zb();
    private int f = -1;
    private boolean g = false;

    public zc() {
        super("Auto Drain", "Swap to empty bucket and pick up water when aiming at a source", -1, za.b);
        this.a(b, c);
    }

    @EventHandler
    private void onTickEvent(zd zd2) {
        if (this.d() || zc.a.field_1755 != null || zc.a.field_1687 == null) {
            return;
        }
        if (this.g) {
            if (c.a() <= 0 || this.e.a(c.a())) {
                if (this.f != -1) {
                    zc.a.field_1724.method_31548().field_7545 = this.f;
                }
                this.f = -1;
                this.g = false;
            }
            return;
        }
        if (!this.d.a(b.a())) {
            return;
        }
        class_239 class_2392 = zc.a.field_1765;
        if (!(class_2392 instanceof class_3965)) {
            return;
        }
        class_3965 class_39652 = (class_3965)class_2392;
        class_2392 = this.a(class_39652);
        if (class_2392 == null) {
            return;
        }
        if (this.o()) {
            return;
        }
        int n = this.n();
        if (n == -1) {
            return;
        }
        this.f = zc.a.field_1724.method_31548().field_7545;
        zc.a.field_1724.method_31548().field_7545 = n;
        ((MinecraftClientAccessor)a).invokeDoItemUse();
        this.g = true;
        this.e.a();
        this.d.a();
    }

    private boolean a(class_3610 class_36102) {
        return class_36102 != null && class_36102.method_15772() == class_3612.field_15910 && class_36102.method_15771();
    }

    private int n() {
        for (int i = 0; i < 9; ++i) {
            class_1799 class_17992 = zc.a.field_1724.method_31548().method_5438(i);
            if (class_17992.method_7960() || class_17992.method_7909() != class_1802.field_8550) continue;
            return i;
        }
        return -1;
    }

    private boolean o() {
        class_238 class_2383 = zc.a.field_1724.method_5829();
        int n = (int)Math.floor(class_2383.field_1323);
        int n2 = (int)Math.floor(class_2383.field_1322);
        int n3 = (int)Math.floor(class_2383.field_1321);
        int n4 = (int)Math.floor(class_2383.field_1320);
        int n5 = (int)Math.floor(class_2383.field_1325);
        int n6 = (int)Math.floor(class_2383.field_1324);
        for (int i = n; i <= n4; ++i) {
            for (int j = n2; j <= n5; ++j) {
                for (int k = n3; k <= n6; ++k) {
                    if (!zc.a.field_1687.method_8320(new class_2338(i, j, k)).method_27852(class_2246.field_10343)) continue;
                    return true;
                }
            }
        }
        return false;
    }

    private class_2338 a(class_3965 class_39652) {
        class_2338 class_23382 = class_39652.method_17777();
        class_2680 class_26802 = zc.a.field_1687.method_8320(class_23382);
        if (class_26802.method_26204() == class_2246.field_10382 && this.a(zc.a.field_1687.method_8316(class_23382))) {
            return class_23382;
        }
        class_2338 class_23383 = class_23382.method_10093(class_39652.method_17780());
        class_2680 class_26803 = zc.a.field_1687.method_8320(class_23383);
        if (class_26803.method_26204() == class_2246.field_10382 && this.a(zc.a.field_1687.method_8316(class_23383))) {
            return class_23383;
        }
        return null;
    }

    @Override
    public void c() {
        super.c();
        if (this.g && this.f != -1 && zc.a.field_1724 != null) {
            zc.a.field_1724.method_31548().field_7545 = this.f;
        }
        this.f = -1;
        this.g = false;
    }
}

