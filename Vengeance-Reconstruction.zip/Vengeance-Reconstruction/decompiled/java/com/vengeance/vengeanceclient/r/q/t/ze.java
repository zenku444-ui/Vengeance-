/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1802
 *  net.minecraft.class_2338
 */
package com.vengeance.vengeanceclient.r.q.t;

import com.vengeance.vengeanceclient.mixin.MinecraftClientAccessor;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import com.vengeance.vengeanceclient.utils.t.zd;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1802;
import net.minecraft.class_2338;

public final class ze
extends zb {
    private final com.vengeance.vengeanceclient.r.r.ze b = new com.vengeance.vengeanceclient.r.r.ze("Fall Distance", 3.0, 40.0, 8.0, 1.0);
    private final com.vengeance.vengeanceclient.r.r.za c = new com.vengeance.vengeanceclient.r.r.za("Pick Up", true);
    private int d;
    private int e;
    private int f = -1;
    private float g;
    private boolean h;

    public ze() {
        super("Auto MLG", "Places water before landing", -1, za.b);
        this.a(this.b, this.c);
    }

    @EventHandler
    private void onTick(com.vengeance.vengeanceclient.p.p.s.zd zd2) {
        if (this.d()) {
            return;
        }
        if (this.d == 0) {
            this.n();
        } else if (this.d == 1) {
            this.o();
        } else if (this.d == 2) {
            this.p();
        } else if (this.d == 3) {
            this.q();
        }
    }

    private void n() {
        if (ze.a.field_1724.method_24828()) {
            return;
        }
        if (ze.a.field_1724.method_5799()) {
            return;
        }
        if (ze.a.field_1724.field_6017 < this.b.f()) {
            return;
        }
        if (!zd.b(class_1802.field_8705)) {
            return;
        }
        this.f = ze.a.field_1724.method_31548().field_7545;
        this.g = ze.a.field_1724.method_36455();
        zd.a(class_1802.field_8705);
        this.d = 1;
        this.e = 0;
        this.h = false;
    }

    private void o() {
        if (!this.h) {
            ze.a.field_1724.method_36457(89.5f);
            this.h = true;
            return;
        }
        if (ze.a.field_1724.method_24828()) {
            this.d = 3;
            return;
        }
        int n = this.r();
        ++this.e;
        if (n > 2) {
            return;
        }
        if (this.e % 2 != 0) {
            return;
        }
        zd.a(class_1802.field_8705);
        ((MinecraftClientAccessor)a).invokeDoItemUse();
        this.d = this.c.b() ? 2 : 3;
        this.e = 0;
    }

    private void p() {
        ++this.e;
        if (!ze.a.field_1724.method_24828() && !ze.a.field_1724.method_5799()) {
            return;
        }
        if (this.e < 3) {
            return;
        }
        zd.a(class_1802.field_8550);
        ((MinecraftClientAccessor)a).invokeDoItemUse();
        this.d = 3;
    }

    private void q() {
        if (this.f >= 0) {
            ze.a.field_1724.method_31548().field_7545 = this.f;
        }
        if (this.h) {
            ze.a.field_1724.method_36457(this.g);
        }
        this.d = 0;
        this.e = 0;
        this.f = -1;
        this.h = false;
    }

    @Override
    public void c() {
        this.q();
        super.c();
    }

    private int r() {
        if (this.d()) {
            return 6;
        }
        class_2338 class_23382 = ze.a.field_1724.method_24515();
        for (int i = 1; i <= 6; ++i) {
            class_2338 class_23383 = class_23382.method_10087(i);
            if (ze.a.field_1687.method_8320(class_23383).method_26215()) continue;
            return i;
        }
        return 7;
    }
}

