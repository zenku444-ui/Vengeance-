/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1294
 *  net.minecraft.class_1657
 *  net.minecraft.class_1713
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_1842
 *  net.minecraft.class_1844
 *  net.minecraft.class_437
 *  net.minecraft.class_490
 *  net.minecraft.class_6880
 *  net.minecraft.class_9334
 */
package com.vengeance.vengeanceclient.r.q.t;

import com.vengeance.vengeanceclient.mixin.HandledScreenAccessor;
import com.vengeance.vengeanceclient.p.p.s.zd;
import com.vengeance.vengeanceclient.r.r.zc;
import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import java.util.ArrayList;
import java.util.Random;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1294;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1842;
import net.minecraft.class_1844;
import net.minecraft.class_437;
import net.minecraft.class_490;
import net.minecraft.class_6880;
import net.minecraft.class_9334;

public final class zf
extends zb {
    private static final ze c = new ze("Delay", 10.0, 200.0, 50.0, 10.0);
    private static final ze d = new ze("Hover Delay", 10.0, 100.0, 25.0, 5.0);
    private static final ze e = new ze("Min Stack", 1.0, 64.0, 16.0, 1.0);
    private static final com.vengeance.vengeanceclient.r.r.za f = new com.vengeance.vengeanceclient.r.r.za("Hover Mode", false);
    private static final com.vengeance.vengeanceclient.r.r.za g = new com.vengeance.vengeanceclient.r.r.za("Health", true);
    private static final com.vengeance.vengeanceclient.r.r.za h = new com.vengeance.vengeanceclient.r.r.za("Regen", true);
    private static final com.vengeance.vengeanceclient.r.r.za i = new com.vengeance.vengeanceclient.r.r.za("Strength", false);
    private static final com.vengeance.vengeanceclient.r.r.za j = new com.vengeance.vengeanceclient.r.r.za("Speed", false);
    private static final com.vengeance.vengeanceclient.r.r.za k = new com.vengeance.vengeanceclient.r.r.za("TNT Carts", false);
    private static final com.vengeance.vengeanceclient.r.r.za l = new com.vengeance.vengeanceclient.r.r.za("Random Pick", true);
    private final zc m = new zc("Key", 82, false);
    private final com.vengeance.vengeanceclient.utils.s.zb n = new com.vengeance.vengeanceclient.utils.s.zb();
    private final Random o = new Random();
    private boolean p = false;
    private boolean q = false;
    private boolean r = false;

    public zf() {
        super("Auto Refill", "Refills hotbar with potions and TNT carts", -1, za.b);
        this.a(this.m, c, d, e, f, g, h, i, j, k, l);
    }

    @EventHandler
    private void onTickEvent(zd zd2) {
        if (this.d()) {
            return;
        }
        if (f.b()) {
            this.n();
            return;
        }
        if (zf.a.field_1755 != null && !(zf.a.field_1755 instanceof class_490)) {
            return;
        }
        boolean bl = com.vengeance.vengeanceclient.utils.r.za.b(this.m.e());
        if (bl && !this.p) {
            this.o();
        }
        this.p = bl;
        if (!this.r) {
            return;
        }
        if (this.n.a(c.a())) {
            this.p();
        }
    }

    private void n() {
        class_437 class_4372 = zf.a.field_1755;
        if (!(class_4372 instanceof class_490)) {
            return;
        }
        class_490 class_4902 = (class_490)class_4372;
        try {
            class_4372 = ((HandledScreenAccessor)class_4902).getFocusedSlot();
            if (class_4372 == null || class_4372.method_34266() < 9 || !this.a(class_4372.method_7677()) || !this.r()) {
                return;
            }
            if (this.n.a(d.a() + this.o.nextInt(10))) {
                this.b(class_4372.method_34266());
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private void o() {
        if (!this.t()) {
            return;
        }
        this.q = zf.a.field_1755 instanceof class_490;
        if (!this.q) {
            assert (zf.a.field_1724 != null);
            a.method_1507((class_437)new class_490((class_1657)zf.a.field_1724));
        }
        this.r = true;
        this.n.a();
    }

    private void p() {
        if (!(zf.a.field_1755 instanceof class_490) || !this.r()) {
            this.q();
            return;
        }
        int n = this.s();
        if (n == -1) {
            this.q();
            return;
        }
        this.b(n);
    }

    private void q() {
        if (!this.q) {
            a.method_1507(null);
        }
        this.r = false;
    }

    private boolean r() {
        for (int i = 0; i < 9; ++i) {
            class_1799 class_17992 = zf.a.field_1724.method_31548().method_5438(i);
            if (!class_17992.method_7960() && (!this.a(class_17992) || class_17992.method_7947() >= e.a())) continue;
            return true;
        }
        return false;
    }

    private int s() {
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        for (int i = 9; i < 36; ++i) {
            if (!this.a(zf.a.field_1724.method_31548().method_5438(i))) continue;
            arrayList.add(i);
        }
        return arrayList.isEmpty() ? -1 : (Integer)arrayList.get(this.o.nextInt(arrayList.size()));
    }

    private boolean t() {
        return this.s() != -1;
    }

    private boolean a(class_1799 class_17992) {
        if (class_17992.method_7960()) {
            return false;
        }
        if (k.b() && class_17992.method_7909() == class_1802.field_8069) {
            return true;
        }
        if (!this.a(class_17992.method_7909())) {
            return false;
        }
        class_1844 class_18442 = (class_1844)class_17992.method_58694(class_9334.field_49651);
        if (class_18442 == null || class_18442.comp_2378().isEmpty()) {
            return false;
        }
        return ((class_1842)((class_6880)class_18442.comp_2378().get()).comp_349()).method_8049().stream().anyMatch(class_12932 -> g.b() && class_12932.method_5579().equals((Object)class_1294.field_5915) || h.b() && class_12932.method_5579().equals((Object)class_1294.field_5924) || i.b() && class_12932.method_5579().equals((Object)class_1294.field_5910) || j.b() && class_12932.method_5579().equals((Object)class_1294.field_5904));
    }

    private boolean a(class_1792 class_17922) {
        return class_17922 == class_1802.field_8574 || class_17922 == class_1802.field_8436 || class_17922 == class_1802.field_8150;
    }

    private void b(int n) {
        zf.a.field_1761.method_2906(zf.a.field_1724.field_7512.field_7763, n, 0, class_1713.field_7794, (class_1657)zf.a.field_1724);
        this.n.a();
    }

    @Override
    public void b() {
        this.n.a();
        this.p = com.vengeance.vengeanceclient.utils.r.za.b(this.m.e());
        this.r = false;
        super.b();
    }

    @Override
    public void c() {
        if (zf.a.field_1755 instanceof class_490 && !this.q) {
            a.method_1507(null);
        }
        this.r = false;
        super.c();
    }
}

