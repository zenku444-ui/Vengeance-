/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1799
 *  net.minecraft.class_1922
 *  net.minecraft.class_239
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_2680
 *  net.minecraft.class_3965
 */
package com.vengeance.vengeanceclient.r.q.t;

import com.vengeance.vengeanceclient.p.p.s.zd;
import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_3965;

public final class zg
extends zb {
    private static final ze b = new ze("Delay", 0.0, 100.0, 5.0, 1.0);
    private static final com.vengeance.vengeanceclient.r.r.za c = new com.vengeance.vengeanceclient.r.r.za("Return To Previous", true);
    private static final com.vengeance.vengeanceclient.r.r.za d = new com.vengeance.vengeanceclient.r.r.za("Only When Sneaking", false);
    private static final com.vengeance.vengeanceclient.r.r.za e = new com.vengeance.vengeanceclient.r.r.za("Prevent Low Durability", true);
    private static final ze f = new ze("Durability Threshold", 1.0, 100.0, 10.0, 1.0);
    private final com.vengeance.vengeanceclient.utils.s.zb g = new com.vengeance.vengeanceclient.utils.s.zb();
    private int h = -1;

    public zg() {
        super("Auto Tool", "Automatically switches to the best tool", -1, za.b);
        this.a(b, c, d, e, f);
    }

    @EventHandler
    private void onTickEvent(zd zd2) {
        if (this.d()) {
            return;
        }
        if (d.b() && !zg.a.field_1724.method_5715()) {
            return;
        }
        if (!zg.a.field_1690.field_1886.method_1434()) {
            if (c.b() && this.h != -1) {
                zg.a.field_1724.method_31548().field_7545 = this.h;
                this.h = -1;
            }
            return;
        }
        class_239 class_2392 = zg.a.field_1765;
        if (class_2392 == null) {
            return;
        }
        if (class_2392.method_17783() == class_239.class_240.field_1332) {
            this.a((class_3965)class_2392);
        }
    }

    private void a(class_3965 class_39652) {
        class_2680 class_26802 = zg.a.field_1687.method_8320(class_39652.method_17777());
        if (class_26802.method_26214((class_1922)zg.a.field_1687, class_39652.method_17777()) < 0.0f) {
            return;
        }
        int n = this.a(class_26802);
        if (n != -1 && n != zg.a.field_1724.method_31548().field_7545) {
            this.b(n);
        }
    }

    private void b(int n) {
        if (!this.g.a(b.a())) {
            return;
        }
        if (this.h == -1) {
            this.h = zg.a.field_1724.method_31548().field_7545;
        }
        zg.a.field_1724.method_31548().field_7545 = n;
        this.g.a();
    }

    private int a(class_2680 class_26802) {
        int n = -1;
        float f = 0.0f;
        for (int i = 0; i < 9; ++i) {
            float f2;
            class_1799 class_17992 = zg.a.field_1724.method_31548().method_5438(i);
            if (class_17992.method_7960() || !this.a(class_17992, class_26802) || e.b() && this.b(class_17992) || !((f2 = this.b(class_17992, class_26802)) > f)) continue;
            f = f2;
            n = i;
        }
        return n;
    }

    private boolean a(class_1799 class_17992, class_2680 class_26802) {
        return class_17992.method_7951(class_26802) || class_17992.method_7924(class_26802) > 1.0f;
    }

    private float b(class_1799 class_17992, class_2680 class_26802) {
        float f = class_17992.method_7924(class_26802);
        float f2 = this.a(class_17992);
        return f * f2;
    }

    private float a(class_1799 class_17992) {
        String string = class_17992.method_7909().toString().toLowerCase();
        if (string.contains("netherite")) {
            return 6.0f;
        }
        if (string.contains("diamond")) {
            return 5.0f;
        }
        if (string.contains("iron")) {
            return 4.0f;
        }
        if (string.contains("golden")) {
            return 3.5f;
        }
        if (string.contains("stone")) {
            return 2.0f;
        }
        if (string.contains("wooden")) {
            return 1.5f;
        }
        return 1.0f;
    }

    private boolean b(class_1799 class_17992) {
        if (class_17992.method_7936() <= 0) {
            return false;
        }
        int n = class_17992.method_7936() - class_17992.method_7919();
        return n <= f.a();
    }

    @Override
    public void b() {
        this.g.a();
        this.h = -1;
        super.b();
    }

    @Override
    public void c() {
        if (c.b() && this.h != -1) {
            zg.a.field_1724.method_31548().field_7545 = this.h;
        }
        this.h = -1;
        super.c();
    }
}

