/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1747
 *  net.minecraft.class_1799
 */
package com.vengeance.vengeanceclient.r.q.t;

import com.vengeance.vengeanceclient.mixin.MinecraftClientAccessor;
import com.vengeance.vengeanceclient.p.p.s.zd;
import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1747;
import net.minecraft.class_1799;

public final class zl
extends zb {
    private static final com.vengeance.vengeanceclient.r.r.za b = new com.vengeance.vengeanceclient.r.r.za("Blocks Only", true);
    private static final ze c = new ze("Delay", 0.0, 4.0, 0.0, 1.0);
    private final com.vengeance.vengeanceclient.utils.s.zb d = new com.vengeance.vengeanceclient.utils.s.zb();

    public zl() {
        super("Fast Place", "Bypasses item use cooldown for faster block placement", -1, za.b);
        this.a(b, c);
    }

    @EventHandler
    private void onTickEvent(zd zd2) {
        class_1799 class_17992;
        if (this.d()) {
            return;
        }
        if (b.b() && ((class_17992 = zl.a.field_1724.method_6047()).method_7960() || !(class_17992.method_7909() instanceof class_1747))) {
            return;
        }
        long l = (long)c.a() * 50L;
        if (this.d.a(l, true)) {
            ((MinecraftClientAccessor)a).setItemUseCooldown(0);
        }
    }

    @Override
    public void b() {
        this.d.a();
        super.b();
    }

    @Override
    public void c() {
        this.d.a();
        if (zl.a.field_1724 != null) {
            ((MinecraftClientAccessor)a).setItemUseCooldown(4);
        }
        super.c();
    }
}

