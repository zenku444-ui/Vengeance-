/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2596
 *  net.minecraft.class_2670
 *  net.minecraft.class_2827
 */
package com.vengeance.vengeanceclient.r.q.t;

import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.r.zg;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2596;
import net.minecraft.class_2670;
import net.minecraft.class_2827;

public final class zm
extends zb {
    private final ze b = new ze("Ms", 1.0, 500.0, 60.0, 1.0);

    public zm() {
        super("Ping Spoof", "Increases your ping", -1, za.b);
        this.a((zg)this.b);
    }

    @EventHandler
    private void onEventPacket(com.vengeance.vengeanceclient.p.p.r.zb zb2) {
        Object object = zb2.b();
        if (object instanceof class_2670) {
            class_2670 class_26702 = (class_2670)object;
            if (this.d()) {
                return;
            }
            object = CompletableFuture.runAsync(() -> {
                try {
                    Thread.sleep(this.b.a());
                    Objects.requireNonNull(a.method_1562()).method_48296().method_10743((class_2596)new class_2827(class_26702.method_11517()));
                }
                catch (InterruptedException interruptedException) {
                    throw new RuntimeException(interruptedException);
                }
            });
            ((CompletableFuture)object).join();
        }
    }
}

