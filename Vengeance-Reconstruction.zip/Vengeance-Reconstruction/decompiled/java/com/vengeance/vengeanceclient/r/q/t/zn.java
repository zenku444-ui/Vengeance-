/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1109
 *  net.minecraft.class_1113
 *  net.minecraft.class_1294
 *  net.minecraft.class_3414
 *  net.minecraft.class_3417
 */
package com.vengeance.vengeanceclient.r.q.t;

import com.vengeance.vengeanceclient.p.p.s.zd;
import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1109;
import net.minecraft.class_1113;
import net.minecraft.class_1294;
import net.minecraft.class_3414;
import net.minecraft.class_3417;

public final class zn
extends zb {
    private final com.vengeance.vengeanceclient.r.r.za b = new com.vengeance.vengeanceclient.r.r.za("Sound Alert", true);
    private final com.vengeance.vengeanceclient.r.r.za c = new com.vengeance.vengeanceclient.r.r.za("Show Notification", true);
    private final ze d = new ze("Volume", 0.1f, 2.0, 1.0, 0.1f);
    private final com.vengeance.vengeanceclient.utils.s.zb e = new com.vengeance.vengeanceclient.utils.s.zb();
    private boolean f = false;
    private boolean g = false;
    private boolean h = false;

    public zn() {
        super("ReBuff Notifier", "Plays a sound when speed or strength effects expire", -1, za.b);
        this.a(this.b, this.c, this.d);
    }

    @EventHandler
    private void onTickEvent(zd zd2) {
        if (zn.a.field_1724 == null || !this.l()) {
            return;
        }
        boolean bl = zn.a.field_1724.method_6059(class_1294.field_5904);
        boolean bl2 = zn.a.field_1724.method_6059(class_1294.field_5910);
        if (!bl && this.g) {
            this.b("Speed");
        }
        if (!bl2 && this.h) {
            this.b("Strength");
        }
        if (this.f && this.e.a(3000L)) {
            this.o();
        }
        this.g = bl;
        this.h = bl2;
    }

    private void b(String string) {
        if (this.b.b() && !this.f) {
            this.n();
        }
        if (this.c.b()) {
            com.vengeance.vengeanceclient.utils.u.zb.a().a(string);
        }
    }

    private void n() {
        if (this.f) {
            return;
        }
        this.f = true;
        this.e.a();
        a.method_1483().method_4873((class_1113)class_1109.method_4758((class_3414)((class_3414)class_3417.field_14622.comp_349()), (float)this.d.b()));
    }

    private void o() {
        this.f = false;
    }

    @Override
    public void b() {
        super.b();
        this.f = false;
        this.g = false;
        this.h = false;
        this.e.a();
    }

    @Override
    public void c() {
        this.o();
        super.c();
    }
}

