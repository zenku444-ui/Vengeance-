/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.opengl.GlStateManager
 *  net.minecraft.class_1297
 *  net.minecraft.class_1657
 *  net.minecraft.class_243
 *  net.minecraft.class_2960
 *  net.minecraft.class_332
 *  net.minecraft.class_3532
 */
package com.vengeance.vengeanceclient.r.q.u;

import com.mojang.blaze3d.opengl.GlStateManager;
import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.utils.w.zq;
import java.awt.Color;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3532;

public final class zb
extends com.vengeance.vengeanceclient.r.zb {
    private static final class_2960 b = class_2960.method_60655((String)"vengeance-client", (String)"textures/visuals/triangle.png");
    private final com.vengeance.vengeanceclient.r.r.za c = new com.vengeance.vengeanceclient.r.r.za("Show Self", false);
    private final ze d = new ze("Range", 10.0, 200.0, 120.0, 5.0);
    private final ze e = new ze("Size", 8.0, 64.0, 24.0, 1.0);
    private final ze f = new ze("Offset", 0.0, 64.0, 28.0, 1.0);
    private final com.vengeance.vengeanceclient.r.r.zb g = new com.vengeance.vengeanceclient.r.r.zb("Color", new Color(255, 255, 255, 200), true);

    public zb() {
        super("Arrow ESP", "Displays arrows pointing to players", -1, za.d);
        this.a(this.c, this.d, this.e, this.f, this.g);
    }

    @EventHandler
    private void onRender2D(com.vengeance.vengeanceclient.p.p.t.za za2) {
        if (this.d()) {
            return;
        }
        class_332 class_3322 = za2.a();
        int n = za2.b();
        int n2 = za2.c();
        float f = (float)n * 0.5f;
        float f2 = (float)n2 * 0.5f;
        float f3 = a.method_61966().method_60637(true);
        class_243 class_2432 = zb.a.field_1773.method_19418().method_71156();
        float f4 = zb.a.field_1773.method_19418().method_19330();
        GlStateManager._disableDepthTest();
        GlStateManager._depthMask((boolean)false);
        GlStateManager._enableBlend();
        GlStateManager._blendFuncSeparate((int)770, (int)771, (int)1, (int)771);
        Color color = this.g.h();
        int n3 = color.getAlpha();
        float f5 = this.e.b();
        float f6 = this.f.b();
        double d = this.d.f();
        for (class_1657 class_16572 : zb.a.field_1687.method_18456()) {
            double d2;
            if (!this.a(class_16572) || (d2 = zb.a.field_1724.method_5858((class_1297)class_16572)) > d * d) continue;
            class_243 class_2433 = class_16572.method_30950(f3);
            double d3 = class_2433.field_1352 - class_2432.field_1352;
            double d4 = class_2433.field_1350 - class_2432.field_1350;
            double d5 = Math.sqrt(d3 * d3 + d4 * d4);
            if (d5 < 1.0E-6) continue;
            float f7 = (float)class_3532.method_15338((double)(Math.toDegrees(Math.atan2(d4, d3)) - 90.0 - (double)f4));
            double d6 = Math.sqrt(d2);
            float f8 = (float)Math.min(d6 / d, 1.0);
            float f9 = 1.0f - f8 * 0.6f;
            int n4 = Math.max(24, Math.min(255, (int)((float)n3 * f9)));
            int n5 = n4 << 24 | color.getRed() << 16 | color.getGreen() << 8 | color.getBlue();
            float f10 = f;
            float f11 = f2 - (f6 + f8 * f6);
            zq.a(class_3322, b, f10, f11, f5, f5, f7, n5, true);
        }
        GlStateManager._disableBlend();
        GlStateManager._depthMask((boolean)true);
        GlStateManager._enableDepthTest();
    }

    private boolean a(class_1657 class_16572) {
        if (class_16572 == zb.a.field_1724 && !this.c.b()) {
            return false;
        }
        return !class_16572.method_7325();
    }
}

