/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1296
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1588
 *  net.minecraft.class_1657
 *  net.minecraft.class_276
 */
package com.vengeance.vengeanceclient.r.q.u;

import com.vengeance.vengeanceclient.mixin.WorldRendererAccessor;
import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import java.awt.Color;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_276;

public class zf
extends zb {
    private static zf b;
    private final com.vengeance.vengeanceclient.r.r.za c = new com.vengeance.vengeanceclient.r.r.za("Show Self", false);
    private final com.vengeance.vengeanceclient.r.r.za d = new com.vengeance.vengeanceclient.r.r.za("Show Players", true);
    private final com.vengeance.vengeanceclient.r.r.za e = new com.vengeance.vengeanceclient.r.r.za("Show Passives", false);
    private final com.vengeance.vengeanceclient.r.r.za f = new com.vengeance.vengeanceclient.r.r.za("Show Hostiles", false);
    private final ze g = new ze("Range", 10.0, 200.0, 100.0, 5.0);
    private final ze h = new ze("Outline Width", 1.0, 10.0, 3.0, 1.0);
    private final ze i = new ze("Intensity", 0.1, 2.0, 1.0, 0.1);
    private final com.vengeance.vengeanceclient.r.r.za j = new com.vengeance.vengeanceclient.r.r.za("Show Fill", true);
    private final ze k = new ze("Fill Alpha", 0.0, 255.0, 50.0, 5.0);
    private final com.vengeance.vengeanceclient.r.r.zb l = new com.vengeance.vengeanceclient.r.r.zb("Player Color", new Color(255, 50, 50));
    private final com.vengeance.vengeanceclient.r.r.zb m = new com.vengeance.vengeanceclient.r.r.zb("Friend Color", new Color(50, 255, 50));
    private final com.vengeance.vengeanceclient.r.r.zb n = new com.vengeance.vengeanceclient.r.r.zb("Passive Color", new Color(50, 255, 50));
    private final com.vengeance.vengeanceclient.r.r.zb o = new com.vengeance.vengeanceclient.r.r.zb("Hostile Color", new Color(255, 165, 0));
    private final Set<class_1297> p = new HashSet<class_1297>();

    public zf() {
        super("Custom Outline", "Custom post-processed outline ESP", za.d);
        b = this;
        this.a(this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j, this.k, this.l, this.m, this.n, this.o);
    }

    public static zf n() {
        return b;
    }

    public boolean a(class_1297 class_12972) {
        if (!this.l() || this.d()) {
            return false;
        }
        return this.c(class_12972);
    }

    public void o() {
        this.p.clear();
        if (this.d() || zf.a.field_1687 == null) {
            return;
        }
        for (class_1297 class_12972 : zf.a.field_1687.method_18112()) {
            if (!(class_12972 instanceof class_1309) || !this.c(class_12972)) continue;
            this.p.add(class_12972);
        }
    }

    public Set<class_1297> p() {
        return this.p;
    }

    private boolean c(class_1297 class_12972) {
        if (!(class_12972 instanceof class_1309)) {
            return false;
        }
        if (zf.a.field_1724 == null) {
            return false;
        }
        if (zf.a.field_1724.method_5858(class_12972) > this.g.f() * this.g.f()) {
            return false;
        }
        if (class_12972 instanceof class_1657) {
            class_1657 class_16572 = (class_1657)class_12972;
            if (class_16572 == zf.a.field_1724 && !this.c.b()) {
                return false;
            }
            return this.d.b();
        }
        if (class_12972 instanceof class_1296) {
            return this.e.b();
        }
        if (class_12972 instanceof class_1588) {
            return this.f.b();
        }
        return false;
    }

    public Color b(class_1297 class_12972) {
        if (class_12972 instanceof class_1657) {
            class_1657 class_16572 = (class_1657)class_12972;
            if (com.vengeance.vengeanceclient.utils.q.za.c(class_16572.method_5667())) {
                return this.m.h();
            }
            return this.l.h();
        }
        if (class_12972 instanceof class_1296) {
            return this.n.h();
        }
        if (class_12972 instanceof class_1588) {
            return this.o.h();
        }
        return this.l.h();
    }

    public float q() {
        return this.h.b();
    }

    public float r() {
        return this.i.b();
    }

    public boolean s() {
        return this.j.b();
    }

    public float t() {
        return this.k.b() / 255.0f;
    }

    public class_276 u() {
        if (zf.a.field_1769 == null) {
            return null;
        }
        return ((WorldRendererAccessor)zf.a.field_1769).getEntityOutlineFramebuffer();
    }
}

