/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_124
 *  net.minecraft.class_1296
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1588
 *  net.minecraft.class_1657
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_268
 *  net.minecraft.class_4604
 *  org.joml.Vector4d
 */
package com.vengeance.vengeanceclient.r.q.u;

import com.vengeance.vengeanceclient.r.r.zd;
import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import com.vengeance.vengeanceclient.utils.w.zr;
import java.awt.Color;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_268;
import net.minecraft.class_4604;
import org.joml.Vector4d;

public class zh
extends zb {
    private final zd b = new zd("Targets", "Players", "Players", "Passives", "Hostiles", "All");
    private final com.vengeance.vengeanceclient.r.r.za c = new com.vengeance.vengeanceclient.r.r.za("Show Self", false);
    private final ze d = new ze("Range", 10.0, 200.0, 64.0, 5.0);
    private final zd e = new zd("Box Mode", "Full", "Full", "Corners", "Rounded");
    private final com.vengeance.vengeanceclient.r.r.za f = new com.vengeance.vengeanceclient.r.r.za("Box", true);
    private final ze g = new ze("Box Expand", 0.0, 2.0, 0.0, 0.05);
    private final ze h = new ze("Round Radius", 0.0, 10.0, 3.0, 0.5);
    private final com.vengeance.vengeanceclient.r.r.za i = new com.vengeance.vengeanceclient.r.r.za("Box Fill", false);
    private final ze j = new ze("Fill Opacity", 0.0, 255.0, 80.0, 5.0);
    private final com.vengeance.vengeanceclient.r.r.za k = new com.vengeance.vengeanceclient.r.r.za("Health Bar", true);
    private final com.vengeance.vengeanceclient.r.r.za l = new com.vengeance.vengeanceclient.r.r.za("Team Color", false);
    private final com.vengeance.vengeanceclient.r.r.zb m = new com.vengeance.vengeanceclient.r.r.zb("Box Color", new Color(255, 255, 255));
    private final com.vengeance.vengeanceclient.r.r.zb n = new com.vengeance.vengeanceclient.r.r.zb("Player Color", new Color(255, 255, 255));
    private final com.vengeance.vengeanceclient.r.r.zb o = new com.vengeance.vengeanceclient.r.r.zb("Passive Color", new Color(0, 255, 0));
    private final com.vengeance.vengeanceclient.r.r.zb p = new com.vengeance.vengeanceclient.r.r.zb("Hostile Color", new Color(255, 0, 0));

    public zh() {
        super("2D ESP", "Draws 2D boxes around entities", -1, za.d);
        this.a(this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j, this.k, this.l, this.m, this.n, this.o, this.p);
    }

    @EventHandler
    private void onRender2D(com.vengeance.vengeanceclient.p.p.t.za za2) {
        if (this.d() || zh.a.field_1687 == null || zh.a.field_1724 == null) {
            return;
        }
        com.vengeance.vengeanceclient.utils.w.r.za.c();
        for (class_1297 class_12972 : zh.a.field_1687.method_18112()) {
            float f;
            float f2;
            float f3;
            Object object;
            if (!(class_12972 instanceof class_1309) || !this.b(class_12972)) continue;
            class_238 class_2383 = class_12972.method_5829();
            class_4604 class_46042 = zh.a.field_1769.method_62222();
            if (class_46042 != null && !class_46042.method_23093(class_2383)) continue;
            class_243 class_2432 = class_12972.method_30950(a.method_61966().method_60637(false));
            double d = class_2432.field_1352;
            double d2 = class_2432.field_1351;
            double d3 = class_2432.field_1350;
            class_238 class_2384 = new class_238(class_2383.field_1323 - class_12972.method_23317() + d - 0.05 - this.g.f(), class_2383.field_1322 - class_12972.method_23318() + d2 - this.g.f(), class_2383.field_1321 - class_12972.method_23321() + d3 - 0.05 - this.g.f(), class_2383.field_1320 - class_12972.method_23317() + d + 0.05 + this.g.f(), class_2383.field_1325 - class_12972.method_23318() + d2 + 0.1 + this.g.f(), class_2383.field_1324 - class_12972.method_23321() + d3 + 0.05 + this.g.f());
            class_243[] class_243Array = new class_243[]{new class_243(class_2384.field_1323, class_2384.field_1322, class_2384.field_1321), new class_243(class_2384.field_1323, class_2384.field_1325, class_2384.field_1321), new class_243(class_2384.field_1320, class_2384.field_1322, class_2384.field_1321), new class_243(class_2384.field_1320, class_2384.field_1325, class_2384.field_1321), new class_243(class_2384.field_1323, class_2384.field_1322, class_2384.field_1324), new class_243(class_2384.field_1323, class_2384.field_1325, class_2384.field_1324), new class_243(class_2384.field_1320, class_2384.field_1322, class_2384.field_1324), new class_243(class_2384.field_1320, class_2384.field_1325, class_2384.field_1324)};
            Vector4d vector4d = null;
            for (class_243 class_2433 : class_243Array) {
                object = zr.a(class_2433);
                if (!(((class_243)object).field_1350 > 0.0) || !(((class_243)object).field_1350 < 1.0)) continue;
                if (vector4d == null) {
                    vector4d = new Vector4d(((class_243)object).field_1352, ((class_243)object).field_1351, ((class_243)object).field_1350, 0.0);
                }
                vector4d.x = Math.min(((class_243)object).field_1352, vector4d.x);
                vector4d.y = Math.min(((class_243)object).field_1351, vector4d.y);
                vector4d.z = Math.max(((class_243)object).field_1352, vector4d.z);
                vector4d.w = Math.max(((class_243)object).field_1351, vector4d.w);
            }
            if (vector4d == null) continue;
            float f4 = (float)vector4d.x;
            float f5 = (float)vector4d.y;
            float f6 = (float)vector4d.z;
            float f7 = (float)vector4d.w;
            object = this.a(class_12972);
            if (this.i.b()) {
                int n = this.j.a();
                Color color = new Color(0, 0, 0, n);
                com.vengeance.vengeanceclient.utils.w.r.za.a(f4, f5, f6 - f4, f7 - f5, color);
            }
            if (this.f.b()) {
                float f8 = 1.0f;
                float f9 = 0.5f;
                if (this.e.a().equals("Full")) {
                    com.vengeance.vengeanceclient.utils.w.r.za.a(f4 - f8, f5, f9 + f8, f7 - f5 + f8, Color.BLACK);
                    com.vengeance.vengeanceclient.utils.w.r.za.a(f4 - f8, f5 - f8, f6 - f4 + f8, f9 + f8, Color.BLACK);
                    com.vengeance.vengeanceclient.utils.w.r.za.a(f6 - f9, f5, f9 + f8, f7 - f5 + f8, Color.BLACK);
                    com.vengeance.vengeanceclient.utils.w.r.za.a(f4 - f8, f7 - f9, f6 - f4 + f8, f9 + f8, Color.BLACK);
                    com.vengeance.vengeanceclient.utils.w.r.za.a(f4 - f9, f5, f9, f7 - f5, (Color)object);
                    com.vengeance.vengeanceclient.utils.w.r.za.a(f4, f7 - f9, f6 - f4, f9, (Color)object);
                    com.vengeance.vengeanceclient.utils.w.r.za.a(f4, f5 - f9, f6 - f4, f9, (Color)object);
                    com.vengeance.vengeanceclient.utils.w.r.za.a(f6 - f9, f5, f9, f7 - f5, (Color)object);
                } else if (this.e.a().equals("Rounded")) {
                    f3 = (float)this.h.f();
                    f2 = f6 - f4;
                    f = f7 - f5;
                    com.vengeance.vengeanceclient.utils.w.r.za.a(f4 - 1.0f, f5 - 1.0f, f2 + 2.0f, f + 2.0f, f3, 1.5f, Color.BLACK);
                    com.vengeance.vengeanceclient.utils.w.r.za.a(f4, f5, f2, f, f3, 1.0f, (Color)object);
                } else {
                    f3 = f6 - f4;
                    f2 = Math.min(f3 * 0.25f, 15.0f);
                    com.vengeance.vengeanceclient.utils.w.r.za.a(f4 - f8, f5, f9 + f8, f2 + f8, Color.BLACK);
                    com.vengeance.vengeanceclient.utils.w.r.za.a(f4 - f8, f5 - f8, f2 + f8, f9 + f8, Color.BLACK);
                    com.vengeance.vengeanceclient.utils.w.r.za.a(f6 - f9, f5, f9 + f8, f2 + f8, Color.BLACK);
                    com.vengeance.vengeanceclient.utils.w.r.za.a(f6 - f2 - f8, f5 - f8, f2 + f8, f9 + f8, Color.BLACK);
                    com.vengeance.vengeanceclient.utils.w.r.za.a(f4 - f8, f7 - f2, f9 + f8, f2 + f8, Color.BLACK);
                    com.vengeance.vengeanceclient.utils.w.r.za.a(f4 - f8, f7 - f9, f2 + f8, f9 + f8, Color.BLACK);
                    com.vengeance.vengeanceclient.utils.w.r.za.a(f6 - f9, f7 - f2, f9 + f8, f2 + f8, Color.BLACK);
                    com.vengeance.vengeanceclient.utils.w.r.za.a(f6 - f2 - f8, f7 - f9, f2 + f8, f9 + f8, Color.BLACK);
                    com.vengeance.vengeanceclient.utils.w.r.za.a(f4 - f9, f5, f9, f2, (Color)object);
                    com.vengeance.vengeanceclient.utils.w.r.za.a(f4, f5 - f9, f2, f9, (Color)object);
                    com.vengeance.vengeanceclient.utils.w.r.za.a(f6 - f9, f5, f9, f2, (Color)object);
                    com.vengeance.vengeanceclient.utils.w.r.za.a(f6 - f2, f5 - f9, f2, f9, (Color)object);
                    com.vengeance.vengeanceclient.utils.w.r.za.a(f4 - f9, f7 - f2, f9, f2, (Color)object);
                    com.vengeance.vengeanceclient.utils.w.r.za.a(f4, f7 - f9, f2, f9, (Color)object);
                    com.vengeance.vengeanceclient.utils.w.r.za.a(f6 - f9, f7 - f2, f9, f2, (Color)object);
                    com.vengeance.vengeanceclient.utils.w.r.za.a(f6 - f2, f7 - f9, f2, f9, (Color)object);
                }
            }
            if (!this.k.b() || !(class_12972 instanceof class_1309)) continue;
            class_1309 class_13092 = (class_1309)class_12972;
            float f10 = class_13092.method_6032();
            f3 = class_13092.method_6063();
            f2 = Math.min(f10 / f3, 1.0f);
            f = 1.5f;
            float f11 = f7 - f5;
            float f12 = f4 - f - 3.0f;
            float f13 = f5;
            float f14 = 0.3f;
            com.vengeance.vengeanceclient.utils.w.r.za.a(f12, f13, f + 0.5f, f11, Color.BLACK);
            com.vengeance.vengeanceclient.utils.w.r.za.a(f12, f13 - f14, f, f14, Color.BLACK);
            com.vengeance.vengeanceclient.utils.w.r.za.a(f12, f13 + f11, f, f14, Color.BLACK);
            float f15 = f11 * f2;
            float f16 = f13 + (f11 - f15);
            Color color = new Color(Math.max(0, ((Color)object).getRed() - 60), Math.max(0, ((Color)object).getGreen() - 60), Math.max(0, ((Color)object).getBlue() - 60));
            com.vengeance.vengeanceclient.utils.w.r.za.a(f12, f16, f, f15, 0.0f, (Color)object, color);
        }
        com.vengeance.vengeanceclient.utils.w.r.za.e();
    }

    private Color a(class_1297 class_12972) {
        class_124 class_1242;
        class_1309 class_13092;
        class_268 class_2682;
        if (this.l.b() && class_12972 instanceof class_1309 && (class_2682 = (class_13092 = (class_1309)class_12972).method_5781()) != null && (class_1242 = class_2682.method_1202()) != null && class_1242.method_532() != null) {
            return new Color(class_1242.method_532());
        }
        if (class_12972 instanceof class_1657) {
            return this.n.h();
        }
        if (class_12972 instanceof class_1296) {
            return this.o.h();
        }
        if (class_12972 instanceof class_1588) {
            return this.p.h();
        }
        return this.m.h();
    }

    private boolean b(class_1297 class_12972) {
        if (class_12972 == zh.a.field_1724 && !this.c.b()) {
            return false;
        }
        if ((double)zh.a.field_1724.method_5739(class_12972) > this.d.f()) {
            return false;
        }
        return switch (this.b.a()) {
            case "Players" -> class_12972 instanceof class_1657;
            case "Passives" -> class_12972 instanceof class_1296;
            case "Hostiles" -> class_12972 instanceof class_1588;
            case "All" -> {
                if (class_12972 instanceof class_1657 || class_12972 instanceof class_1296 || class_12972 instanceof class_1588) {
                    yield true;
                }
                yield false;
            }
            default -> false;
        };
    }
}

