/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1296
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1588
 *  net.minecraft.class_1657
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_268
 *  net.minecraft.class_4587
 *  net.minecraft.class_4604
 */
package com.vengeance.vengeanceclient.r.q.u;

import com.vengeance.vengeanceclient.r.r.zd;
import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import com.vengeance.vengeanceclient.utils.w.zm;
import java.awt.Color;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_268;
import net.minecraft.class_4587;
import net.minecraft.class_4604;

public class zi
extends zb {
    private final zd b = new zd("Targets", "Players", "Players", "Passives", "Hostiles", "All");
    private final com.vengeance.vengeanceclient.r.r.za c = new com.vengeance.vengeanceclient.r.r.za("Show Self", false);
    private final ze d = new ze("Range", 10.0, 200.0, 64.0, 5.0);
    private final zd e = new zd("Mode", "Both", "Outline", "Filled", "Both");
    private final ze f = new ze("Fill Opacity", 0.0, 255.0, 50.0, 5.0);
    private final com.vengeance.vengeanceclient.r.r.za g = new com.vengeance.vengeanceclient.r.r.za("Through Walls", true);
    private final com.vengeance.vengeanceclient.r.r.za h = new com.vengeance.vengeanceclient.r.r.za("Team Color", false);
    private final com.vengeance.vengeanceclient.r.r.zb i = new com.vengeance.vengeanceclient.r.r.zb("Player Color", new Color(255, 50, 50));
    private final com.vengeance.vengeanceclient.r.r.zb j = new com.vengeance.vengeanceclient.r.r.zb("Friend Color", new Color(50, 255, 50));
    private final com.vengeance.vengeanceclient.r.r.zb k = new com.vengeance.vengeanceclient.r.r.zb("Passive Color", new Color(50, 255, 50));
    private final com.vengeance.vengeanceclient.r.r.zb l = new com.vengeance.vengeanceclient.r.r.zb("Hostile Color", new Color(255, 165, 0));

    public zi() {
        super("3D ESP", "Draws 3D boxes around entities", -1, za.d);
        this.a(this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j, this.k, this.l);
    }

    @EventHandler
    private void onRender3D(com.vengeance.vengeanceclient.p.p.t.zb zb2) {
        if (this.d() || zi.a.field_1687 == null) {
            return;
        }
        class_4587 class_45872 = zb2.a();
        float f = a.method_61966().method_60637(true);
        if (this.g.b()) {
            zm.b();
        } else {
            zm.a();
        }
        for (class_1297 class_12972 : zi.a.field_1687.method_18112()) {
            if (!(class_12972 instanceof class_1309) || !this.a(class_12972)) continue;
            class_238 class_2383 = class_12972.method_5829();
            class_4604 class_46042 = zi.a.field_1769.method_62222();
            if (class_46042 != null && !class_46042.method_23093(class_2383)) continue;
            class_243 class_2432 = zm.a(class_12972, f);
            Color color = this.b(class_12972);
            if (this.e.b("Filled") || this.e.b("Both")) {
                Color color2 = new Color(color.getRed(), color.getGreen(), color.getBlue(), this.f.a());
                zm.c(class_45872, class_2432.field_1352, class_2432.field_1351, class_2432.field_1350, class_12972.method_17681(), class_12972.method_17682(), color2);
            }
            if (!this.e.b("Outline") && !this.e.b("Both")) continue;
            zm.b(class_45872, class_2432.field_1352, class_2432.field_1351, class_2432.field_1350, class_12972.method_17681(), class_12972.method_17682(), color);
        }
        zm.c();
    }

    private boolean a(class_1297 class_12972) {
        if (class_12972 == zi.a.field_1724 && !this.c.b()) {
            return false;
        }
        if (zi.a.field_1724.method_5858(class_12972) > this.d.f() * this.d.f()) {
            return false;
        }
        String string = this.b.a();
        if (class_12972 instanceof class_1657) {
            return string.equals("Players") || string.equals("All");
        }
        if (class_12972 instanceof class_1296) {
            return string.equals("Passives") || string.equals("All");
        }
        if (class_12972 instanceof class_1588) {
            return string.equals("Hostiles") || string.equals("All");
        }
        return string.equals("All");
    }

    private Color b(class_1297 class_12972) {
        if (class_12972 instanceof class_1657) {
            class_268 class_2682;
            class_1657 class_16572 = (class_1657)class_12972;
            if (com.vengeance.vengeanceclient.utils.q.za.c(class_16572.method_5667())) {
                return this.j.h();
            }
            if (this.h.b() && (class_2682 = class_16572.method_5781()) != null && class_2682.method_1202().method_532() != null) {
                return new Color(class_2682.method_1202().method_532());
            }
            return this.i.h();
        }
        if (class_12972 instanceof class_1296) {
            return this.k.h();
        }
        if (class_12972 instanceof class_1588) {
            return this.l.h();
        }
        return this.i.h();
    }
}

