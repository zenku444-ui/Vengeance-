/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1293
 *  net.minecraft.class_1294
 *  net.minecraft.class_7172
 */
package com.vengeance.vengeanceclient.r.q.u;

import com.vengeance.vengeanceclient.p.p.s.zd;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_7172;

public class zj
extends zb {
    private static final double b = 16.0;
    private static final int c = 220;
    private Double d = null;

    public zj() {
        super("Full Bright", "Removes darkness", za.d);
    }

    @Override
    public void b() {
        super.b();
        this.n();
    }

    @EventHandler
    private void onTick(zd zd2) {
        this.n();
        this.o();
    }

    private void n() {
        if (a != null && zj.a.field_1690 != null) {
            try {
                class_7172 class_71722 = zj.a.field_1690.method_42473();
                if (this.d == null) {
                    this.d = (Double)class_71722.method_41753();
                }
                class_71722.method_41748((Object)16.0);
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }

    private void o() {
        if (a == null || zj.a.field_1724 == null) {
            return;
        }
        try {
            zj.a.field_1724.method_6092(new class_1293(class_1294.field_5925, 220, 0, false, false));
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    @Override
    public void c() {
        super.c();
        if (a != null && zj.a.field_1690 != null && this.d != null) {
            try {
                zj.a.field_1690.method_42473().method_41748((Object)this.d);
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
        this.d = null;
    }
}

