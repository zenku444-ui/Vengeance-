/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.opengl.GlStateManager
 *  net.minecraft.class_124
 *  net.minecraft.class_1296
 *  net.minecraft.class_1297
 *  net.minecraft.class_1304
 *  net.minecraft.class_1309
 *  net.minecraft.class_1588
 *  net.minecraft.class_1657
 *  net.minecraft.class_1799
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_268
 *  net.minecraft.class_4604
 *  org.joml.Vector4d
 */
package com.vengeance.vengeanceclient.r.q.u;

import com.mojang.blaze3d.opengl.GlStateManager;
import com.vengeance.vengeanceclient.r.r.zd;
import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import com.vengeance.vengeanceclient.utils.w.zr;
import java.awt.Color;
import java.util.ArrayList;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_268;
import net.minecraft.class_4604;
import org.joml.Vector4d;

public class zk
extends zb {
    private final zd b = new zd("Targets", "Players", "Players", "Passives", "Hostiles", "All");
    private final com.vengeance.vengeanceclient.r.r.za c = new com.vengeance.vengeanceclient.r.r.za("Show Self", false);
    private final ze d = new ze("Range", 10.0, 200.0, 64.0, 5.0);
    private final com.vengeance.vengeanceclient.r.r.za e = new com.vengeance.vengeanceclient.r.r.za("Show Health", true);
    private final com.vengeance.vengeanceclient.r.r.za f = new com.vengeance.vengeanceclient.r.r.za("Show Armor", true);
    private final com.vengeance.vengeanceclient.r.r.za g = new com.vengeance.vengeanceclient.r.r.za("Show Weapon", true);
    private final com.vengeance.vengeanceclient.r.r.za h = new com.vengeance.vengeanceclient.r.r.za("Scale With Distance", true);
    private final ze i = new ze("Min Scale", 0.1, 2.0, 0.5, 0.1);
    private final ze j = new ze("Max Scale", 0.1, 3.0, 1.5, 0.1);
    private final com.vengeance.vengeanceclient.r.r.za k = new com.vengeance.vengeanceclient.r.r.za("Team Color", false);
    private final com.vengeance.vengeanceclient.r.r.zb l = new com.vengeance.vengeanceclient.r.r.zb("Border Color", new Color(255, 255, 255));
    private final com.vengeance.vengeanceclient.r.r.zb m = new com.vengeance.vengeanceclient.r.r.zb("Player Color", new Color(255, 255, 255));
    private final com.vengeance.vengeanceclient.r.r.zb n = new com.vengeance.vengeanceclient.r.r.zb("Passive Color", new Color(0, 255, 0));
    private final com.vengeance.vengeanceclient.r.r.zb o = new com.vengeance.vengeanceclient.r.r.zb("Hostile Color", new Color(255, 0, 0));

    public zk() {
        super("Nametags", "Displays nametags above entities", -1, za.d);
        this.a(this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j, this.k, this.l, this.m, this.n, this.o);
    }

    @EventHandler
    private void onRender2D(com.vengeance.vengeanceclient.p.p.t.za za2) {
        if (this.d() || zk.a.field_1687 == null || zk.a.field_1724 == null) {
            return;
        }
        GlStateManager._disableDepthTest();
        com.vengeance.vengeanceclient.utils.w.r.za.c();
        for (class_1297 class_12972 : zk.a.field_1687.method_18112()) {
            float f;
            float f2;
            Object object;
            class_243 class_24322;
            if (!(class_12972 instanceof class_1309) || !this.b(class_12972)) continue;
            class_238 class_2383 = class_12972.method_5829();
            class_4604 class_46042 = zk.a.field_1769.method_62222();
            if (class_46042 != null && !class_46042.method_23093(class_2383)) continue;
            class_243 class_2433 = class_12972.method_30950(a.method_61966().method_60637(false));
            double d = class_2433.field_1352;
            double d2 = class_2433.field_1351;
            double d3 = class_2433.field_1350;
            class_238 class_2384 = new class_238(class_2383.field_1323 - class_12972.method_23317() + d - 0.05, class_2383.field_1322 - class_12972.method_23318() + d2, class_2383.field_1321 - class_12972.method_23321() + d3 - 0.05, class_2383.field_1320 - class_12972.method_23317() + d + 0.05, class_2383.field_1325 - class_12972.method_23318() + d2 + 0.1, class_2383.field_1324 - class_12972.method_23321() + d3 + 0.05);
            class_243[] class_243Array = new class_243[]{new class_243(class_2384.field_1323, class_2384.field_1322, class_2384.field_1321), new class_243(class_2384.field_1323, class_2384.field_1325, class_2384.field_1321), new class_243(class_2384.field_1320, class_2384.field_1322, class_2384.field_1321), new class_243(class_2384.field_1320, class_2384.field_1325, class_2384.field_1321), new class_243(class_2384.field_1323, class_2384.field_1322, class_2384.field_1324), new class_243(class_2384.field_1323, class_2384.field_1325, class_2384.field_1324), new class_243(class_2384.field_1320, class_2384.field_1322, class_2384.field_1324), new class_243(class_2384.field_1320, class_2384.field_1325, class_2384.field_1324)};
            Vector4d vector4d = null;
            for (class_243 class_24322 : class_243Array) {
                object = zr.a(class_24322);
                if (!(object.field_1350 > 0.0) || !(object.field_1350 < 1.0)) continue;
                if (vector4d == null) {
                    vector4d = new Vector4d(object.field_1352, object.field_1351, object.field_1350, 0.0);
                }
                vector4d.x = Math.min(object.field_1352, vector4d.x);
                vector4d.y = Math.min(object.field_1351, vector4d.y);
                vector4d.z = Math.max(object.field_1352, vector4d.z);
                vector4d.w = Math.max(object.field_1351, vector4d.w);
            }
            if (vector4d == null) continue;
            float f3 = (float)vector4d.x;
            float f4 = (float)vector4d.y;
            float f5 = (float)vector4d.z;
            class_24322 = (class_1309)class_12972;
            object = class_12972.method_5477().getString();
            float f6 = class_24322.method_6032();
            float f7 = class_24322.method_6063();
            float f8 = zk.a.field_1724.method_5739(class_12972);
            float f9 = 1.0f;
            if (this.h.b()) {
                float f10 = 5.0f;
                f2 = (float)this.d.f();
                f = Math.min(Math.max((f8 - f10) / (f2 - f10), 0.0f), 1.0f);
                f9 = (float)(this.j.f() - (double)f * (this.j.f() - this.i.f()));
            }
            String string = this.e.b() ? String.format(" %.1f", Float.valueOf(f6)) : "";
            f2 = 9.0f * f9;
            f = com.vengeance.vengeanceclient.utils.w.r.za.a((String)object, f2);
            float f11 = this.e.b() ? com.vengeance.vengeanceclient.utils.w.r.za.a(string, f2) : 0.0f;
            float f12 = f + f11;
            float f13 = 3.0f * f9;
            float f14 = f12 + f13 * 2.0f;
            float f15 = f2 + f13 * 2.0f;
            float f16 = f3 + (f5 - f3 - f14) / 2.0f;
            float f17 = f4 - f15 - 3.0f * f9;
            Color color = new Color(0, 0, 0, 180);
            Color color2 = this.a(class_12972);
            Color color3 = new Color(color2.getRed(), color2.getGreen(), color2.getBlue(), 200);
            com.vengeance.vengeanceclient.utils.w.r.za.a(f16, f17, f14, f15, 3.0f * f9, color);
            com.vengeance.vengeanceclient.utils.w.r.za.a(f16, f17, f14, f15, 3.0f * f9, 1.0f * f9, color3);
            float f18 = f16 + f13;
            float f19 = f17 + f13;
            Color color4 = new Color(255, 255, 255, 255);
            com.vengeance.vengeanceclient.utils.w.r.za.a((String)object, f18, f19, f2, color4);
            if (!this.e.b()) continue;
            float f20 = f6 / f7;
            Color color5 = f20 > 0.6f ? new Color(85, 255, 85, 255) : (f20 > 0.3f ? new Color(255, 255, 85, 255) : new Color(255, 85, 85, 255));
            com.vengeance.vengeanceclient.utils.w.r.za.a(string, f18 + f, f19, f2, color5);
        }
        com.vengeance.vengeanceclient.utils.w.r.za.e();
        this.a(za2);
        GlStateManager._enableDepthTest();
    }

    private void a(com.vengeance.vengeanceclient.p.p.t.za za2) {
        for (class_1297 class_12972 : zk.a.field_1687.method_18112()) {
            class_1304 class_13042;
            int n;
            float f;
            if (!(class_12972 instanceof class_1657)) continue;
            class_1657 class_16572 = (class_1657)class_12972;
            if (!this.b(class_12972)) continue;
            class_238 class_2383 = class_12972.method_5829();
            class_4604 class_46042 = zk.a.field_1769.method_62222();
            if (class_46042 != null && !class_46042.method_23093(class_2383)) continue;
            class_243 class_2432 = class_12972.method_30950(a.method_61966().method_60637(false));
            double d = class_2432.field_1352;
            double d2 = class_2432.field_1351;
            double d3 = class_2432.field_1350;
            class_238 class_2384 = new class_238(class_2383.field_1323 - class_12972.method_23317() + d - 0.05, class_2383.field_1322 - class_12972.method_23318() + d2, class_2383.field_1321 - class_12972.method_23321() + d3 - 0.05, class_2383.field_1320 - class_12972.method_23317() + d + 0.05, class_2383.field_1325 - class_12972.method_23318() + d2 + 0.1, class_2383.field_1324 - class_12972.method_23321() + d3 + 0.05);
            class_243[] class_243Array = new class_243[]{new class_243(class_2384.field_1323, class_2384.field_1322, class_2384.field_1321), new class_243(class_2384.field_1323, class_2384.field_1325, class_2384.field_1321), new class_243(class_2384.field_1320, class_2384.field_1322, class_2384.field_1321), new class_243(class_2384.field_1320, class_2384.field_1325, class_2384.field_1321), new class_243(class_2384.field_1323, class_2384.field_1322, class_2384.field_1324), new class_243(class_2384.field_1323, class_2384.field_1325, class_2384.field_1324), new class_243(class_2384.field_1320, class_2384.field_1322, class_2384.field_1324), new class_243(class_2384.field_1320, class_2384.field_1325, class_2384.field_1324)};
            Vector4d vector4d = null;
            for (class_243 class_2433 : class_243Array) {
                class_243 class_2434 = zr.a(class_2433);
                if (!(class_2434.field_1350 > 0.0) || !(class_2434.field_1350 < 1.0)) continue;
                if (vector4d == null) {
                    vector4d = new Vector4d(class_2434.field_1352, class_2434.field_1351, class_2434.field_1350, 0.0);
                }
                vector4d.x = Math.min(class_2434.field_1352, vector4d.x);
                vector4d.y = Math.min(class_2434.field_1351, vector4d.y);
                vector4d.z = Math.max(class_2434.field_1352, vector4d.z);
                vector4d.w = Math.max(class_2434.field_1351, vector4d.w);
            }
            if (vector4d == null) continue;
            float f2 = (float)vector4d.x;
            float f3 = (float)vector4d.y;
            float f4 = (float)vector4d.z;
            float f5 = zk.a.field_1724.method_5739(class_12972);
            float f6 = 1.0f;
            if (this.h.b()) {
                float f7 = 5.0f;
                float f8 = (float)this.d.f();
                f = Math.min(Math.max((f5 - f7) / (f8 - f7), 0.0f), 1.0f);
                f6 = (float)(this.j.f() - (double)f * (this.j.f() - this.i.f()));
            }
            String string = class_12972.method_5477().getString();
            String string2 = this.e.b() ? String.format(" %.1f", Float.valueOf(class_16572.method_6032())) : "";
            f = 9.0f * f6;
            float f9 = com.vengeance.vengeanceclient.utils.w.r.za.a(string, f);
            float f10 = this.e.b() ? com.vengeance.vengeanceclient.utils.w.r.za.a(string2, f) : 0.0f;
            float f11 = f9 + f10;
            float f12 = 3.0f * f6;
            float f13 = f11 + f12 * 2.0f;
            float f14 = f + f12 * 2.0f;
            float f15 = f2 + (f4 - f2 - f13) / 2.0f;
            float f16 = f3 - f14 - 3.0f * f6;
            float f17 = f16 - 18.0f * f6 - 2.0f * f6;
            float f18 = 16.0f * f6;
            float f19 = 2.0f * f6;
            ArrayList<class_1799> arrayList = new ArrayList<class_1799>();
            if (this.g.b() && !class_16572.method_6047().method_7960()) {
                arrayList.add(class_16572.method_6047());
            }
            if (this.f.b()) {
                class_1304[] class_1304Array = new class_1304[]{class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166};
                int n2 = class_1304Array.length;
                for (n = 0; n < n2; ++n) {
                    class_13042 = class_1304Array[n];
                    class_1799 class_17992 = class_16572.method_6118(class_13042);
                    if (class_17992.method_7960()) continue;
                    arrayList.add(class_17992);
                }
            }
            if (arrayList.isEmpty()) continue;
            float f20 = (float)arrayList.size() * f18 + (float)(arrayList.size() - 1) * f19;
            float f21 = f2 + (f4 - f2 - f20) / 2.0f;
            za2.a().method_51448().pushMatrix();
            za2.a().method_51448().translate(f21, f17);
            za2.a().method_51448().scale(f6, f6);
            for (n = 0; n < arrayList.size(); ++n) {
                class_13042 = (class_1799)arrayList.get(n);
                float f22 = (float)n * (f18 + f19) / f6;
                za2.a().method_51427((class_1799)class_13042, (int)f22, 0);
            }
            za2.a().method_51448().popMatrix();
        }
    }

    private Color a(class_1297 class_12972) {
        class_124 class_1242;
        class_1309 class_13092;
        class_268 class_2682;
        if (this.k.b() && class_12972 instanceof class_1309 && (class_2682 = (class_13092 = (class_1309)class_12972).method_5781()) != null && (class_1242 = class_2682.method_1202()) != null && class_1242.method_532() != null) {
            return new Color(class_1242.method_532());
        }
        if (class_12972 instanceof class_1657) {
            return this.m.h();
        }
        if (class_12972 instanceof class_1296) {
            return this.n.h();
        }
        if (class_12972 instanceof class_1588) {
            return this.o.h();
        }
        return this.l.h();
    }

    private boolean b(class_1297 class_12972) {
        if (class_12972 == zk.a.field_1724 && !this.c.b()) {
            return false;
        }
        if ((double)zk.a.field_1724.method_5739(class_12972) > this.d.f()) {
            return false;
        }
        return switch (this.b.a()) {
            case "Players" -> class_12972 instanceof class_1657;
            case "Passives" -> class_12972 instanceof class_1296;
            case "Hostiles" -> class_12972 instanceof class_1588;
            case "All" -> {
                if (class_12972 instanceof class_1657 || class_12972 instanceof class_1296 || class_12972 instanceof class_1588) {
                    yield true;
                }
                yield false;
            }
            default -> false;
        };
    }
}

