/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_124
 *  net.minecraft.class_1296
 *  net.minecraft.class_1297
 *  net.minecraft.class_1588
 *  net.minecraft.class_1657
 *  net.minecraft.class_268
 */
package com.vengeance.vengeanceclient.r.q.u;

import com.vengeance.vengeanceclient.p.p.s.zd;
import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import java.awt.Color;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_268;

public class zm
extends zb {
    private static zm b;
    private final com.vengeance.vengeanceclient.r.r.za c = new com.vengeance.vengeanceclient.r.r.za("Show Self", false);
    private final com.vengeance.vengeanceclient.r.r.za d = new com.vengeance.vengeanceclient.r.r.za("Team Check", false);
    private final com.vengeance.vengeanceclient.r.r.za e = new com.vengeance.vengeanceclient.r.r.za("Show Passives", false);
    private final com.vengeance.vengeanceclient.r.r.za f = new com.vengeance.vengeanceclient.r.r.za("Show Hostiles", false);
    private final ze g = new ze("Range", 10.0, 200.0, 100.0, 5.0);
    private final com.vengeance.vengeanceclient.r.r.zb h = new com.vengeance.vengeanceclient.r.r.zb("Player Color", new Color(255, 255, 255));
    private final com.vengeance.vengeanceclient.r.r.zb i = new com.vengeance.vengeanceclient.r.r.zb("Passive Color", new Color(0, 255, 0));
    private final com.vengeance.vengeanceclient.r.r.zb j = new com.vengeance.vengeanceclient.r.r.zb("Hostile Color", new Color(255, 0, 0));
    private final Set<Integer> k = new HashSet<Integer>();

    public zm() {
        super("Outline ESP", "Uses Minecraft's glowing effect for entity outlines", za.d);
        b = this;
        this.a(this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j);
    }

    public static zm n() {
        return b;
    }

    public boolean a(class_1297 class_12972) {
        if (!this.l() || this.d()) {
            return false;
        }
        return this.d(class_12972);
    }

    public boolean b(class_1297 class_12972) {
        return this.k.contains(class_12972.method_5628());
    }

    @EventHandler
    private void onTick(zd zd2) {
        if (this.d() || zm.a.field_1687 == null) {
            return;
        }
        try {
            for (class_1297 class_12972 : zm.a.field_1687.method_18112()) {
                if (this.d(class_12972)) {
                    this.e(class_12972);
                    continue;
                }
                this.c(class_12972);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private void c(class_1297 class_12972) {
        if (!this.k.contains(class_12972.method_5628())) {
            return;
        }
        if (zm.a.field_1687 == null || zm.a.field_1687.method_8428() == null) {
            return;
        }
        this.k.remove(class_12972.method_5628());
        try {
            class_268 class_2682;
            String string = "outlineESP_" + class_12972.method_5628();
            class_268 class_2683 = zm.a.field_1687.method_8428().method_1153(string);
            if (class_2683 != null) {
                zm.a.field_1687.method_8428().method_1157(class_12972.method_5820(), class_2683);
                zm.a.field_1687.method_8428().method_1191(class_2683);
            }
            if ((class_2682 = class_12972.method_5781()) != null && class_2682.method_1197().startsWith("outlineESP_")) {
                zm.a.field_1687.method_8428().method_1157(class_12972.method_5820(), class_2682);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private boolean d(class_1297 class_12972) {
        if ((double)zm.a.field_1724.method_5739(class_12972) > this.g.f()) {
            return false;
        }
        if (class_12972 instanceof class_1657) {
            class_1657 class_16572 = (class_1657)class_12972;
            if (class_16572 == zm.a.field_1724 && !this.c.b()) {
                return false;
            }
            return !this.d.b() || !this.a(class_16572);
        }
        if (class_12972 instanceof class_1296) {
            return this.e.b();
        }
        if (class_12972 instanceof class_1588) {
            return this.f.b();
        }
        return false;
    }

    private boolean a(class_1657 class_16572) {
        if (zm.a.field_1724.method_5781() == null || class_16572.method_5781() == null) {
            return false;
        }
        return zm.a.field_1724.method_5781().equals(class_16572.method_5781());
    }

    private void e(class_1297 class_12972) {
        if (zm.a.field_1687 == null || zm.a.field_1687.method_8428() == null) {
            return;
        }
        this.k.add(class_12972.method_5628());
        try {
            class_268 class_2682;
            String string = "outlineESP_" + class_12972.method_5628();
            class_268 class_2683 = class_12972.method_5781();
            if (class_2683 != null && !class_2683.method_1197().startsWith("outlineESP_")) {
                zm.a.field_1687.method_8428().method_1157(class_12972.method_5820(), class_2683);
            }
            if ((class_2682 = zm.a.field_1687.method_8428().method_1153(string)) == null) {
                class_2682 = zm.a.field_1687.method_8428().method_1171(string);
            }
            if (class_12972.method_5781() != class_2682) {
                zm.a.field_1687.method_8428().method_1172(class_12972.method_5820(), class_2682);
            }
            Color color = this.f(class_12972);
            class_2682.method_1141(this.a(color));
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private Color f(class_1297 class_12972) {
        if (class_12972 instanceof class_1657) {
            class_1657 class_16572 = (class_1657)class_12972;
            if (com.vengeance.vengeanceclient.utils.q.za.c(class_16572.method_5667())) {
                return new Color(128, 0, 128);
            }
            return this.h.h();
        }
        if (class_12972 instanceof class_1296) {
            return this.i.h();
        }
        if (class_12972 instanceof class_1588) {
            return this.j.h();
        }
        return this.h.h();
    }

    private class_124 a(Color color) {
        int n = color.getRed();
        int n2 = color.getGreen();
        int n3 = color.getBlue();
        if (n > 200 && n2 < 100 && n3 < 100) {
            return class_124.field_1061;
        }
        if (n < 100 && n2 > 200 && n3 < 100) {
            return class_124.field_1060;
        }
        if (n < 100 && n2 < 100 && n3 > 200) {
            return class_124.field_1078;
        }
        if (n > 200 && n2 > 200 && n3 < 100) {
            return class_124.field_1054;
        }
        if (n > 200 && n2 < 100 && n3 > 200) {
            return class_124.field_1076;
        }
        if (n < 100 && n2 > 200 && n3 > 200) {
            return class_124.field_1075;
        }
        if (n > 200 && n2 > 200 && n3 > 200) {
            return class_124.field_1068;
        }
        if (n < 100 && n2 < 100 && n3 < 100) {
            return class_124.field_1063;
        }
        return class_124.field_1068;
    }

    @Override
    public void c() {
        if (!this.d() && zm.a.field_1687 != null && zm.a.field_1687.method_8428() != null) {
            try {
                Object object2;
                HashSet<Integer> hashSet = new HashSet<Integer>(this.k);
                for (Object object2 : zm.a.field_1687.method_18112()) {
                    if (!hashSet.contains(object2.method_5628())) continue;
                    this.c((class_1297)object2);
                }
                ArrayList arrayList = new ArrayList();
                for (class_268 class_2682 : zm.a.field_1687.method_8428().method_1159()) {
                    if (!class_2682.method_1197().startsWith("outlineESP_")) continue;
                    arrayList.add(class_2682);
                }
                object2 = arrayList.iterator();
                while (object2.hasNext()) {
                    class_268 class_2682;
                    class_2682 = (class_268)object2.next();
                    zm.a.field_1687.method_8428().method_1191(class_2682);
                }
                this.k.clear();
            }
            catch (Exception exception) {
                this.k.clear();
            }
        }
        super.c();
    }
}

