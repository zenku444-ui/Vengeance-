/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.opengl.GlStateManager
 *  net.minecraft.class_12249
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_243
 *  net.minecraft.class_2960
 *  net.minecraft.class_4587
 *  net.minecraft.class_4588
 *  net.minecraft.class_4597
 *  net.minecraft.class_4597$class_4598
 *  net.minecraft.class_7833
 *  net.minecraft.class_9799
 *  org.joml.Matrix4f
 *  org.joml.Matrix4fc
 *  org.joml.Quaternionfc
 */
package com.vengeance.vengeanceclient.r.q.u;

import com.mojang.blaze3d.opengl.GlStateManager;
import com.vengeance.vengeanceclient.r.r.zd;
import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.za;
import com.vengeance.vengeanceclient.r.zb;
import com.vengeance.vengeanceclient.utils.w.zm;
import java.awt.Color;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_12249;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import net.minecraft.class_9799;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Quaternionfc;

public final class zo
extends zb {
    private static final class_2960 b = class_2960.method_60655((String)"vengeance-client", (String)"textures/visuals/firefly.png");
    private static final class_9799 c = new class_9799(65536);
    private final zd d = new zd("Targets", "Players", "Players", "Living");
    private final ze e = new ze("Layers", 1.0, 5.0, 3.0, 1.0);
    private final ze f = new ze("Orbs Per Layer", 5.0, 20.0, 14.0, 1.0);
    private final ze g = new ze("Orb Size", 0.1, 0.8, 0.3, 0.05);
    private final ze h = new ze("Speed", 0.5, 5.0, 2.5, 0.1);
    private final ze i = new ze("Height Offset", 0.0, 2.0, 1.0, 0.1);
    private final zd j = new zd("Color Mode", "Single", "Single", "Gradient");
    private final com.vengeance.vengeanceclient.r.r.zb k = new com.vengeance.vengeanceclient.r.r.zb("Color", new Color(120, 240, 255, 220));
    private final com.vengeance.vengeanceclient.r.r.zb l = new com.vengeance.vengeanceclient.r.r.zb("Gradient Color 1", new Color(255, 0, 0, 220));
    private final com.vengeance.vengeanceclient.r.r.zb m = new com.vengeance.vengeanceclient.r.r.zb("Gradient Color 2", new Color(0, 0, 255, 220));

    public zo() {
        super("Target ESP", "Ghost-like spiral orbs around players", -1, za.d);
        this.a(this.d, this.e, this.f, this.g, this.h, this.i, this.j, this.k, this.l, this.m);
    }

    @EventHandler
    private void onRender3D(com.vengeance.vengeanceclient.p.p.t.zb zb2) {
        if (this.d()) {
            return;
        }
        class_4587 class_45872 = zb2.a();
        float f = a.method_61966().method_60637(true);
        GlStateManager._enableBlend();
        GlStateManager._blendFuncSeparate((int)770, (int)1, (int)1, (int)1);
        float f2 = this.g.b();
        float f3 = this.i.b();
        Color color = this.k.h();
        int n = this.e.a();
        int n2 = this.f.a();
        boolean bl = this.j.b("Gradient");
        float f4 = (float)(System.currentTimeMillis() % 100000L) / 50.0f;
        float f5 = f4 * this.h.b();
        for (class_1297 class_12972 : zo.a.field_1687.method_18112()) {
            if (!this.a(class_12972)) continue;
            class_243 class_2432 = zm.a(class_12972, f);
            double d = class_2432.field_1352;
            double d2 = class_2432.field_1351 + (double)f3;
            double d3 = class_2432.field_1350;
            if (zo.a.field_1724.method_6057(class_12972)) {
                GlStateManager._enableDepthTest();
                GlStateManager._depthMask((boolean)false);
            } else {
                GlStateManager._disableDepthTest();
            }
            class_4597.class_4598 class_45982 = class_4597.method_22991((class_9799)c);
            class_4588 class_45882 = class_45982.method_73477(class_12249.method_76000((class_2960)b));
            for (int i = 0; i < n; ++i) {
                float f6 = (float)i * 120.0f;
                float f7 = (float)i + 1.0f;
                for (int j = 0; j <= n2; ++j) {
                    int n3;
                    float f8 = j;
                    double d4 = Math.toRadians(((f8 / 1.5f + f4 * this.h.b()) * 8.0f + f6) % 2880.0f);
                    double d5 = Math.sin(Math.toRadians(f5 + (float)j * f7) * 3.0) / (double)1.8f;
                    float f9 = f8 / (float)n2;
                    if (bl) {
                        Color color2 = this.a(this.l.h(), this.m.h(), f9);
                        n3 = this.a(color2.getRGB(), f9);
                    } else {
                        n3 = this.a(color.getRGB(), f9);
                    }
                    double d6 = Math.cos(d4) * (double)class_12972.method_17681();
                    double d7 = d5;
                    double d8 = Math.sin(d4) * (double)class_12972.method_17681();
                    class_45872.method_22903();
                    class_45872.method_22904(d + d6, d2 + d7, d3 + d8);
                    class_45872.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees(-zo.a.field_1773.method_19418().method_19330()));
                    class_45872.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(zo.a.field_1773.method_19418().method_19329()));
                    Matrix4f matrix4f = class_45872.method_23760().method_23761();
                    float f10 = (float)(n3 >>> 24 & 0xFF) / 255.0f;
                    float f11 = (float)(n3 >>> 16 & 0xFF) / 255.0f;
                    float f12 = (float)(n3 >>> 8 & 0xFF) / 255.0f;
                    float f13 = (float)(n3 & 0xFF) / 255.0f;
                    int n4 = Math.max(0, Math.min(255, Math.round(f11 * 255.0f)));
                    int n5 = Math.max(0, Math.min(255, Math.round(f12 * 255.0f)));
                    int n6 = Math.max(0, Math.min(255, Math.round(f13 * 255.0f)));
                    int n7 = Math.max(0, Math.min(255, Math.round(f10 * 255.0f)));
                    class_45882.method_22918((Matrix4fc)matrix4f, -f2, f2, 0.0f).method_22913(0.0f, 1.0f).method_1336(n4, n5, n6, n7).method_22922(0).method_60803(0xF000F0);
                    class_45882.method_22918((Matrix4fc)matrix4f, f2, f2, 0.0f).method_22913(1.0f, 1.0f).method_1336(n4, n5, n6, n7).method_22922(0).method_60803(0xF000F0);
                    class_45882.method_22918((Matrix4fc)matrix4f, f2, -f2, 0.0f).method_22913(1.0f, 0.0f).method_1336(n4, n5, n6, n7).method_22922(0).method_60803(0xF000F0);
                    class_45882.method_22918((Matrix4fc)matrix4f, -f2, -f2, 0.0f).method_22913(0.0f, 0.0f).method_1336(n4, n5, n6, n7).method_22922(0).method_60803(0xF000F0);
                    class_45872.method_22909();
                }
            }
            class_45982.method_22993();
            if (!zo.a.field_1724.method_6057(class_12972)) continue;
            GlStateManager._depthMask((boolean)true);
        }
        GlStateManager._enableDepthTest();
        GlStateManager._disableBlend();
    }

    private Color a(Color color, Color color2, float f) {
        f = Math.min(1.0f, Math.max(0.0f, f));
        int n = (int)((float)color.getRed() * (1.0f - f) + (float)color2.getRed() * f);
        int n2 = (int)((float)color.getGreen() * (1.0f - f) + (float)color2.getGreen() * f);
        int n3 = (int)((float)color.getBlue() * (1.0f - f) + (float)color2.getBlue() * f);
        int n4 = (int)((float)color.getAlpha() * (1.0f - f) + (float)color2.getAlpha() * f);
        return new Color(n, n2, n3, n4);
    }

    private int a(int n, float f) {
        f = Math.min(1.0f, Math.max(0.0f, f));
        Color color = new Color(n, true);
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)((float)color.getAlpha() * f)).getRGB();
    }

    private boolean a(class_1297 class_12972) {
        if (class_12972 == zo.a.field_1724) {
            return false;
        }
        if (this.d.b("Players")) {
            return class_12972 instanceof class_1657;
        }
        return class_12972 instanceof class_1309;
    }
}

