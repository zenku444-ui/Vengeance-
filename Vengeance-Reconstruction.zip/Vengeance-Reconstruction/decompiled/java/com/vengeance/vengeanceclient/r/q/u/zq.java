/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1536
 *  net.minecraft.class_1667
 *  net.minecraft.class_1675
 *  net.minecraft.class_1679
 *  net.minecraft.class_1680
 *  net.minecraft.class_1681
 *  net.minecraft.class_1683
 *  net.minecraft.class_1684
 *  net.minecraft.class_1685
 *  net.minecraft.class_1686
 *  net.minecraft.class_1753
 *  net.minecraft.class_1764
 *  net.minecraft.class_1771
 *  net.minecraft.class_1776
 *  net.minecraft.class_1779
 *  net.minecraft.class_1787
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1812
 *  net.minecraft.class_1823
 *  net.minecraft.class_1835
 *  net.minecraft.class_1937
 *  net.minecraft.class_238
 *  net.minecraft.class_239
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_243
 *  net.minecraft.class_3959
 *  net.minecraft.class_3959$class_242
 *  net.minecraft.class_3959$class_3960
 *  net.minecraft.class_3965
 *  net.minecraft.class_3966
 */
package com.vengeance.vengeanceclient.r.q.u;

import com.vengeance.vengeanceclient.r.r.ze;
import com.vengeance.vengeanceclient.r.zb;
import com.vengeance.vengeanceclient.utils.w.zr;
import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1536;
import net.minecraft.class_1667;
import net.minecraft.class_1675;
import net.minecraft.class_1679;
import net.minecraft.class_1680;
import net.minecraft.class_1681;
import net.minecraft.class_1683;
import net.minecraft.class_1684;
import net.minecraft.class_1685;
import net.minecraft.class_1686;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1771;
import net.minecraft.class_1776;
import net.minecraft.class_1779;
import net.minecraft.class_1787;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1812;
import net.minecraft.class_1823;
import net.minecraft.class_1835;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

public final class zq
extends zb {
    private final com.vengeance.vengeanceclient.r.r.za b = new com.vengeance.vengeanceclient.r.r.za("Show Landing Point", true);
    private final com.vengeance.vengeanceclient.r.r.za c = new com.vengeance.vengeanceclient.r.r.za("Track Thrown", true);
    private final ze d = new ze("Track Duration (s)", 1.0, 10.0, 3.0, 0.5);
    private final ze e = new ze("Line Width", 1.0, 5.0, 2.0, 0.5);
    private final ze f = new ze("Point Size", 2.0, 10.0, 5.0, 0.5);
    private final com.vengeance.vengeanceclient.r.r.zb g = new com.vengeance.vengeanceclient.r.r.zb("Line Color", new Color(255, 255, 255, 200), true);
    private final com.vengeance.vengeanceclient.r.r.zb h = new com.vengeance.vengeanceclient.r.r.zb("Hit Color", new Color(255, 50, 50, 255), true);
    private final com.vengeance.vengeanceclient.r.r.zb i = new com.vengeance.vengeanceclient.r.r.zb("Thrown Color", new Color(100, 200, 255, 200), true);
    private final ze j = new ze("Max Points", 50.0, 500.0, 200.0, 10.0);
    private final Map<class_1297, za> k = new HashMap<class_1297, za>();

    public zq() {
        super("Trajectories", "Shows projectile trajectory path", -1, com.vengeance.vengeanceclient.r.za.d);
        this.a(this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j);
    }

    @EventHandler
    private void onRender2D(com.vengeance.vengeanceclient.p.p.t.za za2) {
        Object object;
        if (this.d() || zq.a.field_1724 == null || zq.a.field_1687 == null) {
            return;
        }
        if (this.c.b()) {
            this.n();
        } else {
            this.k.clear();
        }
        if (!com.vengeance.vengeanceclient.utils.w.r.za.c()) {
            return;
        }
        class_1799 class_17992 = zq.a.field_1724.method_6047();
        if (this.b(class_17992) && this.a(class_17992) && !(object = this.c(class_17992)).isEmpty()) {
            this.a((List<class_243>)object, this.g.h(), false);
        }
        if (this.c.b()) {
            for (za za3 : this.k.values()) {
                if (za3.a.isEmpty()) continue;
                this.a(za3.a, this.i.h(), true);
            }
        }
        com.vengeance.vengeanceclient.utils.w.r.za.e();
    }

    private boolean a(class_1799 class_17992) {
        class_1792 class_17922 = class_17992.method_7909();
        if (class_17922 instanceof class_1753) {
            return zq.a.field_1724.method_6115() && zq.a.field_1724.method_6048() > 0;
        }
        if (class_17922 instanceof class_1764) {
            return class_1764.method_7781((class_1799)class_17992);
        }
        if (class_17922 instanceof class_1835) {
            return zq.a.field_1724.method_6115() && zq.a.field_1724.method_6048() > 0;
        }
        if (class_17922 instanceof class_1823 || class_17922 instanceof class_1771 || class_17922 instanceof class_1776 || class_17922 instanceof class_1779 || class_17922 instanceof class_1812) {
            return true;
        }
        if (class_17922 instanceof class_1787) {
            return zq.a.field_1724.method_6115();
        }
        return false;
    }

    private void n() {
        this.k.entrySet().removeIf(entry -> ((za)entry.getValue()).a(this.d.f()) || !((class_1297)entry.getKey()).method_5805() || ((class_1297)entry.getKey()).method_31481());
        for (Object object : zq.a.field_1687.method_18112()) {
            if (!this.a((class_1297)object) || this.k.containsKey(object) || ((class_1297)object).field_6012 >= 5 || !(object.method_5858((class_1297)zq.a.field_1724) < 100.0)) continue;
            this.k.put((class_1297)object, new za());
        }
        float f = a.method_61966().method_60637(true);
        for (Map.Entry entry2 : this.k.entrySet()) {
            class_1297 class_12972 = (class_1297)entry2.getKey();
            za za2 = (za)entry2.getValue();
            class_243 class_2432 = class_12972.method_30950(f);
            if (!za2.a.isEmpty() && !(za2.a.get(za2.a.size() - 1).method_1025(class_2432) > 0.01)) continue;
            za2.a.add(class_2432);
            if (za2.a.size() <= this.j.a()) continue;
            za2.a.remove(0);
        }
    }

    private boolean a(class_1297 class_12972) {
        return class_12972 instanceof class_1667 || class_12972 instanceof class_1679 || class_12972 instanceof class_1685 || class_12972 instanceof class_1680 || class_12972 instanceof class_1681 || class_12972 instanceof class_1684 || class_12972 instanceof class_1683 || class_12972 instanceof class_1686 || class_12972 instanceof class_1536;
    }

    private boolean b(class_1799 class_17992) {
        class_1792 class_17922 = class_17992.method_7909();
        return class_17922 instanceof class_1753 || class_17922 instanceof class_1764 || class_17922 instanceof class_1835 || class_17922 instanceof class_1823 || class_17922 instanceof class_1771 || class_17922 instanceof class_1776 || class_17922 instanceof class_1779 || class_17922 instanceof class_1812 || class_17922 instanceof class_1787;
    }

    private List<class_243> c(class_1799 class_17992) {
        ArrayList<class_243> arrayList = new ArrayList<class_243>();
        class_1792 class_17922 = class_17992.method_7909();
        class_243 class_2432 = zq.a.field_1724.method_33571();
        class_243 class_2433 = this.a(zq.a.field_1724.method_36455(), zq.a.field_1724.method_36454());
        float f = this.a(class_17922, class_17992);
        class_2433 = class_2433.method_1021((double)f);
        float f2 = this.a(class_17922);
        float f3 = this.b(class_17922);
        int n = this.j.a();
        for (int i = 0; i < n; ++i) {
            arrayList.add(class_2432);
            class_243 class_2434 = class_2432.method_1019(class_2433);
            class_239 class_2392 = this.a(class_2432, class_2434);
            if (class_2392 != null && class_2392.method_17783() != class_239.class_240.field_1333) {
                arrayList.add(class_2392.method_17784());
                break;
            }
            class_2432 = class_2434;
            if ((class_2433 = class_2433.method_1021((double)f3).method_1031(0.0, (double)(-f2), 0.0)).method_1027() < 0.001) break;
        }
        return arrayList;
    }

    private class_243 a(float f, float f2) {
        float f3 = f * ((float)Math.PI / 180);
        float f4 = -f2 * ((float)Math.PI / 180);
        float f5 = (float)Math.cos(f4);
        float f6 = (float)Math.sin(f4);
        float f7 = (float)Math.cos(f3);
        float f8 = (float)Math.sin(f3);
        return new class_243((double)(f6 * f7), (double)(-f8), (double)(f5 * f7));
    }

    private float a(class_1792 class_17922, class_1799 class_17992) {
        if (class_17922 instanceof class_1753) {
            int n = zq.a.field_1724.method_6048();
            float f = class_1753.method_7722((int)n);
            return f * 3.0f;
        }
        if (class_17922 instanceof class_1764) {
            return 3.15f;
        }
        if (class_17922 instanceof class_1835) {
            return 2.5f;
        }
        if (class_17922 instanceof class_1823 || class_17922 instanceof class_1771 || class_17922 instanceof class_1776) {
            return 1.5f;
        }
        if (class_17922 instanceof class_1779 || class_17922 instanceof class_1812) {
            return 1.0f;
        }
        if (class_17922 instanceof class_1787) {
            return 1.5f;
        }
        return 1.5f;
    }

    private float a(class_1792 class_17922) {
        if (class_17922 instanceof class_1753 || class_17922 instanceof class_1764 || class_17922 instanceof class_1835) {
            return 0.05f;
        }
        if (class_17922 instanceof class_1787) {
            return 0.04f;
        }
        return 0.03f;
    }

    private float b(class_1792 class_17922) {
        if (class_17922 instanceof class_1753 || class_17922 instanceof class_1764 || class_17922 instanceof class_1835) {
            return 0.99f;
        }
        return 0.99f;
    }

    private class_239 a(class_243 class_2432, class_243 class_2433) {
        double d;
        class_3965 class_39652 = zq.a.field_1687.method_17742(new class_3959(class_2432, class_2433, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, (class_1297)zq.a.field_1724));
        class_238 class_2383 = new class_238(class_2432, class_2433).method_1014(1.0);
        class_3966 class_39662 = class_1675.method_37226((class_1937)zq.a.field_1687, (class_1297)zq.a.field_1724, (class_243)class_2432, (class_243)class_2433, (class_238)class_2383, class_12972 -> !class_12972.method_7325() && class_12972 != zq.a.field_1724, (float)0.0f);
        if (class_39662 == null) {
            return class_39652;
        }
        if (class_39652 == null || class_39652.method_17783() == class_239.class_240.field_1333) {
            return class_39662;
        }
        double d2 = class_2432.method_1025(class_39662.method_17784());
        return d2 <= (d = class_2432.method_1025(class_39652.method_17784())) ? class_39662 : class_39652;
    }

    private void a(List<class_243> list, Color color, boolean bl) {
        class_243 class_2432;
        Object object;
        class_243 class_2433;
        if (list.size() < 2) {
            return;
        }
        float f = this.e.b();
        for (int i = 0; i < list.size() - 1; ++i) {
            class_2433 = list.get(i);
            object = list.get(i + 1);
            class_243 class_2434 = zr.a(class_2433);
            class_243 class_2435 = zr.a(object);
            if (class_2434 == null || class_2435 == null || !(class_2434.field_1350 >= 0.0) || !(class_2434.field_1350 < 1.0) || !(class_2435.field_1350 >= 0.0) || !(class_2435.field_1350 < 1.0)) continue;
            Color color2 = color;
            if (bl) {
                float f2 = (float)i / (float)list.size();
                color2 = new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)((float)color.getAlpha() * f2));
            }
            com.vengeance.vengeanceclient.utils.w.r.za.b((float)class_2434.field_1352, (float)class_2434.field_1351, (float)class_2435.field_1352, (float)class_2435.field_1351, f, color2);
        }
        if (this.b.b() && !bl && !list.isEmpty() && (class_2433 = zr.a(class_2432 = list.get(list.size() - 1))) != null && class_2433.field_1350 >= 0.0 && class_2433.field_1350 < 1.0) {
            object = this.h.h();
            float f3 = this.f.b();
            com.vengeance.vengeanceclient.utils.w.r.za.a((float)class_2433.field_1352, (float)class_2433.field_1351, f3 + 2.0f, new Color(0, 0, 0, 150));
            com.vengeance.vengeanceclient.utils.w.r.za.a((float)class_2433.field_1352, (float)class_2433.field_1351, f3, (Color)object);
        }
    }

    private static class za {
        final List<class_243> a = new ArrayList<class_243>();
        final long b = System.currentTimeMillis();

        private za() {
        }

        boolean a(double d) {
            return (double)(System.currentTimeMillis() - this.b) / 1000.0 > d;
        }
    }
}

