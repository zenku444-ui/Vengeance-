/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_304
 *  net.minecraft.class_310
 *  net.minecraft.class_3675$class_306
 */
package com.vengeance.vengeanceclient.utils.r.p;

import com.vengeance.vengeanceclient.VengeanceClient;
import com.vengeance.vengeanceclient.utils.r.p.zb;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;

public final class za {
    public static void a() {
        if (VengeanceClient.shouldUseMouseEvent) {
            zb.a.a(2, 0, 0, 0, 0);
            zb.a.a(4, 0, 0, 0, 0);
        } else {
            class_310 class_3102 = class_310.method_1551();
            class_304 class_3042 = class_3102.field_1690.field_1886;
            class_3675.class_306 class_3062 = class_3042.method_1429();
            class_304.method_1416((class_3675.class_306)class_3062, (boolean)true);
            class_304.method_1420((class_3675.class_306)class_3062);
            class_3102.execute(() -> class_304.method_1416((class_3675.class_306)class_3062, (boolean)false));
        }
    }

    private za() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}

