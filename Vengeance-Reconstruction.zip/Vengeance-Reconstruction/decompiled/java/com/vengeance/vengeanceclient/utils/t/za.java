/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_124
 *  net.minecraft.class_2561
 *  net.minecraft.class_2583
 *  net.minecraft.class_5250
 *  net.minecraft.class_5251
 */
package com.vengeance.vengeanceclient.utils.t;

import com.vengeance.vengeanceclient.VengeanceClient;
import com.vengeance.vengeanceclient.utils.zb;
import java.awt.Color;
import java.util.Objects;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_5250;
import net.minecraft.class_5251;

public final class za
implements zb {
    private static final class_5250 a = class_2561.method_43473().method_10862(class_2583.field_24360.method_27706(class_124.field_1080));

    public static void a(String string) {
        za.a((class_2561)class_2561.method_43470((String)string));
    }

    public static void a(class_2561 class_25612) {
        za.a(class_25612.method_27661().method_54663(za.a.a()), true);
    }

    public static void b(String string) {
        za.b((class_2561)class_2561.method_43470((String)string));
    }

    public static void b(class_2561 class_25612) {
        if (Objects.isNull(za.w.field_1705)) {
            VengeanceClient.INSTANCE.getLogger().warn(class_25612.getString());
            return;
        }
        za.a(class_25612.method_27661().method_54663(za.b.a()), true);
    }

    public static void c(String string) {
        za.c((class_2561)class_2561.method_43470((String)string));
    }

    public static void c(class_2561 class_25612) {
        if (Objects.isNull(za.w.field_1705)) {
            VengeanceClient.INSTANCE.getLogger().error(class_25612.getString());
            return;
        }
        za.a(class_25612.method_27661().method_54663(za.c.a()), true);
    }

    public static void a(boolean bl) {
        za.a(class_2561.method_43470((String)" "), bl);
    }

    public static void d(String string) {
        za.a(class_2561.method_43470((String)string));
    }

    public static void a(class_5250 class_52502) {
        za.a(class_52502, true);
    }

    public static void a(String string, boolean bl) {
        za.a(class_2561.method_43470((String)string), bl);
    }

    public static void a(class_5250 class_52502, boolean bl) {
        if (Objects.isNull(za.w.field_1705)) {
            VengeanceClient.INSTANCE.getLogger().info(class_52502.getString());
            return;
        }
        class_5250 class_52503 = bl ? za.a().method_27661().method_10852((class_2561)class_52502) : class_52502;
        za.w.field_1705.method_1743().method_1812((class_2561)class_52503);
    }

    public static void e(String string) {
        if (za.w.field_1724 == null || za.w.field_1687 == null || Objects.isNull(za.w.field_1705) || za.w.field_1705.method_1743() == null) {
            VengeanceClient.INSTANCE.getLogger().info("[Vengeance Client] " + string);
            return;
        }
        za.w.field_1705.method_1743().method_1812(class_2561.method_30163((String)string));
    }

    public static class_5250 a(String string, class_2583 class_25832, Color color, Color color2) {
        class_5250 class_52502 = class_2561.method_43473();
        for (int i = 0; i < string.length(); ++i) {
            float f = (float)i / (float)(string.length() - 1);
            Color color3 = com.vengeance.vengeanceclient.utils.w.zb.a(color, color2, f);
            class_52502.method_10852((class_2561)class_2561.method_43470((String)String.valueOf(string.charAt(i))).method_10862(class_25832.method_27703(class_5251.method_27717((int)color3.getRGB()))));
        }
        return class_52502;
    }

    public static class_5250 a() {
        return a.method_27661().method_27693("[").method_10852((class_2561)za.a("vengeance-client", class_2583.field_24360, new Color(0, 191, 255), new Color(0, 255, 127))).method_27693("]").method_27693(" ");
    }

    private za() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    public static final class za
    extends Enum<za> {
        public static final /* enum */ za a = new za(Color.GREEN);
        public static final /* enum */ za b = new za(Color.ORANGE);
        public static final /* enum */ za c = new za(Color.RED);
        private final int d;
        private final String e;
        private static final /* synthetic */ za[] f;

        public static za[] values() {
            return (za[])f.clone();
        }

        public static za valueOf(String string) {
            return Enum.valueOf(za.class, string);
        }

        private za(Color color) {
            this.d = color.getRGB();
            this.e = com.vengeance.vengeanceclient.utils.v.za.a(this.name());
        }

        public int a() {
            return this.d;
        }

        public String b() {
            return this.e;
        }

        private static /* synthetic */ za[] c() {
            return new za[]{a, b, c};
        }

        static {
            f = za.c();
        }
    }
}

