/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1657
 *  net.minecraft.class_243
 */
package com.vengeance.vengeanceclient.utils.t;

import net.minecraft.class_1657;
import net.minecraft.class_243;

public final class zb
implements com.vengeance.vengeanceclient.utils.zb {
    public static boolean a(class_1657 class_16572) {
        if (zb.w.field_1724 == null || class_16572 == null) {
            return false;
        }
        class_243 class_2432 = zb.w.field_1724.method_33571();
        class_243 class_2433 = class_16572.method_73189();
        class_243 class_2434 = class_2432.method_1020(class_2433);
        class_243 class_2435 = new class_243(class_2434.field_1352, 0.0, class_2434.field_1350);
        if (class_2435.method_1027() == 0.0) {
            return false;
        }
        class_2435 = class_2435.method_1029();
        double d = Math.toRadians(class_16572.method_36454());
        double d2 = Math.toRadians(class_16572.method_36455());
        class_243 class_2436 = new class_243(-Math.sin(d) * Math.cos(d2), -Math.sin(d2), Math.cos(d) * Math.cos(d2)).method_1029();
        double d3 = class_2436.method_1026(class_2435);
        return d3 < 0.0;
    }
}

