/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1799
 *  net.minecraft.class_1887
 *  net.minecraft.class_1937
 *  net.minecraft.class_2378
 *  net.minecraft.class_5321
 *  net.minecraft.class_6880
 *  net.minecraft.class_7924
 *  net.minecraft.class_9304
 *  net.minecraft.class_9334
 */
package com.vengeance.vengeanceclient.utils.t;

import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1937;
import net.minecraft.class_2378;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

public final class zc {
    public static boolean a(class_1799 class_17992, class_1937 class_19372, class_6880<class_1887> class_68802) {
        if (class_17992 == null || class_19372 == null || class_68802 == null) {
            return false;
        }
        class_9304 class_93042 = (class_9304)class_17992.method_58694(class_9334.field_49633);
        if (class_93042 == null) {
            return false;
        }
        return class_93042.method_57536(class_68802) > 0;
    }

    public static boolean a(class_1799 class_17992, class_1937 class_19372, class_1887 class_18872) {
        Object object;
        class_2378 class_23782;
        if (class_17992 == null || class_19372 == null || class_18872 == null) {
            return false;
        }
        class_9304 class_93042 = (class_9304)class_17992.method_58694(class_9334.field_49633);
        if (class_93042 == null) {
            return false;
        }
        try {
            class_23782 = class_19372.method_30349().method_30530(class_7924.field_41265);
            object = class_23782.method_47983((Object)class_18872);
            if (object != null) {
                return class_93042.method_57536((class_6880)object) > 0;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        try {
            class_23782 = (class_2378)class_19372.method_30349().getClass().getMethod("get", class_5321.class).invoke((Object)class_19372.method_30349(), class_7924.field_41265);
            object = class_23782.getClass().getMethod("getEntry", Object.class).invoke((Object)class_23782, class_18872);
            Integer n = (Integer)class_93042.getClass().getMethod("getLevel", object.getClass()).invoke((Object)class_93042, object);
            return n != null && n > 0;
        }
        catch (Throwable throwable) {
            try {
                Integer n = (Integer)class_93042.getClass().getMethod("getLevel", class_1887.class).invoke((Object)class_93042, class_18872);
                return n != null && n > 0;
            }
            catch (Throwable throwable2) {
                return false;
            }
        }
    }

    public static boolean a(class_1799 class_17992, class_1937 class_19372, class_5321<class_1887> class_53212) {
        Object object;
        Object object2;
        Object object3;
        if (class_17992 == null || class_19372 == null || class_53212 == null) {
            return false;
        }
        class_9304 class_93042 = (class_9304)class_17992.method_58694(class_9334.field_49633);
        if (class_93042 == null) {
            return false;
        }
        try {
            object3 = class_19372.method_30349().method_30530(class_7924.field_41265);
            object2 = (class_1887)object3.method_29107(class_53212);
            if (object2 != null && (object = object3.method_47983(object2)) != null) {
                return class_93042.method_57536((class_6880)object) > 0;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        try {
            object3 = class_19372.method_30349().getClass().getMethod("get", class_5321.class).invoke((Object)class_19372.method_30349(), class_7924.field_41265);
            object2 = object3.getClass().getMethod("getOrEmpty", class_5321.class).invoke(object3, class_53212);
            object = (Optional)object2;
            if (((Optional)object).isPresent()) {
                Object t = ((Optional)object).get();
                Object object4 = object3.getClass().getMethod("getEntry", Object.class).invoke(object3, t);
                return zc.a(class_17992, class_19372, (class_6880<class_1887>)((class_6880)object4));
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return false;
    }
}

