/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_3489
 */
package com.vengeance.vengeanceclient.utils.t;

import com.vengeance.vengeanceclient.utils.zb;
import java.util.Objects;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_3489;

public final class zd
implements zb {
    private static final int b = 9;

    public static void a(class_1792 class_17922) {
        for (int n = 0; n < 9; n = (int)((byte)(n + 1))) {
            assert (zd.w.field_1724 != null);
            class_1799 class_17992 = zd.w.field_1724.method_31548().method_5438(n);
            if (class_17992.method_7960() || !class_17992.method_7909().equals(class_17922)) continue;
            zd.w.field_1724.method_31548().method_61496(n);
            return;
        }
    }

    public static boolean b(class_1792 class_17922) {
        for (int n = 0; n < Objects.requireNonNull(zd.w.field_1724).method_31548().method_5439(); n = (int)((byte)(n + 1))) {
            class_1799 class_17992 = zd.w.field_1724.method_31548().method_5438(n);
            if (class_17992.method_7909() != class_17922) continue;
            return true;
        }
        return false;
    }

    public static boolean a(Class<? extends class_1792> clazz) {
        for (int n = 0; n < 9; n = (int)((byte)(n + 1))) {
            class_1799 class_17992 = zd.w.field_1724.method_31548().method_5438(n);
            if (!clazz.isInstance(class_17992.method_7909())) continue;
            return true;
        }
        return false;
    }

    public static void b(Class<? extends class_1792> clazz) {
        for (int n = 0; n < 9; n = (int)((byte)(n + 1))) {
            class_1799 class_17992 = zd.w.field_1724.method_31548().method_5438(n);
            if (!clazz.isInstance(class_17992.method_7909())) continue;
            zd.w.field_1724.method_31548().method_61496(n);
            break;
        }
    }

    public static boolean a() {
        for (int n = 0; n < 9; n = (int)((byte)(n + 1))) {
            class_1799 class_17992 = zd.w.field_1724.method_31548().method_5438(n);
            if (!class_17992.method_31573(class_3489.field_42611)) continue;
            return true;
        }
        return false;
    }

    public static void b() {
        for (int n = 0; n < 9; n = (int)((byte)(n + 1))) {
            class_1799 class_17992 = zd.w.field_1724.method_31548().method_5438(n);
            if (!class_17992.method_31573(class_3489.field_42611)) continue;
            zd.w.field_1724.method_31548().method_61496(n);
            break;
        }
    }

    private zd() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}

