/*
 * Decompiled with CFR 0.152.
 */
package com.vengeance.vengeanceclient.utils.t;

import com.vengeance.vengeanceclient.VengeanceClient;

public final class ze {
    public static boolean a() {
        return VengeanceClient.mc.field_1690.field_1894.method_1434() || VengeanceClient.mc.field_1690.field_1881.method_1434() || VengeanceClient.mc.field_1690.field_1913.method_1434() || VengeanceClient.mc.field_1690.field_1849.method_1434();
    }

    private ze() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}

