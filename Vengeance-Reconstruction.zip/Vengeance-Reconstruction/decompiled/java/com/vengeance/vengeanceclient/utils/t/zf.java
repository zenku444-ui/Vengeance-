/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_2338
 *  net.minecraft.class_243
 *  net.minecraft.class_3959
 *  net.minecraft.class_3959$class_242
 *  net.minecraft.class_3959$class_3960
 *  net.minecraft.class_3965
 */
package com.vengeance.vengeanceclient.utils.t;

import com.vengeance.vengeanceclient.utils.zb;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

public final class zf
implements zb {
    public static boolean a(class_2338 class_23382, double d) {
        class_243 class_2432;
        class_243 class_2433;
        if (zf.w.field_1724 == null || zf.w.field_1687 == null) {
            return false;
        }
        class_243 class_2434 = zf.w.field_1724.method_5836(1.0f);
        class_3965 class_39652 = zf.w.field_1687.method_17742(new class_3959(class_2434, class_2433 = class_2434.method_1019((class_2432 = zf.w.field_1724.method_5828(1.0f)).method_1021(d)), class_3959.class_3960.field_17559, class_3959.class_242.field_1348, (class_1297)zf.w.field_1724));
        return class_39652 != null && class_39652.method_17777().equals((Object)class_23382);
    }

    private zf() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}

