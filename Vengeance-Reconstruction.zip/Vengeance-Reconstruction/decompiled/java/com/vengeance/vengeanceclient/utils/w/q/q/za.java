/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.VertexFormat$class_5596
 *  net.minecraft.class_12249
 *  net.minecraft.class_1921
 *  net.minecraft.class_287
 *  net.minecraft.class_9801
 */
package com.vengeance.vengeanceclient.utils.w.q.q;

import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.class_12249;
import net.minecraft.class_1921;
import net.minecraft.class_287;
import net.minecraft.class_9801;

public final class za {
    private za() {
    }

    public static void a(class_287 class_2872) {
        try (class_9801 class_98012 = class_2872.method_60800();){
            try {
                za.a(class_98012.method_60822().comp_752()).method_60895(class_98012);
            }
            catch (Throwable throwable) {
                try {
                    Class<?> clazz = Class.forName("net.minecraft.client.render.BufferRenderer");
                    clazz.getMethod("drawWithGlobalProgram", class_9801.class).invoke(null, class_98012);
                }
                catch (Throwable throwable2) {
                    // empty catch block
                }
            }
        }
    }

    public static void a(class_287 class_2872, class_1921 class_19212) {
        try (class_9801 class_98012 = class_2872.method_60800();){
            class_19212.method_60895(class_98012);
        }
    }

    private static class_1921 a(VertexFormat.class_5596 class_55962) {
        return switch (class_55962) {
            case VertexFormat.class_5596.field_29344 -> class_12249.method_76668();
            case VertexFormat.class_5596.field_27379 -> class_12249.method_76019();
            case VertexFormat.class_5596.field_27381 -> class_12249.method_76025();
            case VertexFormat.class_5596.field_27382 -> class_12249.method_76023();
            default -> class_12249.method_76023();
        };
    }
}

