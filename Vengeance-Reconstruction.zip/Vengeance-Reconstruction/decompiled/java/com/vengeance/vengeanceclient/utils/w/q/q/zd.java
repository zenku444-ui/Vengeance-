/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.opengl.GlStateManager
 *  net.minecraft.class_1011
 *  net.minecraft.class_1043
 *  net.minecraft.class_1044
 *  net.minecraft.class_243
 *  net.minecraft.class_2960
 *  net.minecraft.class_310
 *  net.minecraft.class_3532
 *  net.minecraft.class_4184
 *  net.minecraft.class_4587
 *  org.jetbrains.annotations.ApiStatus$Internal
 *  org.jetbrains.annotations.Contract
 *  org.joml.Matrix4f
 *  org.joml.Matrix4fc
 *  org.joml.Vector3f
 *  org.joml.Vector4f
 *  org.lwjgl.BufferUtils
 *  org.lwjgl.opengl.GL11
 */
package com.vengeance.vengeanceclient.utils.w.q.q;

import com.mojang.blaze3d.opengl.GlStateManager;
import com.vengeance.vengeanceclient.utils.w.q.q.zc;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import javax.imageio.ImageIO;
import lombok.NonNull;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1044;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Contract;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;

public class zd {
    @ApiStatus.Internal
    public static final Matrix4f a = new Matrix4f();
    @ApiStatus.Internal
    public static final Matrix4f b = new Matrix4f();
    @ApiStatus.Internal
    public static final Matrix4f c = new Matrix4f();
    private static final zc d = new zc();
    private static final class_310 e = class_310.method_1551();
    private static final char f = 'a';
    private static final char g = 'z';
    private static final Random h = new Random();

    public static void a() {
        GlStateManager._disableCull();
        GlStateManager._enableBlend();
        GlStateManager._blendFuncSeparate((int)770, (int)771, (int)1, (int)771);
    }

    public static void b() {
        GlStateManager._disableBlend();
        GlStateManager._enableCull();
        GlStateManager._depthFunc((int)515);
    }

    public static int a(int n, int n2, double d) {
        return (int)Math.floor((double)n + (double)(n2 - n) * class_3532.method_15350((double)d, (double)0.0, (double)1.0));
    }

    public static double a(double d, double d2, double d3) {
        return d + (d2 - d) * class_3532.method_15350((double)d3, (double)0.0, (double)1.0);
    }

    @Contract(value="_, _, _ -> new", pure=true)
    public static Color a(@NonNull Color color, @NonNull Color color2, double d) {
        if (color == null) {
            throw new NullPointerException("a is marked non-null but is null");
        }
        if (color2 == null) {
            throw new NullPointerException("b is marked non-null but is null");
        }
        return new Color(zd.a(color.getRed(), color2.getRed(), d), zd.a(color.getGreen(), color2.getGreen(), d), zd.a(color.getBlue(), color2.getBlue(), d), zd.a(color.getAlpha(), color2.getAlpha(), d));
    }

    @Contract(value="_, _, _, _, _ -> new", pure=true)
    public static Color a(@NonNull Color color, int n, int n2, int n3, int n4) {
        if (color == null) {
            throw new NullPointerException("original is marked non-null but is null");
        }
        return new Color(n == -1 ? color.getRed() : n, n2 == -1 ? color.getGreen() : n2, n3 == -1 ? color.getBlue() : n3, n4 == -1 ? color.getAlpha() : n4);
    }

    @Contract(value="_, _ -> new", pure=true)
    public static class_243 a(@NonNull class_4587 class_45872, @NonNull class_243 class_2432) {
        if (class_45872 == null) {
            throw new NullPointerException("stack is marked non-null but is null");
        }
        if (class_2432 == null) {
            throw new NullPointerException("in is marked non-null but is null");
        }
        Matrix4f matrix4f = class_45872.method_23760().method_23761();
        Vector4f vector4f = new Vector4f((float)class_2432.field_1352, (float)class_2432.field_1351, (float)class_2432.field_1350, 1.0f);
        vector4f.mul((Matrix4fc)matrix4f);
        return new class_243((double)vector4f.x(), (double)vector4f.y(), (double)vector4f.z());
    }

    public static void a(@NonNull class_2960 class_29602, @NonNull BufferedImage bufferedImage) {
        if (class_29602 == null) {
            throw new NullPointerException("i is marked non-null but is null");
        }
        if (bufferedImage == null) {
            throw new NullPointerException("bi is marked non-null but is null");
        }
        try {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            ImageIO.write((RenderedImage)bufferedImage, "png", byteArrayOutputStream);
            byte[] byArray = byteArrayOutputStream.toByteArray();
            ByteBuffer byteBuffer = BufferUtils.createByteBuffer((int)byArray.length).put(byArray);
            byteBuffer.flip();
            class_1043 class_10432 = new class_1043(zd::g, class_1011.method_4324((ByteBuffer)byteBuffer));
            class_310.method_1551().execute(() -> class_310.method_1551().method_1531().method_4616(class_29602, (class_1044)class_10432));
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public static class_4587 c() {
        if (!d.method_67795()) {
            throw new IllegalStateException("Supposed \"empty\" stack is not actually empty; someone does not clean up after themselves.");
        }
        d.method_34426();
        return d;
    }

    @Contract(value="-> new")
    public static class_243 d() {
        class_4184 class_41842 = zd.e.field_1773.method_19418();
        float f = (float)Math.PI;
        float f2 = (float)Math.toRadians(-class_41842.method_19330());
        float f3 = (float)Math.toRadians(-class_41842.method_19329());
        float f4 = class_3532.method_15362((double)(f2 - f));
        float f5 = class_3532.method_15374((double)(f2 - f));
        float f6 = -class_3532.method_15362((double)f3);
        float f7 = class_3532.method_15374((double)f3);
        return new class_243((double)(f5 * f6), (double)f7, (double)(f4 * f6)).method_1019(class_41842.method_71156());
    }

    @Contract(value="_ -> new", pure=true)
    public static class_243 a(@NonNull class_243 class_2432) {
        if (class_2432 == null) {
            throw new NullPointerException("pos is marked non-null but is null");
        }
        class_4184 class_41842 = zd.e.method_1561().field_4686;
        int n = e.method_22683().method_4506();
        int[] nArray = new int[4];
        GL11.glGetIntegerv((int)2978, (int[])nArray);
        Vector3f vector3f = new Vector3f();
        double d = class_2432.field_1352 - class_41842.method_71156().field_1352;
        double d2 = class_2432.field_1351 - class_41842.method_71156().field_1351;
        double d3 = class_2432.field_1350 - class_41842.method_71156().field_1350;
        Vector4f vector4f = new Vector4f((float)d, (float)d2, (float)d3, 1.0f).mul((Matrix4fc)c);
        Matrix4f matrix4f = new Matrix4f((Matrix4fc)a);
        Matrix4f matrix4f2 = new Matrix4f((Matrix4fc)b);
        matrix4f.mul((Matrix4fc)matrix4f2).project(vector4f.x(), vector4f.y(), vector4f.z(), nArray, vector3f);
        return new class_243((double)(vector3f.x / (float)e.method_22683().method_4495()), (double)(((float)n - vector3f.y) / (float)e.method_22683().method_4495()), (double)vector3f.z);
    }

    public static boolean b(class_243 class_2432) {
        return class_2432 != null && class_2432.field_1350 > -1.0 && class_2432.field_1350 < 1.0;
    }

    @Contract(value="_,_,_ -> new", pure=true)
    public static class_243 b(double d, double d2, double d3) {
        class_4184 class_41842 = zd.e.method_1561().field_4686;
        int n = e.method_22683().method_4502();
        int n2 = e.method_22683().method_4486();
        int[] nArray = new int[4];
        GL11.glGetIntegerv((int)2978, (int[])nArray);
        Vector3f vector3f = new Vector3f();
        Matrix4f matrix4f = new Matrix4f((Matrix4fc)a);
        Matrix4f matrix4f2 = new Matrix4f((Matrix4fc)b);
        matrix4f.mul((Matrix4fc)matrix4f2).mul((Matrix4fc)c).unproject((float)d / (float)n2 * (float)nArray[2], (float)((double)n - d2) / (float)n * (float)nArray[3], (float)d3, nArray, vector3f);
        return new class_243((double)vector3f.x, (double)vector3f.y, (double)vector3f.z).method_1019(class_41842.method_71156());
    }

    public static int e() {
        return class_310.method_1551().method_22683().method_4495();
    }

    private static String g() {
        return IntStream.range(0, 32).mapToObj(n -> String.valueOf((char)h.nextInt(97, 123))).collect(Collectors.joining());
    }

    @Contract(value="-> new", pure=true)
    public static class_2960 f() {
        return class_2960.method_60655((String)"renderer", (String)("temp/" + zd.g()));
    }
}

