/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2960
 */
package com.vengeance.vengeanceclient.utils.w.s;

import net.minecraft.class_2960;

public final class zd {
    public static class_2960 a(String string) {
        return class_2960.method_60655((String)"vengeance-client", (String)("core/" + string));
    }
}

