/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_4587
 *  net.minecraft.class_4597
 *  net.minecraft.class_898
 */
package com.vengeance.vengeanceclient.utils.w;

import net.minecraft.class_1297;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_898;

public final class zc {
    private zc() {
    }

    public static void a(class_898 class_8982, class_1297 class_12972, double d, double d2, double d3, float f, float f2, class_4587 class_45872, class_4597 class_45972, int n) {
        try {
            class_8982.getClass().getMethod("render", class_1297.class, Double.TYPE, Double.TYPE, Double.TYPE, Float.TYPE, class_4587.class, class_4597.class, Integer.TYPE).invoke((Object)class_8982, class_12972, d, d2, d3, Float.valueOf(f), class_45872, class_45972, n);
            return;
        }
        catch (NoSuchMethodException noSuchMethodException) {
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        try {
            class_8982.getClass().getMethod("render", class_1297.class, Double.TYPE, Double.TYPE, Double.TYPE, Float.TYPE, Float.TYPE, class_4587.class, class_4597.class, Integer.TYPE).invoke((Object)class_8982, class_12972, d, d2, d3, Float.valueOf(f), Float.valueOf(f2), class_45872, class_45972, n);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }
}

