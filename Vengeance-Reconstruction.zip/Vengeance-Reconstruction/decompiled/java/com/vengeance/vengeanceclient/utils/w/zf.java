/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.VertexFormat$class_5596
 *  net.minecraft.class_287
 *  net.minecraft.class_289
 *  net.minecraft.class_290
 *  net.minecraft.class_4587
 *  org.joml.Matrix4f
 *  org.joml.Matrix4fc
 */
package com.vengeance.vengeanceclient.utils.w;

import com.mojang.blaze3d.vertex.VertexFormat;
import com.vengeance.vengeanceclient.utils.w.q.q.za;
import com.vengeance.vengeanceclient.utils.w.zd;
import java.awt.Color;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_4587;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;

public class zf {
    public static void a(class_4587 class_45872, float f, float f2, float f3, float f4, Color color) {
        Matrix4f matrix4f = class_45872.method_23760().method_23761();
        zf.a();
        zd.a();
        class_287 class_2872 = class_289.method_1348().method_60827(VertexFormat.class_5596.field_27382, class_290.field_1576);
        class_2872.method_22918((Matrix4fc)matrix4f, f, f4, 0.0f).method_39415(color.getRGB());
        class_2872.method_22918((Matrix4fc)matrix4f, f3, f4, 0.0f).method_39415(color.getRGB());
        class_2872.method_22918((Matrix4fc)matrix4f, f3, f2, 0.0f).method_39415(color.getRGB());
        class_2872.method_22918((Matrix4fc)matrix4f, f, f2, 0.0f).method_39415(color.getRGB());
        za.a(class_2872);
        zf.b();
    }

    public static void a(class_4587 class_45872, float f, float f2, float f3, float f4, Color color, Color color2) {
        Matrix4f matrix4f = class_45872.method_23760().method_23761();
        zf.a();
        zd.a();
        class_287 class_2872 = class_289.method_1348().method_60827(VertexFormat.class_5596.field_27382, class_290.field_1576);
        class_2872.method_22918((Matrix4fc)matrix4f, f, f4, 0.0f).method_39415(color.getRGB());
        class_2872.method_22918((Matrix4fc)matrix4f, f3, f4, 0.0f).method_39415(color.getRGB());
        class_2872.method_22918((Matrix4fc)matrix4f, f3, f2, 0.0f).method_39415(color.getRGB());
        class_2872.method_22918((Matrix4fc)matrix4f, f, f2, 0.0f).method_39415(color.getRGB());
        za.a(class_2872);
        class_2872 = class_289.method_1348().method_60827(VertexFormat.class_5596.field_29345, class_290.field_1576);
        class_2872.method_22918((Matrix4fc)matrix4f, f, f4, 0.0f).method_39415(color2.getRGB());
        class_2872.method_22918((Matrix4fc)matrix4f, f3, f4, 0.0f).method_39415(color2.getRGB());
        class_2872.method_22918((Matrix4fc)matrix4f, f3, f2, 0.0f).method_39415(color2.getRGB());
        class_2872.method_22918((Matrix4fc)matrix4f, f, f2, 0.0f).method_39415(color2.getRGB());
        class_2872.method_22918((Matrix4fc)matrix4f, f, f4, 0.0f).method_39415(color2.getRGB());
        za.a(class_2872);
        zf.b();
    }

    public static void b(class_4587 class_45872, float f, float f2, float f3, float f4, Color color, Color color2) {
        Matrix4f matrix4f = class_45872.method_23760().method_23761();
        zf.a();
        zd.a();
        class_287 class_2872 = class_289.method_1348().method_60827(VertexFormat.class_5596.field_27382, class_290.field_1576);
        class_2872.method_22918((Matrix4fc)matrix4f, f, f2, 0.0f).method_39415(color.getRGB());
        class_2872.method_22918((Matrix4fc)matrix4f, f, f4, 0.0f).method_39415(color.getRGB());
        class_2872.method_22918((Matrix4fc)matrix4f, f3, f4, 0.0f).method_39415(color2.getRGB());
        class_2872.method_22918((Matrix4fc)matrix4f, f3, f2, 0.0f).method_39415(color2.getRGB());
        za.a(class_2872);
        zf.b();
    }

    public static void a() {
    }

    public static void b() {
    }

    public static void a(class_287 class_2872, Matrix4f matrix4f, float f, float f2, float f3, float f4, Color color, Color color2) {
        zf.a(class_2872, matrix4f, f, f2, f3, f4, color, color, color2, color2);
    }

    public static void b(class_287 class_2872, Matrix4f matrix4f, float f, float f2, float f3, float f4, Color color, Color color2) {
        zf.a(class_2872, matrix4f, f, f2, f3, f4, color, color2, color2, color);
    }

    public static void a(class_287 class_2872, Matrix4f matrix4f, float f, float f2, float f3, float f4, Color color) {
        zf.a(class_2872, matrix4f, f, f2, f3, f4, color, color, color, color);
    }

    public static void a(class_287 class_2872, Matrix4f matrix4f, float f, float f2, float f3, float f4, Color color, Color color2, Color color3, Color color4) {
        class_2872.method_22918((Matrix4fc)matrix4f, f3, f2, 0.0f).method_39415(color2.getRGB());
        class_2872.method_22918((Matrix4fc)matrix4f, f, f2, 0.0f).method_39415(color.getRGB());
        class_2872.method_22918((Matrix4fc)matrix4f, f, f4, 0.0f).method_39415(color4.getRGB());
        class_2872.method_22918((Matrix4fc)matrix4f, f3, f4, 0.0f).method_39415(color3.getRGB());
    }
}

