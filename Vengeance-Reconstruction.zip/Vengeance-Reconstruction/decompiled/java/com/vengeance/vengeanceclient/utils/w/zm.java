/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.opengl.GlStateManager
 *  com.mojang.blaze3d.vertex.VertexFormat$class_5596
 *  net.minecraft.class_1297
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_287
 *  net.minecraft.class_289
 *  net.minecraft.class_290
 *  net.minecraft.class_4587
 *  org.joml.Matrix4f
 *  org.joml.Matrix4fc
 */
package com.vengeance.vengeanceclient.utils.w;

import com.mojang.blaze3d.opengl.GlStateManager;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.vengeance.vengeanceclient.utils.w.q.q.za;
import com.vengeance.vengeanceclient.utils.w.zd;
import java.awt.Color;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_4587;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;

public final class zm {
    private zm() {
    }

    public static void a() {
        GlStateManager._enableBlend();
        GlStateManager._blendFuncSeparate((int)770, (int)771, (int)1, (int)771);
        GlStateManager._disableCull();
        zd.a();
    }

    public static void b() {
        zm.a();
        GlStateManager._disableDepthTest();
    }

    public static void c() {
        GlStateManager._enableCull();
        GlStateManager._enableDepthTest();
        GlStateManager._disableBlend();
    }

    public static void a(class_4587 class_45872, class_238 class_2383, Color color) {
        zm.c(class_45872, class_2383, color);
    }

    public static void a(class_4587 class_45872, double d, double d2, double d3, float f, float f2, Color color) {
        float f3 = f / 2.0f;
        class_238 class_2383 = new class_238(d - (double)f3, d2, d3 - (double)f3, d + (double)f3, d2 + (double)f2, d3 + (double)f3);
        zm.c(class_45872, class_2383, color);
    }

    public static void b(class_4587 class_45872, class_238 class_2383, Color color) {
        Matrix4f matrix4f = class_45872.method_23760().method_23761();
        class_287 class_2872 = class_289.method_1348().method_60827(VertexFormat.class_5596.field_29344, class_290.field_1576);
        float f = (float)color.getRed() / 255.0f;
        float f2 = (float)color.getGreen() / 255.0f;
        float f3 = (float)color.getBlue() / 255.0f;
        float f4 = (float)color.getAlpha() / 255.0f;
        float f5 = (float)class_2383.field_1323;
        float f6 = (float)class_2383.field_1322;
        float f7 = (float)class_2383.field_1321;
        float f8 = (float)class_2383.field_1320;
        float f9 = (float)class_2383.field_1325;
        float f10 = (float)class_2383.field_1324;
        zm.a(class_2872, matrix4f, f5, f6, f7, f8, f6, f7, f, f2, f3, f4);
        zm.a(class_2872, matrix4f, f8, f6, f7, f8, f6, f10, f, f2, f3, f4);
        zm.a(class_2872, matrix4f, f8, f6, f10, f5, f6, f10, f, f2, f3, f4);
        zm.a(class_2872, matrix4f, f5, f6, f10, f5, f6, f7, f, f2, f3, f4);
        zm.a(class_2872, matrix4f, f5, f9, f7, f8, f9, f7, f, f2, f3, f4);
        zm.a(class_2872, matrix4f, f8, f9, f7, f8, f9, f10, f, f2, f3, f4);
        zm.a(class_2872, matrix4f, f8, f9, f10, f5, f9, f10, f, f2, f3, f4);
        zm.a(class_2872, matrix4f, f5, f9, f10, f5, f9, f7, f, f2, f3, f4);
        zm.a(class_2872, matrix4f, f5, f6, f7, f5, f9, f7, f, f2, f3, f4);
        zm.a(class_2872, matrix4f, f8, f6, f7, f8, f9, f7, f, f2, f3, f4);
        zm.a(class_2872, matrix4f, f8, f6, f10, f8, f9, f10, f, f2, f3, f4);
        zm.a(class_2872, matrix4f, f5, f6, f10, f5, f9, f10, f, f2, f3, f4);
        za.a(class_2872);
    }

    public static void b(class_4587 class_45872, double d, double d2, double d3, float f, float f2, Color color) {
        float f3 = f / 2.0f;
        class_238 class_2383 = new class_238(d - (double)f3, d2, d3 - (double)f3, d + (double)f3, d2 + (double)f2, d3 + (double)f3);
        zm.b(class_45872, class_2383, color);
    }

    public static void c(class_4587 class_45872, class_238 class_2383, Color color) {
        Matrix4f matrix4f = class_45872.method_23760().method_23761();
        class_287 class_2872 = class_289.method_1348().method_60827(VertexFormat.class_5596.field_27379, class_290.field_1576);
        float f = (float)color.getRed() / 255.0f;
        float f2 = (float)color.getGreen() / 255.0f;
        float f3 = (float)color.getBlue() / 255.0f;
        float f4 = (float)color.getAlpha() / 255.0f;
        float f5 = (float)class_2383.field_1323;
        float f6 = (float)class_2383.field_1322;
        float f7 = (float)class_2383.field_1321;
        float f8 = (float)class_2383.field_1320;
        float f9 = (float)class_2383.field_1325;
        float f10 = (float)class_2383.field_1324;
        zm.a(class_2872, matrix4f, f5, f6, f7, f8, f6, f7, f8, f9, f7, f, f2, f3, f4);
        zm.a(class_2872, matrix4f, f5, f6, f7, f8, f9, f7, f5, f9, f7, f, f2, f3, f4);
        zm.a(class_2872, matrix4f, f8, f6, f7, f8, f6, f10, f8, f9, f10, f, f2, f3, f4);
        zm.a(class_2872, matrix4f, f8, f6, f7, f8, f9, f10, f8, f9, f7, f, f2, f3, f4);
        zm.a(class_2872, matrix4f, f8, f6, f10, f5, f6, f10, f5, f9, f10, f, f2, f3, f4);
        zm.a(class_2872, matrix4f, f8, f6, f10, f5, f9, f10, f8, f9, f10, f, f2, f3, f4);
        zm.a(class_2872, matrix4f, f5, f6, f10, f5, f6, f7, f5, f9, f7, f, f2, f3, f4);
        zm.a(class_2872, matrix4f, f5, f6, f10, f5, f9, f7, f5, f9, f10, f, f2, f3, f4);
        zm.a(class_2872, matrix4f, f5, f9, f7, f8, f9, f7, f8, f9, f10, f, f2, f3, f4);
        zm.a(class_2872, matrix4f, f5, f9, f7, f8, f9, f10, f5, f9, f10, f, f2, f3, f4);
        zm.a(class_2872, matrix4f, f5, f6, f7, f5, f6, f10, f8, f6, f10, f, f2, f3, f4);
        zm.a(class_2872, matrix4f, f5, f6, f7, f8, f6, f10, f8, f6, f7, f, f2, f3, f4);
        za.a(class_2872);
    }

    public static void c(class_4587 class_45872, double d, double d2, double d3, float f, float f2, Color color) {
        float f3 = f / 2.0f;
        class_238 class_2383 = new class_238(d - (double)f3, d2, d3 - (double)f3, d + (double)f3, d2 + (double)f2, d3 + (double)f3);
        zm.c(class_45872, class_2383, color);
    }

    public static void a(class_4587 class_45872, class_243 class_2432, class_243 class_2433, Color color) {
        Matrix4f matrix4f = class_45872.method_23760().method_23761();
        class_287 class_2872 = class_289.method_1348().method_60827(VertexFormat.class_5596.field_29344, class_290.field_1576);
        float f = (float)color.getRed() / 255.0f;
        float f2 = (float)color.getGreen() / 255.0f;
        float f3 = (float)color.getBlue() / 255.0f;
        float f4 = (float)color.getAlpha() / 255.0f;
        zm.a(class_2872, matrix4f, (float)class_2432.field_1352, (float)class_2432.field_1351, (float)class_2432.field_1350, (float)class_2433.field_1352, (float)class_2433.field_1351, (float)class_2433.field_1350, f, f2, f3, f4);
        za.a(class_2872);
    }

    public static class_243 a(class_1297 class_12972, float f) {
        return class_12972.method_30950(f);
    }

    private static void a(class_287 class_2872, Matrix4f matrix4f, float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, float f10) {
        class_2872.method_22918((Matrix4fc)matrix4f, f, f2, f3).method_22915(f7, f8, f9, f10);
        class_2872.method_22918((Matrix4fc)matrix4f, f4, f5, f6).method_22915(f7, f8, f9, f10);
    }

    private static void a(class_287 class_2872, Matrix4f matrix4f, float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, float f10, float f11, float f12, float f13) {
        class_2872.method_22918((Matrix4fc)matrix4f, f, f2, f3).method_22915(f10, f11, f12, f13);
        class_2872.method_22918((Matrix4fc)matrix4f, f4, f5, f6).method_22915(f10, f11, f12, f13);
        class_2872.method_22918((Matrix4fc)matrix4f, f7, f8, f9).method_22915(f10, f11, f12, f13);
    }
}

