/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.opengl.GlStateManager
 *  com.mojang.blaze3d.vertex.VertexFormat$class_5596
 *  net.minecraft.class_10799
 *  net.minecraft.class_12249
 *  net.minecraft.class_287
 *  net.minecraft.class_289
 *  net.minecraft.class_290
 *  net.minecraft.class_2960
 *  net.minecraft.class_332
 *  net.minecraft.class_4587
 *  org.joml.Matrix3x2fStack
 *  org.joml.Matrix4f
 *  org.joml.Matrix4fc
 */
package com.vengeance.vengeanceclient.utils.w;

import com.mojang.blaze3d.opengl.GlStateManager;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.vengeance.vengeanceclient.utils.w.q.q.za;
import net.minecraft.class_10799;
import net.minecraft.class_12249;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import org.joml.Matrix3x2fStack;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;

public final class zq {
    private zq() {
    }

    public static void a() {
        GlStateManager._texParameter((int)3553, (int)10241, (int)9729);
        GlStateManager._texParameter((int)3553, (int)10240, (int)9729);
    }

    public static void b() {
        GlStateManager._texParameter((int)3553, (int)10241, (int)9728);
        GlStateManager._texParameter((int)3553, (int)10240, (int)9728);
    }

    public static void c() {
        GlStateManager._enableDepthTest();
        GlStateManager._depthFunc((int)519);
        GlStateManager._depthMask((boolean)false);
        GlStateManager._colorMask((boolean)false, (boolean)false, (boolean)false, (boolean)false);
    }

    public static void d() {
        GlStateManager._depthFunc((int)514);
        GlStateManager._depthMask((boolean)false);
        GlStateManager._colorMask((boolean)true, (boolean)true, (boolean)true, (boolean)true);
    }

    public static void e() {
        GlStateManager._depthFunc((int)515);
        GlStateManager._depthMask((boolean)true);
        GlStateManager._colorMask((boolean)true, (boolean)true, (boolean)true, (boolean)true);
        GlStateManager._disableDepthTest();
    }

    public static void a(class_4587 class_45872, class_2960 class_29602, float f, float f2, int n) {
        zq.a(class_45872, class_29602, f, f2, n, false);
    }

    public static void a(class_4587 class_45872, class_2960 class_29602, float f, float f2, int n, boolean bl) {
        if (class_45872 == null || class_29602 == null) {
            return;
        }
        if (bl) {
            zq.a();
        }
        float f3 = (float)(n >>> 24 & 0xFF) / 255.0f;
        float f4 = (float)(n >>> 16 & 0xFF) / 255.0f;
        float f5 = (float)(n >>> 8 & 0xFF) / 255.0f;
        float f6 = (float)(n & 0xFF) / 255.0f;
        Matrix4f matrix4f = class_45872.method_23760().method_23761();
        float f7 = f * 0.5f;
        float f8 = f2 * 0.5f;
        class_287 class_2872 = class_289.method_1348().method_60827(VertexFormat.class_5596.field_27382, class_290.field_1575);
        class_2872.method_22918((Matrix4fc)matrix4f, -f7, f8, 0.0f).method_22913(0.0f, 1.0f).method_22915(f4, f5, f6, f3);
        class_2872.method_22918((Matrix4fc)matrix4f, f7, f8, 0.0f).method_22913(1.0f, 1.0f).method_22915(f4, f5, f6, f3);
        class_2872.method_22918((Matrix4fc)matrix4f, f7, -f8, 0.0f).method_22913(1.0f, 0.0f).method_22915(f4, f5, f6, f3);
        class_2872.method_22918((Matrix4fc)matrix4f, -f7, -f8, 0.0f).method_22913(0.0f, 0.0f).method_22915(f4, f5, f6, f3);
        za.a(class_2872, class_12249.method_76000((class_2960)class_29602));
        if (bl) {
            zq.b();
        }
    }

    public static void a(class_332 class_3322, class_2960 class_29602, float f, float f2, float f3, float f4, float f5, int n) {
        zq.a(class_3322, class_29602, f, f2, f3, f4, f5, n, false);
    }

    public static void a(class_332 class_3322, class_2960 class_29602, float f, float f2, float f3, float f4, float f5, int n, boolean bl) {
        Matrix3x2fStack matrix3x2fStack = class_3322.method_51448();
        matrix3x2fStack.pushMatrix();
        matrix3x2fStack.translate(f, f2);
        if (f5 != 0.0f) {
            matrix3x2fStack.rotate((float)Math.toRadians(f5));
        }
        int n2 = Math.max(1, Math.round(f3));
        int n3 = Math.max(1, Math.round(f4));
        int n4 = Math.round(-f3 * 0.5f);
        int n5 = Math.round(-f4 * 0.5f);
        if (bl) {
            zq.a();
        }
        class_3322.method_25290(class_10799.field_56883, class_29602, n4, n5, 0.0f, 0.0f, n2, n3, n2, n3);
        if (bl) {
            zq.b();
        }
        matrix3x2fStack.popMatrix();
    }

    public static void a(class_332 class_3322, class_2960 class_29602, float f, float f2, float f3, float f4, int n) {
        zq.b(class_3322, class_29602, f, f2, f3, f4, 0.0f, n, false);
    }

    public static void b(class_332 class_3322, class_2960 class_29602, float f, float f2, float f3, float f4, float f5, int n, boolean bl) {
        zq.a(class_3322, class_29602, f, f2, f3, f4, f5, n, bl);
    }
}

