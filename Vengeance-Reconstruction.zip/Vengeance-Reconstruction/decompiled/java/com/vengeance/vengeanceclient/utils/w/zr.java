/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_243
 *  net.minecraft.class_310
 *  net.minecraft.class_4184
 *  org.joml.Matrix4f
 *  org.joml.Matrix4fc
 *  org.joml.Vector3f
 *  org.joml.Vector4f
 *  org.lwjgl.opengl.GL11
 */
package com.vengeance.vengeanceclient.utils.w;

import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL11;

public class zr {
    public static Matrix4f a = new Matrix4f();
    public static Matrix4f b = new Matrix4f();
    public static Matrix4f c = new Matrix4f();

    public static class_243 a(class_243 class_2432) {
        class_310 class_3102 = class_310.method_1551();
        if (class_3102 == null || class_3102.method_1561() == null || class_3102.method_1561().field_4686 == null) {
            return null;
        }
        class_4184 class_41842 = class_3102.method_1561().field_4686;
        class_243 class_2433 = class_41842.method_71156();
        return zr.a(class_2432, class_2433);
    }

    public static class_243 a(class_243 class_2432, class_243 class_2433) {
        class_310 class_3102 = class_310.method_1551();
        if (class_3102 == null) {
            return null;
        }
        int n = class_3102.method_22683().method_4506();
        int[] nArray = new int[4];
        GL11.glGetIntegerv((int)2978, (int[])nArray);
        Vector3f vector3f = new Vector3f();
        double d = class_2432.field_1352 - class_2433.field_1352;
        double d2 = class_2432.field_1351 - class_2433.field_1351;
        double d3 = class_2432.field_1350 - class_2433.field_1350;
        Vector4f vector4f = new Vector4f((float)d, (float)d2, (float)d3, 1.0f).mul((Matrix4fc)c);
        Matrix4f matrix4f = new Matrix4f((Matrix4fc)a);
        Matrix4f matrix4f2 = new Matrix4f((Matrix4fc)b);
        matrix4f.mul((Matrix4fc)matrix4f2).project(vector4f.x(), vector4f.y(), vector4f.z(), nArray, vector3f);
        return new class_243((double)(vector3f.x / (float)class_3102.method_22683().method_4495()), (double)(((float)n - vector3f.y) / (float)class_3102.method_22683().method_4495()), (double)vector3f.z);
    }
}

