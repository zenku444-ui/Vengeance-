/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_310
 */
package com.vengeance.vengeanceclient.utils;

import net.minecraft.class_310;

public interface zb {
    public static final class_310 w = class_310.method_1551();
}

