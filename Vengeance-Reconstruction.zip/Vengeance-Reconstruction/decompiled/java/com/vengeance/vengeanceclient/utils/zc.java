/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 */
package com.vengeance.vengeanceclient.utils;

import net.minecraft.class_1799;
import net.minecraft.class_1802;

public class zc {
    public static boolean a(class_1799 class_17992) {
        if (class_17992.method_7960()) {
            return false;
        }
        return class_17992.method_7909() == class_1802.field_8463 || class_17992.method_7909() == class_1802.field_8367 || class_17992.method_7909() == class_1802.field_8229 || class_17992.method_7909() == class_1802.field_8176 || class_17992.method_7909() == class_1802.field_8261 || class_17992.method_7909() == class_1802.field_8544 || class_17992.method_7909() == class_1802.field_8347 || class_17992.method_7909() == class_1802.field_8752 || class_17992.method_7909() == class_1802.field_8509 || class_17992.method_7909() == class_1802.field_8373 || class_17992.method_7909() == class_1802.field_8279 || class_17992.method_7909() == class_1802.field_8179 || class_17992.method_7909() == class_1802.field_8567 || class_17992.method_7909() == class_1802.field_8512 || class_17992.method_7909() == class_1802.field_8497 || class_17992.method_7909() == class_1802.field_16998 || class_17992.method_7909() == class_1802.field_28659 || class_17992.method_7909() == class_1802.field_8233 || class_17992.method_7909() == class_1802.field_8551 || class_17992.method_7909() == class_1802.field_20417 || class_17992.method_7909() == class_1802.field_8208 || class_17992.method_7909() == class_1802.field_8308 || class_17992.method_7909() == class_1802.field_8515 || class_17992.method_7909() == class_1802.field_8766 || class_17992.method_7909() == class_1802.field_8741 || class_17992.method_7909() == class_1802.field_17534;
    }
}

